# راهنمای جامع راه‌اندازی، استقرار و انتشار (Deployment & Operations Guide)
**پروژه:** GOLI SITE MANAGER  
**مخاطب:** مهندسین DevOps، مدیران سیستم و توسعه‌دهندگان فول‌استک

---

## ۱. پیش‌نیازهای سیستمی (System Requirements)

* **Node.js:** نگارش 20.x یا 22.x LTS (توصیه شده: Node 22.x)
* **npm:** نگارش 10.x یا بالاتر
* **پایگاه داده / وب‌سایت مقصد:** وردپرس نسخه 6.0+ همراه با ووکامرس 8.0+ و افزونه المنتور (Elementor)
* **پورت اجرایی سرور:** پورت 3000 (قابل تغییر از طریق متغیر محیطی `PORT`)

---

## ۲. راه‌اندازی محلی برای توسعه (Local Development)

### گام اول: کلون کردن و ورود به پوشه پروژه
```bash
git clone <URL_REPOSITOY>
cd Sitgolikala
```

### گام دوم: تنظیم فایل متغیرهای محیطی
یک کپی از فایل `.env.example` با نام `.env` ایجاد کنید:
```bash
cp .env.example .env
```
محتوای فایل `.env`:
```env
# کلید سرویس هوش مصنوعی گوگل جهت پردازش دستیار Goli AI Agent (اختیاری اما توصیه شده)
GEMINI_API_KEY="YOUR_GEMINI_API_KEY_HERE"

# نشانی دامنه میزبانی اپلیکیشن
APP_URL="http://localhost:3000"

# پورت اجرایی سرور
PORT=3000
```

### گام سوم: نصب وابستگی‌ها
**نکته بسیار مهم:** به دلیل استفاده از React 19، دستور نصب را همراه با فلگ `--legacy-peer-deps` اجرا کنید:
```bash
npm install --legacy-peer-deps
```

### گام چهارم: اجرای سرور توسعه (Dev Server)
```bash
npm run dev
```
اکنون برنامه بر روی آدرس `http://localhost:3000` همراه با قابلیت‌های کامل فول‌استک، پروکسی وردپرس و هات‌لودینگ Vite در دسترس است.

---

## ۳. بیلد و اجرای نسخه پروداکشن (Production Build & Run)

### گام اول: بیلد دارایی‌های استاتیک فرانت‌اند
```bash
npm run build
```
این دستور کدهای فرانت‌اند را کامپایل کرده و بسته نهایی مینیفای‌شده را در پوشه `dist/` ایجاد می‌کند.

### گام دوم: اجرای سرور پروداکشن
```bash
npm start
```
سرور اکسپرس در فایل `server.ts` فایل‌های کامپایل‌شده داخل `dist/` را به همراه تمام اندپوینت‌های پروکسی API سرویس‌دهی می‌کند.

---

## ۴. استقرار با داکر (Docker Deployment)

برای استقرار ایزوله در سرورهای ابری، لینوکس VPS، کوبرنتیز یا Google Cloud Run، از ساختار زیر استفاده کنید:

### فایل `Dockerfile`
```dockerfile
FROM node:22-alpine AS builder
WORKDIR /app
COPY package*.json .npmrc ./
RUN npm install --legacy-peer-deps
COPY . .
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV PORT=3000
COPY package*.json .npmrc ./
RUN npm install --omit=dev --legacy-peer-deps
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/server.ts ./
COPY --from=builder /app/tsconfig.json ./
RUN npm install -g tsx

EXPOSE 3000
CMD ["tsx", "server.ts"]
```

### اجرای کانتینر داکر:
```bash
docker build -t goli-site-manager .
docker run -d -p 3000:3000 --env-file .env --name goli-manager goli-site-manager
```

---

## ۵. کانفیگ وب‌سرور Nginx به عنوان Reverse Proxy (روی دامنه `manager.golikala.com`)

اگر قصد دارید اپلیکیشن را روی یک ساب‌دامین اختصاصی در سرور اوبونتو با Nginx بالا بیاورید:

```nginx
server {
    listen 80;
    server_name manager.golikala.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name manager.golikala.com;

    ssl_certificate /etc/letsencrypt/live/manager.golikala.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/manager.golikala.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## ۶. فعال‌سازی و استقرار افزونه وردپرس (Companion Bridge)

1. فایل زیپ آماده افزونه در پوشه `public/goli-companion-bridge.zip` قرار دارد.
2. در پیشخوان وردپرس سایت `golikala.com` به مسیر **افزونه‌ها ⬅️ افزودن افزونه ⬅️ بارگذاری افزونه** بروید.
3. فایل `goli-companion-bridge.zip` را آپلود و **فعال‌سازی** کنید.
4. برای تست فعال‌بودن، آدرس زیر را در مرورگر تست کنید:
   `https://golikala.com/wp-json/goli/v1/health`
   پاسخ باید به صورت شیء JSON با `status: "OK"` باشد.
