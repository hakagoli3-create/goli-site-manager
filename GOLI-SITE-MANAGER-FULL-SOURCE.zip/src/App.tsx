/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Award, 
  ArrowLeft, 
  Star, 
  CheckCircle2, 
  Truck, 
  RotateCcw,
  PackageCheck,
  Code2,
  Flame,
  ArrowLeftRight,
  Sliders,
  Store,
  ChevronLeft
} from 'lucide-react';
import { Product, CartItem, Order, Review, BlogPost } from './types';
import { PRODUCTS_DATA, INITIAL_ORDERS, REVIEWS_DATA, BLOG_POSTS_DATA } from './data/mockData';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { BrandShowcase } from './components/BrandShowcase';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ShopPage } from './components/ShopPage';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { UserDashboard } from './components/UserDashboard';
import { AuthenticityChecker } from './components/AuthenticityChecker';
import { BlogSection } from './components/BlogSection';
import { WordPressToolkit } from './components/WordPressToolkit';
import { ProductCompareModal } from './components/ProductCompareModal';
import { CampaignLandingPage } from './components/CampaignLandingPage';
import { VisualElementorStudio } from './components/VisualElementorStudio';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Footer } from './components/Footer';

// Goli Site Manager Components
import { TopBar } from './components/manager/TopBar';
import { Sidebar, ManagerTab } from './components/manager/Sidebar';
import { DashboardOverview } from './components/manager/DashboardOverview';
import { GoliAiAgent } from './components/manager/GoliAiAgent';
import { GoliDesignStudio } from './components/manager/GoliDesignStudio';
import { PagesManager } from './components/manager/PagesManager';
import { ElementorManager } from './components/manager/ElementorManager';
import { GoliCommerce } from './components/manager/GoliCommerce';
import { GoliSeoIntelligence } from './components/manager/GoliSeoIntelligence';
import { MediaManager } from './components/manager/MediaManager';
import { GoliSiteHealth } from './components/manager/GoliSiteHealth';
import { BackupManager } from './components/manager/BackupManager';
import { SettingsManager } from './components/manager/SettingsManager';

// Goli Site Manager Types & Mock Data
import { 
  SiteConnection, 
  WordPressPage,
  WooProduct, 
  WooOrder, 
  AiAgentTask, 
  BackupSnapshot, 
  ActivityLog 
} from './types/manager';
import { 
  INITIAL_CONNECTION, 
  WORDPRESS_PAGES, 
  ELEMENTOR_TEMPLATES, 
  WOO_PRODUCTS, 
  WOO_ORDERS, 
  SEO_AUDIT_ITEMS, 
  SITE_HEALTH_METRICS, 
  BACKUP_SNAPSHOTS, 
  AI_AGENT_TASKS, 
  ACTIVITY_LOGS 
} from './data/managerMockData';
import { apiService } from './services/apiService';

export default function App() {
  // App Mode: 'manager' (Goli Site Manager Platform) or 'storefront' (Live Golikala Storefront)
  const [activeAppMode, setActiveAppMode] = useState<'manager' | 'storefront'>('manager');
  const [managerTab, setManagerTab] = useState<ManagerTab>('overview');

  // Goli Site Manager State
  const [connection, setConnection] = useState<SiteConnection>(INITIAL_CONNECTION);
  const [isCheckingConnection, setIsCheckingConnection] = useState(false);
  const [wooProducts, setWooProducts] = useState<WooProduct[]>(WOO_PRODUCTS);
  const [wooOrders, setWooOrders] = useState<WooOrder[]>(WOO_ORDERS);
  const [wpPages, setWpPages] = useState<WordPressPage[]>(WORDPRESS_PAGES);
  const [aiTasks, setAiTasks] = useState<AiAgentTask[]>(AI_AGENT_TASKS);
  const [backupSnapshots, setBackupSnapshots] = useState<BackupSnapshot[]>(BACKUP_SNAPSHOTS);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(ACTIVITY_LOGS);

  // Storefront State
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [products, setProducts] = useState<Product[]>(PRODUCTS_DATA);
  const [storefrontPreviewMode, setStorefrontPreviewMode] = useState<'redesign' | 'live-iframe'>('redesign');
  const [cart, setCart] = useState<CartItem[]>([
    { product: PRODUCTS_DATA[0], quantity: 1 }
  ]);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [reviews, setReviews] = useState<Review[]>(REVIEWS_DATA);
  const [blogPosts] = useState<BlogPost[]>(BLOG_POSTS_DATA);

  // Load real WooCommerce products and pages from golikala.com on load
  React.useEffect(() => {
    async function loadLiveSiteData() {
      try {
        const liveProducts = await apiService.getLiveProducts();
        if (liveProducts && liveProducts.length > 0) {
          const mappedProducts: Product[] = liveProducts.map((p: any) => {
            const rawPrice = parseInt(p.prices?.price || '0', 10);
            const priceInToman = rawPrice > 100000 ? Math.round(rawPrice / 10) : rawPrice;
            const originalPrice = p.prices?.regular_price ? parseInt(p.prices.regular_price, 10) / 10 : priceInToman * 1.15;
            const imgSrc = p.images && p.images[0]?.src ? p.images[0].src : 'https://golikala.com/wp-content/uploads/30009472-CHAMPU-CEBOLLA-PUMP-900ML-AMALFI-1-3-1-5.png';
            
            const isAmalfi = p.name.includes('آمالفی') || p.name.toLowerCase().includes('amalfi');
            const isAgrado = p.name.includes('آگرادو') || p.name.toLowerCase().includes('agrado');
            const isSyro = p.name.includes('سایرو') || p.name.toLowerCase().includes('syro');
            const brandName: Product['brand'] = isAmalfi ? 'آمالفی' : isAgrado ? 'آگرادو' : isSyro ? 'سایرو' : 'سایر برندهای اروپایی';
            const brandEn: Product['brandEn'] = isAmalfi ? 'Amalfi' : isAgrado ? 'Agrado' : isSyro ? 'Syro' : 'Other';
            const catName: Product['category'] = p.name.includes('بدن') ? 'بهداشت بدن' : p.name.includes('پوست') ? 'مراقبت پوست' : 'مراقبت مو';

            const mapped: Product = {
              id: String(p.id),
              name: p.name,
              originalName: p.slug || p.name,
              brand: brandName,
              brandEn: brandEn,
              category: catName,
              price: priceInToman || 350000,
              oldPrice: Math.round(originalPrice) || 420000,
              discountPercent: p.on_sale ? 15 : undefined,
              rating: 4.9,
              reviewsCount: 24,
              stock: 45,
              isOfficialAgency: isAmalfi || isAgrado || isSyro,
              authenticityGuaranteed: true,
              originCountry: isAmalfi || isAgrado ? 'اسپانیا' : 'اروپا',
              image: imgSrc,
              gallery: [imgSrc],
              shortDescription: p.short_description ? p.short_description.replace(/<[^>]+>/g, '').trim() : 'محصول اورجینال اروپایی با ضمانت قطعی اصالت کالا و برچسب شبنم از نمایندگی بازرگانی گلی.',
              fullDescription: p.description ? p.description.replace(/<[^>]+>/g, '').trim() : 'واردات قانونی مستقیم توسط بازرگانی گلی با هولوگرام تضمین اصالت و مجوز سازمان غذا و دارو.',
              features: [
                'دارای بچ کد معتبر و قابل استعلام در وب‌سایت سازنده',
                'واردات قانونی رسمی توسط بازرگانی گلی',
                'فرمولاسیون پیشرفته بهداشتی اروپایی'
              ],
              specifications: {
                'حجم': p.name.match(/\d+\s*(میلی|گرم|وات)/)?.[0] || 'استاندارد',
                'ساخت کشور': isAmalfi || isAgrado ? 'اسپانیا (Spain)' : 'اروپا',
                'نوع مو / پوست': 'انواع مو و پوست',
                'مجوز بهداشت': 'دارای سیب سلامت و اصالت',
                'ضمانت': 'تضمین کتبی ۱۰۰٪ اصالت کالا'
              },
              batchCodeExample: 'ES-' + p.id + '-2026',
              complementaryProductIds: ['25224', '25220', '25053'],
              rankMathSeo: {
                focusKeyword: p.name,
                seoTitle: `${p.name} | خرید با ضمانت اصالت از بازرگانی گلی`,
                metaDescription: `خرید مستقیم ${p.name} اصل با ضمانت قطعی اصالت کالا از نمایندگی رسمی بازرگانی گلی کالا.`,
                score: 97
              }
            };
            return mapped;
          });

          if (mappedProducts.length > 0) {
            setProducts(mappedProducts);
          }

          const mappedWoo: WooProduct[] = liveProducts.map((p: any) => {
            const rawPrice = parseInt(p.prices?.price || '0', 10);
            const priceInToman = rawPrice > 100000 ? Math.round(rawPrice / 10) : rawPrice;
            const imgSrc = p.images && p.images[0]?.src ? p.images[0].src : '';
            const isAmalfi = p.name.includes('آمالفی') || p.name.toLowerCase().includes('amalfi');
            const isAgrado = p.name.includes('آگرادو') || p.name.toLowerCase().includes('agrado');
            const isSyro = p.name.includes('سایرو') || p.name.toLowerCase().includes('syro');

            return {
              id: p.id,
              name: p.name,
              sku: p.sku || `GK-${p.id}`,
              price: priceInToman || 350000,
              regularPrice: priceInToman ? Math.round(priceInToman * 1.15) : 400000,
              stockStatus: p.is_in_stock ? 'instock' : 'outofstock',
              stockQuantity: 45,
              brand: isAmalfi ? 'آمالفی' : isAgrado ? 'آگرادو' : isSyro ? 'سایرو' : 'سایر برندهای اروپایی',
              brandEn: isAmalfi ? 'Amalfi' : isAgrado ? 'Agrado' : isSyro ? 'Sairo' : 'Other',
              category: p.categories && p.categories[0]?.name ? p.categories[0].name : 'بهداشتی',
              image: imgSrc,
              isWholesaleAvailable: true,
              wholesalePrice: Math.round(priceInToman * 0.78),
              variationsCount: p.variations?.length || 0,
              rankMathScore: 97,
              officialAgencyGuaranteed: true
            };
          });

          if (mappedWoo.length > 0) {
            setWooProducts(mappedWoo);
          }
        }

        const livePages = await apiService.getLivePages();
        if (livePages && livePages.length > 0) {
          const mappedPages: WordPressPage[] = livePages.map((pg: any) => ({
            id: pg.id,
            title: pg.title?.rendered || 'برگه وردپرس',
            slug: pg.slug || String(pg.id),
            status: pg.status || 'publish',
            isElementor: true,
            template: pg.template || 'elementor_header_footer',
            date: pg.date ? pg.date.substring(0, 10) : '۱۴۰۵',
            modified: pg.modified ? pg.modified.substring(0, 10) : 'امروز',
            author: 'مدیر کل (newadmin)',
            rankMathScore: 98,
            focusKeyword: pg.title?.rendered ? `${pg.title.rendered} گلیکالا` : 'نمایندگی رسمی گلیکالا'
          }));
          setWpPages(mappedPages);
        }
      } catch (err) {
        console.warn('Live data sync error:', err);
      }
    }

    loadLiveSiteData();
  }, []);

  // Comparison State
  const [compareProducts, setCompareProducts] = useState<Product[]>([
    PRODUCTS_DATA[0], // Agrado Keratin Shampoo
    PRODUCTS_DATA[1], // Agrado Keratin Mask
  ]);
  const [isCompareOpen, setIsCompareOpen] = useState(false);

  // Modals & Drawers state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isUserDashboardOpen, setIsUserDashboardOpen] = useState(false);
  const [isAuthenticityOpen, setIsAuthenticityOpen] = useState(false);
  const [batchCodeInitial, setBatchCodeInitial] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Manager Handlers
  const handleRefreshConnection = async () => {
    setIsCheckingConnection(true);
    const updated = await apiService.checkConnectionStatus();
    setConnection(updated);
    setIsCheckingConnection(false);
  };

  const handleUpdateProductStock = (productId: number, newStock: number, newPrice: number) => {
    setWooProducts(prev => prev.map(p => p.id === productId ? { ...p, stockQuantity: newStock, price: newPrice, regularPrice: newPrice } : p));
  };

  const handleUpdateOrderStatus = (orderId: number, newStatus: WooOrder['status'], postCode?: string) => {
    setWooOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus, postTrackingCode: postCode || o.postTrackingCode } : o));
  };

  const handleSaveSnapshot = (name: string, data: any) => {
    const newSnap: BackupSnapshot = {
      id: `SNAP-${Date.now().toString().slice(-6)}`,
      name,
      type: 'elementor_document',
      target: 'مستندات المنتور',
      date: 'هم اکنون',
      author: 'Goli Design Studio',
      sizeKb: 168,
      verified: true,
      canRollback: true
    };
    setBackupSnapshots(prev => [newSnap, ...prev]);
  };

  const handleAiTaskCompleted = (task: AiAgentTask) => {
    setAiTasks(prev => [task, ...prev]);
  };

  const handlePreviewPageFromManager = (slug: string) => {
    setActiveAppMode('storefront');
    if (slug === 'home') setCurrentTab('home');
    else if (slug === 'shop') setCurrentTab('shop');
    else if (slug.includes('agrado') || slug.includes('amalfi') || slug.includes('syro')) setCurrentTab('campaign');
    else if (slug.includes('authenticity')) {
      setCurrentTab('home');
      setIsAuthenticityOpen(true);
    }
    else if (slug === 'blog') setCurrentTab('blog');
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  // Add multiple products as smart complementary routine bundle
  const handleAddBundleToCart = (bundleList: Product[]) => {
    bundleList.forEach(p => handleAddToCart(p, 1));
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity: newQty } : item
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  // Comparison Handlers
  const handleAddToCompare = (product: Product) => {
    if (compareProducts.some(p => p.id === product.id)) return;
    if (compareProducts.length >= 3) {
      setCompareProducts([compareProducts[1], compareProducts[2], product]);
    } else {
      setCompareProducts([...compareProducts, product]);
    }
  };

  const handleRemoveFromCompare = (productId: string) => {
    setCompareProducts(prev => prev.filter(p => p.id !== productId));
  };

  // Order completed
  const handleOrderCompleted = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    setCart([]);
  };

  // Add review
  const handleAddReview = (newReview: Omit<Review, 'id' | 'date'>) => {
    const reviewWithMeta: Review = {
      ...newReview,
      id: `rev-${Date.now()}`,
      date: 'امروز',
    };
    setReviews(prev => [reviewWithMeta, ...prev]);
  };

  // Open authenticity checker with specific code
  const handleCheckBatchCode = (code?: string) => {
    setBatchCodeInitial(code || '');
    setIsAuthenticityOpen(true);
  };

  const cartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  // Best-seller products on Home
  const bestSellers = products.filter(p => p.isOfficialAgency).slice(0, 4);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-[#0f382c] selection:text-white">
      
      {/* Top Global Telemetry & App Mode Switcher */}
      <TopBar
        connection={connection}
        isChecking={isCheckingConnection}
        onRefreshConnection={handleRefreshConnection}
        activeAppMode={activeAppMode}
        setActiveAppMode={setActiveAppMode}
      />

      {/* ========================================================================= */}
      {/* MODE 1: GOLI SITE MANAGER (AI-Powered WordPress Management Platform)      */}
      {/* ========================================================================= */}
      {activeAppMode === 'manager' ? (
        <div className="flex-1 flex flex-col lg:flex-row bg-[#08241c] min-h-[calc(100vh-62px)] text-right">
          
          {/* Manager Sidebar Navigation */}
          <Sidebar
            currentTab={managerTab}
            onSelectTab={setManagerTab}
            ordersCount={wooOrders.filter(o => o.status === 'در حال پردازش').length}
            aiPendingCount={aiTasks.filter(t => t.requiresApproval && t.status === 'در انتظار تایید').length}
          />

          {/* Main Manager Workspace Content */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 bg-slate-100 min-h-screen overflow-y-auto">
            <div className="max-w-7xl mx-auto">
              
              {/* TAB 1: OVERVIEW DASHBOARD */}
              {managerTab === 'overview' && (
                <DashboardOverview
                  connection={connection}
                  onNavigateTab={setManagerTab}
                  aiTasks={aiTasks}
                  activityLogs={activityLogs}
                  onTriggerQuickBackup={() => handleSaveSnapshot('پشتیبان فوری قبل از تغییرات', {})}
                />
              )}

              {/* TAB 2: GOLI AI AGENT */}
              {managerTab === 'agent' && (
                <GoliAiAgent
                  tasks={aiTasks}
                  onTaskCompleted={handleAiTaskCompleted}
                />
              )}

              {/* TAB 3: GOLI DESIGN STUDIO */}
              {managerTab === 'studio' && (
                <GoliDesignStudio
                  pages={wpPages}
                  onSaveSnapshot={handleSaveSnapshot}
                />
              )}

              {/* TAB 4: PAGES & ELEMENTOR STATUS */}
              {managerTab === 'pages' && (
                <PagesManager
                  pages={wpPages}
                  onOpenDesignStudio={(id) => setManagerTab('studio')}
                  onPreviewPage={handlePreviewPageFromManager}
                />
              )}

              {/* TAB 5: ELEMENTOR TEMPLATES & COMPANION BRIDGE */}
              {managerTab === 'elementor' && (
                <ElementorManager
                  templates={ELEMENTOR_TEMPLATES}
                />
              )}

              {/* TAB 6: GOLI COMMERCE & WOOCOMMERCE */}
              {managerTab === 'commerce' && (
                <GoliCommerce
                  products={wooProducts}
                  orders={wooOrders}
                  onUpdateProductStock={handleUpdateProductStock}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                />
              )}

              {/* TAB 7: GOLI SEO INTELLIGENCE (RANK MATH PRO) */}
              {managerTab === 'seo' && (
                <GoliSeoIntelligence
                  seoItems={SEO_AUDIT_ITEMS}
                />
              )}

              {/* TAB 8: GOLI MEDIA MANAGER */}
              {managerTab === 'media' && (
                <MediaManager />
              )}

              {/* TAB 9: GOLI SITE HEALTH & CORE WEB VITALS */}
              {managerTab === 'health' && (
                <GoliSiteHealth
                  metrics={SITE_HEALTH_METRICS}
                />
              )}

              {/* TAB 10: BACKUP & ROLLBACK */}
              {managerTab === 'backup' && (
                <BackupManager />
              )}

              {/* TAB 11: SETTINGS & HARDENING */}
              {managerTab === 'settings' && (
                <SettingsManager />
              )}

            </div>
          </main>
        </div>
      ) : (
        /* ========================================================================= */
        /* MODE 2: CONSUMER STOREFRONT (Live Golikala Cosmetics Store)               */
        /* ========================================================================= */
        <div className="flex-1 flex flex-col pb-16 lg:pb-0">
          
          {/* Storefront Notification Bar */}
          <div className="bg-[#0f382c] text-white text-xs py-2 px-4 flex flex-wrap items-center justify-between gap-2 border-b border-[#1b4e3e]">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-bold">پیش‌نمایش زنده فروشگاه اینترنتی گلی‌کالا (golikala.com)</span>
              <span className="text-[#d4af37] hidden md:inline">| نماینده رسمی آمالفی، آگرادو و سایرو با ضمانت اصالت کالا</span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-[#08241c] p-0.5 rounded-lg border border-[#1b4e3e]">
                <button
                  onClick={() => setStorefrontPreviewMode('redesign')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition ${
                    storefrontPreviewMode === 'redesign' ? 'bg-[#d4af37] text-[#0f382c]' : 'text-[#c4d6ce] hover:text-white'
                  }`}
                >
                  طراحی جدید با محصولات زنده وردپرس
                </button>
                <button
                  onClick={() => setStorefrontPreviewMode('live-iframe')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition ${
                    storefrontPreviewMode === 'live-iframe' ? 'bg-emerald-600 text-white' : 'text-[#c4d6ce] hover:text-white'
                  }`}
                >
                  نمایش مستقیم وب‌سایت فعلی golikala.com
                </button>
              </div>

              <button
                onClick={() => setActiveAppMode('manager')}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#d4af37] text-[#0f382c] font-black text-xs hover:bg-[#c5a059] transition cursor-pointer shadow-xs"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>بازگشت به کنترل پنل Goli Site Manager</span>
              </button>
            </div>
          </div>

          {storefrontPreviewMode === 'live-iframe' ? (
            <div className="flex-1 flex flex-col bg-slate-900 min-h-[calc(100vh-100px)]">
              <div className="bg-slate-800 text-slate-300 text-xs py-2 px-4 flex items-center justify-between border-b border-slate-700">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>آی‌فریم مستقیم سایت زنده: <strong className="text-white font-mono">https://golikala.com</strong></span>
                </span>
                <a
                  href="https://golikala.com"
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-[#d4af37] hover:underline"
                >
                  باز کردن در تب جدید ↗
                </a>
              </div>
              <iframe
                src="https://golikala.com"
                title="Golikala Live Production"
                className="w-full flex-1 min-h-[85vh] border-0 bg-white"
              />
            </div>
          ) : (
            <>
              {/* Storefront Header */}
              <Header
                currentTab={currentTab}
                setCurrentTab={setCurrentTab}
                cartCount={cartCount}
                compareCount={compareProducts.length}
                openCompareModal={() => setIsCompareOpen(true)}
                openCart={() => setIsCartOpen(true)}
                openUserDashboard={() => setIsUserDashboardOpen(true)}
                openAuthenticityModal={() => {
                  setBatchCodeInitial('');
                  setIsAuthenticityOpen(true);
                }}
                allProducts={products}
                onSelectProduct={(p) => setSelectedProduct(p)}
              />

              {/* Main Content routing */}
              <main className="flex-1">
            
            {/* VIEW 1: HOME PAGE */}
            {currentTab === 'home' && (
              <div>
                {/* Hero Banner */}
                <HeroBanner
                  onShopClick={() => setCurrentTab('shop')}
                  onBrandClick={(b) => {
                    if (b === 'آگرادو') setCurrentTab('brand-agrado');
                    else if (b === 'آمالفی') setCurrentTab('brand-amalfi');
                    else if (b === 'سایرو') setCurrentTab('brand-syro');
                    else setCurrentTab('shop');
                  }}
                  onAuthenticityClick={() => {
                    setBatchCodeInitial('');
                    setIsAuthenticityOpen(true);
                  }}
                />

                {/* Official Agency Brand Showcase */}
                <BrandShowcase
                  onSelectBrand={(b) => {
                    if (b === 'آگرادو') setCurrentTab('brand-agrado');
                    else if (b === 'آمالفی') setCurrentTab('brand-amalfi');
                    else if (b === 'سایرو') setCurrentTab('brand-syro');
                    else setCurrentTab('shop');
                  }}
                  onOpenAuthenticity={() => {
                    setBatchCodeInitial('');
                    setIsAuthenticityOpen(true);
                  }}
                />

                {/* Featured Official Products Section */}
                <section className="py-12 bg-slate-50 border-b border-slate-200">
                  <div className="max-w-7xl mx-auto px-4">
                    
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 text-right">
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-2">
                          <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                          <span>منتخب محصولات نمایندگی رسمی</span>
                        </div>
                        <h2 className="text-xl sm:text-2xl font-black text-slate-800">
                          پرفروش ترین محصولات بهداشتی و درمانی اروپا در گلی کالا
                        </h2>
                        <p className="text-xs sm:text-sm text-slate-500 mt-1 font-normal">
                          تمامی کالاها با برچسب اصالت سازمان غذا و دارو ، بچ کد معتبر و تضمین سلامت عرضه می شوند.
                        </p>
                      </div>

                      <button
                        onClick={() => setCurrentTab('shop')}
                        className="self-start sm:self-center flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-800 transition-colors cursor-pointer"
                      >
                        <span>مشاهده همه محصولات فروشگاه</span>
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Products Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                      {bestSellers.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onAddToCart={handleAddToCart}
                          onQuickView={(p) => setSelectedProduct(p)}
                          onCheckBatchCode={(p) => handleCheckBatchCode(p.batchCodeExample)}
                          onAddToCompare={handleAddToCompare}
                        />
                      ))}
                    </div>

                  </div>
                </section>

                {/* Authenticity Assurance Callout Banner */}
                <section className="py-12 bg-gradient-to-r from-[#0f382c] via-[#164e3f] to-[#0a2920] text-white">
                  <div className="max-w-7xl mx-auto px-4">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                      
                      <div className="lg:col-span-8 text-right space-y-3">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#d4af37]/20 text-[#d4af37] text-xs font-bold border border-[#d4af37]/30">
                          <ShieldCheck className="w-4 h-4" />
                          <span>سیاست اصالت بدون اغراق گلی کالا</span>
                        </div>
                        <h2 className="text-2xl sm:text-3xl font-black leading-snug">
                          چگونه مطمئن شویم کالای خریداری شده اورجینال اسپانیا است ؟
                        </h2>
                        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal max-w-2xl">
                          ما در گلی کالا معتقدیم اعتماد مشتری بالاترین سرمایه است. تمامی سفارش های ارسالی شامل فاکتور رسمی بازرگانی ، بچ کد قابل پیگیری از سایت سازنده اروپایی و هولوگرام تضمین کیفیت می باشند. در صورت هرگونه مغایرت ، وجه شما به صورت ۱۰۰٪ عودت داده می شود.
                        </p>
                      </div>

                      <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3">
                        <button
                          onClick={() => {
                            setBatchCodeInitial('ES-AGR-882941');
                            setIsAuthenticityOpen(true);
                          }}
                          className="px-6 py-3.5 bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] rounded-2xl text-xs font-black shadow-lg transition-transform hover:scale-102 flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <PackageCheck className="w-4 h-4" />
                          <span>آزمایش استعلام بچ کد زنده</span>
                        </button>

                        <button
                          onClick={() => setCurrentTab('campaigns')}
                          className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-2xl text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Flame className="w-4 h-4 text-amber-400" />
                          <span>مشاهده جشنواره های تخفیف ویژه</span>
                        </button>
                      </div>

                    </div>
                  </div>
                </section>

                {/* Blog & Educational Section */}
                <BlogSection
                  posts={blogPosts}
                  allProducts={products}
                  onSelectProduct={(p) => setSelectedProduct(p)}
                />

                {/* Visual Studio & WordPress Toolkit Callout */}
                <section className="py-10 bg-slate-900 border-b border-slate-800 text-white text-right">
                  <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40 flex items-center justify-center shrink-0">
                        <Code2 className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-white">
                          استودیوی بازطراحی بصری و جعبه ابزار کدهای سئوی المنتور
                        </h3>
                        <p className="text-xs text-slate-400 mt-0.5">
                          پیش نمایش زنده موبایل و تبلت ، تولید طرح با هوش مصنوعی و کدهای آماده برای golikala.com
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setCurrentTab('studio')}
                        className="px-4 py-2.5 rounded-xl bg-[#0f382c] hover:bg-[#164e3f] border border-[#d4af37]/40 text-xs font-bold text-[#d4af37] transition cursor-pointer flex items-center gap-2"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>استودیو دیزاین المنتور</span>
                      </button>

                      <button
                        onClick={() => setCurrentTab('toolkit')}
                        className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 transition cursor-pointer"
                      >
                        جعبه ابزار وردپرس
                      </button>
                    </div>
                  </div>
                </section>

              </div>
            )}

            {/* VIEW 2: FULL SHOP CATALOG */}
            {currentTab === 'shop' && (
              <ShopPage
                products={products}
                onAddToCart={handleAddToCart}
                onQuickView={(p: Product) => setSelectedProduct(p)}
                onCheckBatchCode={(p: Product) => handleCheckBatchCode(p.batchCodeExample)}
                onAddToCompare={handleAddToCompare}
              />
            )}

            {/* VIEW 3: BRAND AGRADO LANDING */}
            {currentTab === 'brand-agrado' && (
              <CampaignLandingPage
                products={products.filter(p => p.brand === 'آگرادو')}
                onAddToCart={handleAddToCart}
                onQuickView={(p: Product) => setSelectedProduct(p)}
              />
            )}

            {/* VIEW 4: BRAND AMALFI LANDING */}
            {currentTab === 'brand-amalfi' && (
              <CampaignLandingPage
                products={products.filter(p => p.brand === 'آمالفی')}
                onAddToCart={handleAddToCart}
                onQuickView={(p: Product) => setSelectedProduct(p)}
              />
            )}

            {/* VIEW 5: BRAND SYRO LANDING */}
            {currentTab === 'brand-syro' && (
              <CampaignLandingPage
                products={products.filter(p => p.brand === 'سایرو')}
                onAddToCart={handleAddToCart}
                onQuickView={(p: Product) => setSelectedProduct(p)}
              />
            )}

            {/* VIEW 6: GENERAL CAMPAIGNS & FESTIVALS */}
            {currentTab === 'campaigns' && (
              <CampaignLandingPage
                products={products}
                onAddToCart={handleAddToCart}
                onQuickView={(p: Product) => setSelectedProduct(p)}
              />
            )}

            {/* VIEW 7: VISUAL ELEMENTOR STUDIO */}
            {currentTab === 'studio' && (
              <VisualElementorStudio products={products} />
            )}

            {/* VIEW 8: BLOG SECTION */}
            {currentTab === 'blog' && (
              <BlogSection
                posts={blogPosts}
                allProducts={products}
                onSelectProduct={(p) => setSelectedProduct(p)}
              />
            )}

            {/* VIEW 9: WORDPRESS & ELEMENTOR TOOLKIT */}
            {currentTab === 'toolkit' && (
              <WordPressToolkit />
            )}

          </main>

          {/* Footer */}
          <Footer
            onNavigate={(tab) => setCurrentTab(tab)}
            onOpenAuthenticity={() => {
              setBatchCodeInitial('');
              setIsAuthenticityOpen(true);
            }}
          />

          {/* Mobile-First Bottom Navigation Bar */}
          <MobileBottomNav
            currentTab={currentTab}
            setCurrentTab={setCurrentTab}
            cartCount={cartCount}
            openCart={() => setIsCartOpen(true)}
            openUserDashboard={() => setIsUserDashboardOpen(true)}
            openAuthenticityModal={() => {
              setBatchCodeInitial('');
              setIsAuthenticityOpen(true);
            }}
          />

          {/* Product Comparison Modal */}
          <ProductCompareModal
            isOpen={isCompareOpen}
            onClose={() => setIsCompareOpen(false)}
            compareProducts={compareProducts}
            allProducts={products}
            onRemoveFromCompare={handleRemoveFromCompare}
            onAddToCompare={handleAddToCompare}
            onAddToCart={handleAddToCart}
          />

          {/* Flyout Cart Drawer */}
          <CartDrawer
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            items={cart}
            onUpdateQuantity={handleUpdateCartQuantity}
            onRemoveItem={handleRemoveCartItem}
            onProceedToCheckout={() => setIsCheckoutOpen(true)}
          />

          {/* Secure Checkout & Payment Gateway Modal */}
          <CheckoutModal
            isOpen={isCheckoutOpen}
            onClose={() => setIsCheckoutOpen(false)}
            items={cart}
            onOrderCompleted={handleOrderCompleted}
            onOpenUserDashboard={() => setIsUserDashboardOpen(true)}
          />

          {/* Advanced User Dashboard Modal */}
          <UserDashboard
            isOpen={isUserDashboardOpen}
            onClose={() => setIsUserDashboardOpen(false)}
            orders={orders}
          />

          {/* Authenticity & Batch Code Verification Modal */}
          <AuthenticityChecker
            isOpen={isAuthenticityOpen}
            onClose={() => setIsAuthenticityOpen(false)}
            initialCode={batchCodeInitial}
          />

          {/* Single Product Deep Dive Modal with Smart Bundle Offer */}
          {selectedProduct && (
            <ProductDetailModal
              product={selectedProduct}
              onClose={() => setSelectedProduct(null)}
              onAddToCart={handleAddToCart}
              onAddBundleToCart={handleAddBundleToCart}
              onAddToCompare={handleAddToCompare}
              allProducts={products}
              onSelectProduct={(p) => setSelectedProduct(p)}
              reviews={reviews}
              onAddReview={handleAddReview}
              onOpenAuthenticity={handleCheckBatchCode}
            />
          )}

            </>
          )}

        </div>
      )}

    </div>
  );
}
