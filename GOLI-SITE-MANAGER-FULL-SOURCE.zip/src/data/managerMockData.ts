import { 
  SiteConnection, 
  WordPressPage, 
  ElementorTemplate, 
  WooProduct, 
  WooOrder, 
  SeoAuditItem, 
  MediaItem, 
  SiteHealthMetric, 
  BackupSnapshot, 
  AiAgentTask, 
  ActivityLog 
} from '../types/manager';

export const INITIAL_CONNECTION: SiteConnection = {
  siteUrl: 'https://golikala.com',
  name: 'گلی کالا (بازرگانی گلی)',
  description: 'نماینده رسمی و واردات مستقیم برندهای اروپایی آمالفی، آگرادو و سایرو در ایران',
  status: 'CONNECTED',
  latencyMs: 142,
  wpVersion: '6.7.1',
  wcVersion: '9.4.2',
  elementorVersion: '3.25.1 (Elementor Pro)',
  rankMathVersion: '3.0.75 (Rank Math Pro)',
  activeTheme: 'Bakala Child Theme (سازگار با ووکامرس و المنتور)',
  serverType: 'LiteSpeed Web Server Enterprise',
  phpVersion: '8.2.18 (OPcache فعال)',
  sslActive: true,
  litespeedActive: true,
  lastPingTime: 'هم اکنون (مانیتورینگ زنده فعال)',
};

export const WORDPRESS_PAGES: WordPressPage[] = [
  {
    id: 12,
    title: 'صفحه اصلی گلی کالا (نمایندگی رسمی برندهای اروپایی)',
    slug: 'home',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۵/۱۰',
    modified: 'امروز - ۱۲:۳۰',
    author: 'newadmin',
    rankMathScore: 98,
    focusKeyword: 'نماینده رسمی آمالفی، آگرادو و سایرو در ایران',
    elementorDocType: 'landing'
  },
  {
    id: 48,
    title: 'فروشگاه تخصصی محصولات آرایشی بهداشتی اروپایی',
    slug: 'shop',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۵/۱۲',
    modified: 'دیروز - ۱۸:۴۵',
    author: 'newadmin',
    rankMathScore: 95,
    focusKeyword: 'خرید محصولات اصل آگرادو و آمالفی',
    elementorDocType: 'product-archive'
  },
  {
    id: 104,
    title: 'لندینگ پیج اختصاصی و نمایندگی برند آگرادو اسپانیا (Agrado)',
    slug: 'agrado-spain',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۶/۰۱',
    modified: 'امروز - ۱۰:۱۵',
    author: 'newadmin',
    rankMathScore: 99,
    focusKeyword: 'نماینده رسمی آگرادو اسپانیا در ایران',
    elementorDocType: 'landing'
  },
  {
    id: 112,
    title: 'لندینگ پیج تخصصی مراقبت پوست و بدن آمالفی اسپانیا (Amalfi)',
    slug: 'amalfi-spain',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۶/۰۵',
    modified: '۳ روز پیش',
    author: 'newadmin',
    rankMathScore: 96,
    focusKeyword: 'نماینده رسمی آمالفی اسپانیا',
    elementorDocType: 'landing'
  },
  {
    id: 120,
    title: 'لندینگ پیج درماتولوژی و پوست های حساس سایرو (Syro)',
    slug: 'syro-europe',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۶/۱۰',
    modified: '۴ روز پیش',
    author: 'newadmin',
    rankMathScore: 97,
    focusKeyword: 'نماینده رسمی سایرو در ایران',
    elementorDocType: 'landing'
  },
  {
    id: 88,
    title: 'فروش عمده و همکاری تجاری بازرگانی گلی (B2B Wholesale)',
    slug: 'wholesale',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۶/۱۵',
    modified: '۵ روز پیش',
    author: 'newadmin',
    rankMathScore: 94,
    focusKeyword: 'خرید عمده محصولات آگرادو و آمالفی اصل',
    elementorDocType: 'wp-page'
  },
  {
    id: 72,
    title: 'سامانه استعلام بچ کد و اصالت قطعی کالا',
    slug: 'authenticity-check',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۶/۲۰',
    modified: 'امروز - ۱۱:۰۰',
    author: 'newadmin',
    rankMathScore: 99,
    focusKeyword: 'استعلام بچ کد اصالت کالای اروپایی',
    elementorDocType: 'landing'
  },
  {
    id: 60,
    title: 'وبلاگ و راهنمای تخصصی پوست و مو',
    slug: 'blog',
    status: 'publish',
    isElementor: true,
    template: 'elementor_header_footer',
    date: '۱۴۰۵/۰۵/۲۰',
    modified: 'دیروز',
    author: 'newadmin',
    rankMathScore: 93,
    focusKeyword: 'راهنمای تشخیص کراتین اصل آگرادو',
    elementorDocType: 'wp-page'
  }
];

export const ELEMENTOR_TEMPLATES: ElementorTemplate[] = [
  {
    id: 201,
    title: 'هدر اصلی دسکتاپ و مگامنوی ناوبری لوکس (Goli Header Pro)',
    type: 'header',
    status: 'active',
    instances: 'سراسر سایت (Entire Site)',
    lastEdited: 'امروز - ۱۰:۱۵',
    author: 'newadmin',
    hasCustomCss: true,
    cssLinesCount: 42
  },
  {
    id: 202,
    title: 'هدر اختصاصی و فشرده موبایل (Mobile Floating Header)',
    type: 'header',
    status: 'active',
    instances: 'نمایشگرهای کوچکتر از ۷۶۸ پیکسل',
    lastEdited: 'دیروز - ۱۵:۳۰',
    author: 'newadmin',
    hasCustomCss: true,
    cssLinesCount: 28
  },
  {
    id: 203,
    title: 'فوتر ۴ ستونه هوشمند همراه با نمادهای اطمینان و سرتیفیکیت اروپا',
    type: 'footer',
    status: 'active',
    instances: 'سراسر سایت (Entire Site)',
    lastEdited: '۳ روز پیش',
    author: 'newadmin',
    hasCustomCss: true,
    cssLinesCount: 35
  },
  {
    id: 204,
    title: 'قالب تکی محصولات ووکامرس (Single Product Template - Goli)',
    type: 'single-product',
    status: 'active',
    instances: 'تمام محصولات ووکامرس (All Products)',
    lastEdited: 'امروز - ۱۱:۲۰',
    author: 'newadmin',
    hasCustomCss: true,
    cssLinesCount: 64
  },
  {
    id: 205,
    title: 'سکشن پروموشن جشنواره طلایی کراتین آگرادو',
    type: 'section',
    status: 'active',
    instances: 'صفحه اصلی و لندینگ آگرادو',
    lastEdited: '۴ روز پیش',
    author: 'newadmin',
    hasCustomCss: true,
    cssLinesCount: 19
  }
];

export const WOO_PRODUCTS: WooProduct[] = [
  {
    id: 1001,
    name: 'شامپو کراتین تخصصی آگرادو اسپانیا حجم ۷۵۰ میل',
    sku: 'AGR-KER-750',
    price: 495000,
    regularPrice: 580000,
    salePrice: 495000,
    stockStatus: 'instock',
    stockQuantity: 42,
    brand: 'آگرادو',
    brandEn: 'Agrado',
    category: 'مراقبت مو',
    image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: true,
    wholesalePrice: 410000,
    variationsCount: 1,
    rankMathScore: 98,
    officialAgencyGuaranteed: true
  },
  {
    id: 1002,
    name: 'ماسک مو کراتینه احیا کننده آگرادو حجم ۵۰۰ میل',
    sku: 'AGR-MSK-500',
    price: 430000,
    regularPrice: 510000,
    salePrice: 430000,
    stockStatus: 'instock',
    stockQuantity: 28,
    brand: 'آگرادو',
    brandEn: 'Agrado',
    category: 'مراقبت مو',
    image: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: true,
    wholesalePrice: 355000,
    variationsCount: 1,
    rankMathScore: 96,
    officialAgencyGuaranteed: true
  },
  {
    id: 1003,
    name: 'لوسیون بدن آبرسان و آرامش بخش آمالفی عصاره آلوئه ورا ۵۰۰ میل',
    sku: 'AMF-LOT-ALOE',
    price: 365000,
    regularPrice: 420000,
    salePrice: 365000,
    stockStatus: 'instock',
    stockQuantity: 65,
    brand: 'آمالفی',
    brandEn: 'Amalfi',
    category: 'مراقبت پوست',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: true,
    wholesalePrice: 295000,
    variationsCount: 1,
    rankMathScore: 97,
    officialAgencyGuaranteed: true
  },
  {
    id: 1004,
    name: 'سرم موی مغذی حاوی روغن آرگان خالص آمالفی ۱۰۰ میل',
    sku: 'AMF-SER-ARG',
    price: 395000,
    regularPrice: 470000,
    salePrice: 395000,
    stockStatus: 'instock',
    stockQuantity: 18,
    brand: 'آمالفی',
    brandEn: 'Amalfi',
    category: 'مراقبت مو',
    image: 'https://images.unsplash.com/photo-1608248597359-540b68a6fcf7?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: true,
    wholesalePrice: 320000,
    variationsCount: 1,
    rankMathScore: 95,
    officialAgencyGuaranteed: true
  },
  {
    id: 1005,
    name: 'میسلار واتر پاک کننده تخصصی آرایش سایرو ۴۰۰ میل',
    sku: 'SYR-MIC-400',
    price: 340000,
    regularPrice: 410000,
    salePrice: 340000,
    stockStatus: 'instock',
    stockQuantity: 34,
    brand: 'سایرو',
    brandEn: 'Sairo',
    category: 'مراقبت پوست',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: true,
    wholesalePrice: 275000,
    variationsCount: 1,
    rankMathScore: 96,
    officialAgencyGuaranteed: true
  },
  {
    id: 1006,
    name: 'ژل شستشوی صورت هیدرا فوم سایرو حجم ۲۵۰ میل',
    sku: 'SYR-GEL-250',
    price: 310000,
    regularPrice: 380000,
    salePrice: 310000,
    stockStatus: 'instock',
    stockQuantity: 40,
    brand: 'سایرو',
    brandEn: 'Sairo',
    category: 'مراقبت پوست',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: true,
    wholesalePrice: 250000,
    variationsCount: 1,
    rankMathScore: 95,
    officialAgencyGuaranteed: true
  },
  {
    id: 1007,
    name: 'سرم ویتامین سی روشن کننده گارنیر اصل فرانسه ۳۰ میل',
    sku: 'GAR-VITC-30',
    price: 520000,
    regularPrice: 620000,
    salePrice: 520000,
    stockStatus: 'instock',
    stockQuantity: 15,
    brand: 'سایر برندهای اروپایی',
    brandEn: 'Other',
    category: 'مراقبت پوست',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=400&q=80',
    isWholesaleAvailable: false,
    variationsCount: 1,
    rankMathScore: 94,
    officialAgencyGuaranteed: true
  }
];

export const WOO_ORDERS: WooOrder[] = [
  {
    id: 98214,
    orderNumber: '#GK-98214',
    date: '۱۴ آبان ۱۴۰۵ - ۱۱:۴۵',
    customerName: 'کامران گلی',
    customerPhone: '۰۹۱۲۳۴۵۶۷۸۹',
    total: 1355000,
    status: 'ارسال شده با تیپاکس',
    paymentGateway: 'زرین‌پال (Zarinpal)',
    postTrackingCode: '319482710599281720',
    itemsCount: 3,
    shippingCity: 'تهران'
  },
  {
    id: 98213,
    orderNumber: '#GK-98213',
    date: '۱۴ آبان ۱۴۰۵ - ۰۹:۲۰',
    customerName: 'سالار مرادی',
    customerPhone: '۰۹۳۵۱۱۲۰۴۴۹',
    total: 825000,
    status: 'در حال پردازش',
    paymentGateway: 'شاپرک سامان',
    itemsCount: 2,
    shippingCity: 'شیراز'
  },
  {
    id: 98212,
    orderNumber: '#GK-98212',
    date: '۱۳ آبان ۱۴۰۵ - ۲۲:۱۰',
    customerName: 'فروشگاه زیبایی پریا (سفارش عمده)',
    customerPhone: '۰۹۱۲۹۹۰۴۵۸۲',
    total: 8450000,
    status: 'تکمیل شده',
    paymentGateway: 'واریز به حساب',
    postTrackingCode: 'TIP-8840192801',
    itemsCount: 24,
    shippingCity: 'اصفهان'
  }
];

export const SEO_AUDIT_ITEMS: SeoAuditItem[] = [
  {
    id: 1,
    pageTitle: 'صفحه اصلی گلی کالا | نماینده رسمی آمالفی، آگرادو و سایرو',
    url: 'https://golikala.com/',
    focusKeyword: 'نماینده رسمی آمالفی، آگرادو و سایرو در ایران',
    score: 98,
    issuesCount: 0,
    titleLength: 58,
    descLength: 156,
    canonicalOk: true,
    schemaType: 'Organization + WebSite',
    indexingStatus: 'ایندکس شده در گوگل',
    searchConsoleImpressions: 14200,
    searchConsoleClicks: 1120
  },
  {
    id: 2,
    pageTitle: 'خرید محصولات اصل آگرادو اسپانیا با ضمانت کتبی اصالت',
    url: 'https://golikala.com/agrado-spain/',
    focusKeyword: 'خرید شامپو کراتین آگرادو اصل اسپانیا',
    score: 99,
    issuesCount: 0,
    titleLength: 54,
    descLength: 152,
    canonicalOk: true,
    schemaType: 'ProductCollection + FAQPage',
    indexingStatus: 'ایندکس شده در گوگل',
    searchConsoleImpressions: 8900,
    searchConsoleClicks: 740
  },
  {
    id: 3,
    pageTitle: 'لوسیون و محصولات مراقبت بدن آمالفی ساخت اسپانیا',
    url: 'https://golikala.com/amalfi-spain/',
    focusKeyword: 'نماینده رسمی آمالفی اسپانیا',
    score: 96,
    issuesCount: 1,
    titleLength: 51,
    descLength: 148,
    canonicalOk: true,
    schemaType: 'CollectionPage',
    indexingStatus: 'ایندکس شده در گوگل',
    searchConsoleImpressions: 6300,
    searchConsoleClicks: 490
  }
];

export const MEDIA_ITEMS: MediaItem[] = [
  {
    id: 501,
    title: 'بنر هیرو صفحه اصلی - معرفی نمایندگی رسمی اروپا',
    fileName: 'golikala-hero-official-brands.webp',
    url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1200&q=80',
    width: 1920,
    height: 1080,
    fileSizeKb: 148,
    format: 'webp',
    altText: 'نماینده رسمی محصولات اروپایی آمالفی، آگرادو و سایرو در ایران - گلی کالا',
    hasAlt: true,
    isOversized: false
  },
  {
    id: 502,
    title: 'شامپو کراتین تخصصی آگرادو اسپانیا حجم ۷۵۰ میل',
    fileName: 'agrado-keratin-shampoo-750ml.webp',
    url: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80',
    width: 800,
    height: 800,
    fileSizeKb: 74,
    format: 'webp',
    altText: 'شامپو کراتین آگرادو اصل اسپانیا ۷۵۰ میلی لیتر با برچسب اصالت بازرگانی گلی',
    hasAlt: true,
    isOversized: false,
    associatedProduct: 'شامپو کراتین آگرادو'
  },
  {
    id: 503,
    title: 'لوسیون بدن آلوئه ورا آمالفی اصل اسپانیا',
    fileName: 'amalfi-aloe-body-lotion-500ml.webp',
    url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
    width: 800,
    height: 800,
    fileSizeKb: 82,
    format: 'webp',
    altText: 'لوسیون بدن آبرسان آلوئه ورا آمالفی ساخت والنسیا اسپانیا',
    hasAlt: true,
    isOversized: false,
    associatedProduct: 'لوسیون آمالفی'
  },
  {
    id: 504,
    title: 'میسلار واتر پاک کننده تخصصی سایرو اروپا',
    fileName: 'syro-micellar-water-sensitive.webp',
    url: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80',
    width: 800,
    height: 800,
    fileSizeKb: 69,
    format: 'webp',
    altText: 'میسلار واتر سایرو اصل برای پوست های بسیار حساس',
    hasAlt: true,
    isOversized: false,
    associatedProduct: 'میسلار سایرو'
  }
];

export const SITE_HEALTH_METRICS: SiteHealthMetric[] = [
  {
    id: 'ttfb',
    title: 'زمان پاسخ اولیه سرور (TTFB)',
    value: '۲۴۰ میلی‌ثانیه',
    status: 'good',
    recommendation: 'وضعیت عالی. وب‌سرور لایت‌اسپید روی پورت‌های HTTP/3 با سرعت پاسخ می‌دهد.',
    category: 'performance'
  },
  {
    id: 'lcp',
    title: 'سرعت رندر بزرگترین عنصر (LCP)',
    value: '۱.۷ ثانیه',
    status: 'good',
    recommendation: 'بسیار خوب. تصویر هیرو به فرمت فشرده WebP لود می‌شود و اولویت بالا (fetchpriority=high) دارد.',
    category: 'performance'
  },
  {
    id: 'cls',
    title: 'شاخص جابجایی تجمعی چیدمان (CLS)',
    value: '۰.۰۲',
    status: 'good',
    recommendation: 'ایده‌آل. ابعاد صریح برای بنرها و کارت‌های ووکامرس تعریف شده و پرش المان‌ها حذف شده است.',
    category: 'performance'
  },
  {
    id: 'inp',
    title: 'تعامل با صفحه (INP / FID)',
    value: '۳۸ میلی‌ثانیه',
    status: 'good',
    recommendation: 'پاسخ لمسی و کلیک فوق‌العاده سریع بدون تاخیر در رشته اصلی جاوااسکریپت.',
    category: 'performance'
  },
  {
    id: 'litespeed_cache',
    title: 'پیکربندی افزونه LiteSpeed Cache',
    value: 'کش صفحات و بهینه‌سازی CSS/JS فعال',
    status: 'good',
    recommendation: 'تنظیمات همگام با کش سرور بدون اختلال در سبد خرید و صفحات حساب کاربری.',
    category: 'compatibility'
  },
  {
    id: 'php_security',
    title: 'نسخه PHP و امنیت سرور',
    value: 'PHP 8.2.18 امن و پایدار',
    status: 'good',
    recommendation: 'دسترسی XML-RPC غیرفعال است و گزارش خطاهای عمومی در فرانت‌اند خاموش است.',
    category: 'security'
  }
];

export const BACKUP_SNAPSHOTS: BackupSnapshot[] = [
  {
    id: 'SNAP-20261104-01',
    name: 'نسخه پشتیبان تایید شده - کدهای سفارشی و تنظیمات المنتور صفحه اصلی',
    type: 'elementor_document',
    target: 'صفحه اصلی (ID: 12)',
    date: 'امروز - ۱۲:۳۰',
    author: 'Goli AI Agent (Verified)',
    sizeKb: 184,
    verified: true,
    canRollback: true
  },
  {
    id: 'SNAP-20261104-02',
    name: 'پشتیبان کدهای CSS اختصاصی استایل‌های گلیکالا',
    type: 'custom_css',
    target: 'تنظیمات سراسری Custom CSS',
    date: 'امروز - ۱۰:۱۵',
    author: 'newadmin',
    sizeKb: 28,
    verified: true,
    canRollback: true
  },
  {
    id: 'SNAP-20261103-01',
    name: 'نسخه پیش از بهینه‌سازی قالب محصول تکی ووکامرس',
    type: 'elementor_document',
    target: 'قالب Single Product (ID: 204)',
    date: 'دیروز - ۱۸:۴۵',
    author: 'newadmin',
    sizeKb: 142,
    verified: true,
    canRollback: true
  }
];

export const AI_AGENT_TASKS: AiAgentTask[] = [
  {
    id: 'TASK-101',
    prompt: 'بازطراحی هیرو بنر صفحه اصلی با پالت رسمی سبز جنگلی، طلایی و عاجی گلیکالا',
    timestamp: 'امروز - ۱۲:۲۸',
    targetArea: 'صفحه اصلی (Elementor Header & Hero)',
    riskLevel: 'پایین',
    status: 'اجرا شده در وبسایت',
    planSummary: 'ساختار کانتینر فلکس‌باکس با پالت رنگ رسمی گلیکالا و تاییدیه‌های اصالت آگرادو، آمالفی و سایرو تنظیم گردید.',
    steps: [
      'ایجاد نقطه بازگشت (Snapshot SNAP-20261104-01)',
      'اعمال پالت رنگی #0f382c و #d4af37',
      'تست عدم تداخل با ویجت‌های ووکامرس',
      'ذخیره در دیتابیس المنتور'
    ],
    requiresApproval: true,
    dryRunVerified: true
  },
  {
    id: 'TASK-102',
    prompt: 'بررسی سلامت سئوی صفحه نمایندگی رسمی آگرادو و تصحیح متادسکریپشن رنک‌مث',
    timestamp: 'امروز - ۱۰:۱۲',
    targetArea: 'برگه نمایندگی آگرادو اسپانیا (Rank Math SEO)',
    riskLevel: 'پایین',
    status: 'اجرا شده در وبسایت',
    planSummary: 'کلمه کلیدی کانونی "نماینده رسمی آگرادو اسپانیا در ایران" بهینه شد و نمره سئو به ۹۹/۱۰۰ رسید.',
    steps: [
      'تحلیل چگالی کلمات کلیدی و ساختار H1 تا H3',
      'بررسی تگ‌های OpenGraph و Schema',
      'به‌روزرسانی عنوان سئو و متا در وردپرس'
    ],
    requiresApproval: false,
    dryRunVerified: true
  }
];

export const ACTIVITY_LOGS: ActivityLog[] = [
  {
    id: 'LOG-301',
    timestamp: 'امروز - ۱۲:۳۰',
    user: 'newadmin (Goli AI Agent)',
    module: 'Goli Design Studio',
    action: 'به‌روزرسانی استایل‌های کانتینر هیرو بنر صفحه اصلی',
    status: 'success',
    details: 'اعمال کدهای CSS بهینه با پالت سبز جنگلی و طلایی بدون تداخل با لایت‌اسپید.'
  },
  {
    id: 'LOG-302',
    timestamp: 'امروز - ۱۱:۴۵',
    user: 'سیستم خودکار ووکامرس',
    module: 'Goli Commerce',
    action: 'ثبت سفارش جدید #GK-98214 با پرداخت موفق زرین‌پال',
    status: 'success',
    details: 'ارسال خودکار پیامک رهگیری به خریدار (کامران گلی) و کسر موجودی از انبار مرکزی.'
  },
  {
    id: 'LOG-303',
    timestamp: 'امروز - ۱۰:۱۵',
    user: 'newadmin',
    module: 'Goli SEO Intelligence',
    action: 'تایید و ذخیره اسکیما ساختاریافته JSON-LD صفحه اصلی',
    status: 'success',
    details: 'تست موفق در Rich Results Test گوگل برای اسکیمای سازمان و وب‌سایت.'
  }
];

export const COMPANION_PLUGIN_CODE = `<?php
/**
 * Plugin Name: Goli Site Manager Companion Bridge
 * Plugin URI:  https://golikala.com
 * Description: رابط امن، مجاز و اختصاصی اتصال پلتفرم هوش مصنوعی GOLI SITE MANAGER به وردپرس و المنتور گلیکالا.
 * Version:     1.0.0
 * Author:      بازرگانی گلی (Goli Management Team)
 * License:     GPL-2.0+
 * Text Domain: goli-companion
 */

if (!defined('ABSPATH')) {
    exit; // خروج در صورت دسترسی مستقیم
}

class Goli_Companion_Bridge {

    const REST_NAMESPACE = 'goli-manager/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_secure_routes'));
    }

    /**
     * ثبت مسیرهای REST API امن
     */
    public function register_secure_routes() {
        // ۱. بررسی سلامت و دریافت متادیتاهای المنتور و ووکامرس
        register_rest_route(self::REST_NAMESPACE, '/status', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_system_status'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));

        // ۲. خواندن داده‌های سندی المنتور بدون تخریب
        register_rest_route(self::REST_NAMESPACE, '/elementor/get-document/(?P<id>\\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_elementor_document'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));

        // ۳. به‌روزرسانی امن المنتور به همراه پشتیبان‌گیری خودکار
        register_rest_route(self::REST_NAMESPACE, '/elementor/update-document', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'update_elementor_document_safely'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));
    }

    /**
     * اعتبارسنجی سطح دسترسی کاربر ارشد وردپرس
     */
    public function check_admin_permissions() {
        return current_user_can('manage_options');
    }

    /**
     * بررسی وضعیت زنده وردپرس، المنتور و ووکامرس
     */
    public function get_system_status() {
        return rest_ensure_response(array(
            'status'           => 'OK',
            'site_url'         => get_site_url(),
            'wp_version'       => get_bloginfo('version'),
            'is_elementor_pro' => defined('ELEMENTOR_PRO_VERSION'),
            'is_woocommerce'   => class_exists('WooCommerce'),
            'is_rank_math'     => class_exists('RankMath'),
            'php_version'      => phpversion(),
            'server_time'      => current_time('mysql'),
        ));
    }

    /**
     * استخراج داده‌های سند المنتور
     */
    public function get_elementor_document($request) {
        $post_id = $request->get_param('id');
        $data = get_post_meta($post_id, '_elementor_data', true);
        return rest_ensure_response(array(
            'post_id' => $post_id,
            'data'    => json_decode($data, true),
        ));
    }

    /**
     * به‌روزرسانی امن سند المنتور با ثبت نقطه بازگشت
     */
    public function update_elementor_document_safely($request) {
        $params  = $request->get_json_params();
        $post_id = isset($params['post_id']) ? intval($params['post_id']) : 0;
        $content = isset($params['data']) ? $params['data'] : null;

        if (!$post_id || !$content) {
            return new WP_Error('invalid_data', 'شناسه پست یا داده‌های ارسالی نامعتبر است.', array('status' => 400));
        }

        // ایجاد پشتیبان خودکار در متادیتای وردپرس قبل از اعمال
        $current_data = get_post_meta($post_id, '_elementor_data', true);
        update_post_meta($post_id, '_goli_backup_' . time(), $current_data);

        // اعمال ایمن
        update_post_meta($post_id, '_elementor_data', wp_slash(json_encode($content)));
        
        // پاکسازی کش لایت‌اسپید برای این برگه
        if (has_action('litespeed_purge_post')) {
            do_action('litespeed_purge_post', $post_id);
        }

        return rest_ensure_response(array(
            'success'   => true,
            'message'   => 'سند المنتور با موفقیت به‌روزرسانی و کش پاکسازی شد.',
            'backup_id' => '_goli_backup_' . time()
        ));
    }
}

new Goli_Companion_Bridge();
`;
