import { Product, BlogPost, Order, Review } from '../types';

export const OFFICIAL_BRANDS = [
  {
    name: 'آمالفی',
    nameEn: 'Amalfi',
    country: 'اسپانیا (اتحادیه اروپا)',
    countryCode: 'ES',
    description: 'برند نام آشنای اسپانیایی با بیش از ۵۰ سال سابقه در تولید محصولات بهداشتی، شامپوهای تخصصی و لوسیون های مغذی بدن با استاندارد های بین المللی.',
    banner: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=1200&q=80',
    logo: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=300&q=80',
    badge: 'نماینده رسمی و انحصاری در ایران',
    productCount: 28,
  },
  {
    name: 'آگرادو',
    nameEn: 'Agrado',
    country: 'اسپانیا (اتحادیه اروپا)',
    countryCode: 'ES',
    description: 'تخصصی ترین برند مراقبت از مو و پوست اروپا با فرمولاسیون غنی از کراتین هیدرولیز شده و روغن آرگان برای ترمیم موهای آسیب دیده و خشک.',
    banner: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=1200&q=80',
    logo: 'https://images.unsplash.com/photo-1608248597359-540b68a6fcf7?auto=format&fit=crop&w=300&q=80',
    badge: 'نماینده رسمی و واردات مستقیم',
    productCount: 34,
  },
  {
    name: 'سایرو',
    nameEn: 'Syro',
    country: 'ایتالیا و اروپا',
    countryCode: 'IT',
    description: 'پیشرو در نوآوری های درماتولوژی، شوینده های صورت ضد حساسیت و میسلار واتر های تخصصی مناسب انواع تیپ های پوستی حساس.',
    banner: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=1200&q=80',
    logo: 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=300&q=80',
    badge: 'نماینده رسمی و ثبت کد اصالت',
    productCount: 22,
  },
];

export const PRODUCTS_DATA: Product[] = [
  {
    id: 'agrado-keratin-shampoo',
    name: 'شامپو کراتین تخصصی آگرادو اسپانیا حجم ۷۵۰ میل',
    originalName: 'Agrado Keratin Professional Hair Shampoo 750ml',
    brand: 'آگرادو',
    brandEn: 'Agrado',
    category: 'مراقبت مو',
    price: 495000,
    oldPrice: 580000,
    discountPercent: 15,
    rating: 4.9,
    reviewsCount: 142,
    stock: 25,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اسپانیا',
    image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1608248597359-540b68a6fcf7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
    ],
    shortDescription: 'شامپو کراتین اصل آگرادو تولید کشور اسپانیا ، سرشار از کراتین هیدرولیز شده برای نرم کنندگی فوق العاده و احیای ساقه های شکننده مو با ضمانت کتبی اصالت گلی کالا.',
    fullDescription: 'شامپو کراتین آگرادو یکی از معروف ترین محصولات مراقبت مو در اروپا می باشد. این شامپو با فرمول تخصصی غنی شده از کراتین خالص ، ساختار کوتیکول مو را ترمیم نموده و از وز شدن و شکنندگی موهای رنگ شده و کراتین شده جلوگیری می کند. واردات مستقیم توسط گلی کالا به عنوان نماینده رسمی آگرادو در ایران صورت گرفته و دارای بارکد اصالت و بچ کد تایید شده آزمایشگاهی اسپانیا می باشد.',
    features: [
      'حاوی کراتین هیدرولیز شده درجه یک اروپایی',
      'مناسب موهای آسیب دیده ، کراتین شده و رنگ شده',
      'تثبیت کننده رطوبت طبیعی مو و رفع خشکی ساقه',
      'فاقد پارابن و نمک های سنگین تخریب کننده کراتین',
      'دارای تاییدیه رسمی آزمایشگاه های درماتولوژی اتحادیه اروپا',
      'حجم به صرفه و غلیظ ۷۵۰ میلی لیتر'
    ],
    specifications: {
      'کشور سازنده': 'اسپانیا',
      'حجم': '۷۵۰ میلی لیتر',
      'ترکیب اصلی': 'کراتین خالص هیدرولیز شده',
      'نوع مو': 'موهای خشک ، رنگ شده و کراتینه',
      'صادر کننده مجوز': 'سازمان غذا و دارو اتحادیه اروپا',
      'بچ کد معتبر': 'AGR-2026-SP882'
    },
    batchCodeExample: 'ES-AGR-882941',
    complementaryProductIds: ['agrado-keratin-mask', 'amalfi-argan-serum'],
    rankMathSeo: {
      focusKeyword: 'شامپو کراتین آگرادو اصل اسپانیا',
      seoTitle: 'خرید شامپو کراتین آگرادو اصل اسپانیا ۷۵۰ میل با ضمانت اصالت | گلی کالا',
      metaDescription: 'خرید اینترنتی شامپو کراتین آگرادو اورجینال از نماینده رسمی در ایران گلی کالا. دارای بچ کد اصالت ، قیمت تضمینی و ارسال سریع به سراسر کشور.',
      score: 98
    }
  },
  {
    id: 'agrado-keratin-mask',
    name: 'ماسک مو کراتینه احیا کننده آگرادو حجم ۵۰۰ میل',
    originalName: 'Agrado Keratin Hair Treatment Mask 500ml',
    brand: 'آگرادو',
    brandEn: 'Agrado',
    category: 'مراقبت مو',
    price: 430000,
    oldPrice: 510000,
    discountPercent: 16,
    rating: 4.8,
    reviewsCount: 98,
    stock: 18,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اسپانیا',
    image: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'ماسک موی فوق مغذی کراتین آگرادو اسپانیا برای درمان قطعی موخوره ، زبری و سوختگی ناشی از دکلره با ضمانت اصالت ۱۰۰ درصدی.',
    fullDescription: 'ماسک داخل حمام کراتین آگرادو محصولی معجزه آسا جهت بازسازی کوتیکول موهای آسیب دیده است. ترکیب کراتین فعال با نفوذ به عمق تار مو ، استحکام کشسانی مو را تا ۸۵ درصد بهبود می دهد. مکمل عالی برای استفاده به همراه شامپو کراتین آگرادو می باشد.',
    features: [
      'نرم کنندگی ابریشمی فوری در اولین بار مصرف',
      'تغذیه عمقی ریشه و ساقه بدون ایجاد سنگینی روی مو',
      'پیشگیری موثر از دوشاخه شدن و موخوره',
      'محصول اورجینال اسپانیا با برچسب اصالت اختصاصی'
    ],
    specifications: {
      'کشور سازنده': 'اسپانیا',
      'حجم': '۵۰۰ میلی لیتر',
      'نحوه مصرف': 'داخل حمام با ۵ دقیقه مکث و آبکشی',
      'مناسب برای': 'موهای آسیب دیده و خشک'
    },
    batchCodeExample: 'ES-AGR-441092',
    complementaryProductIds: ['agrado-keratin-shampoo', 'amalfi-argan-serum'],
    rankMathSeo: {
      focusKeyword: 'ماسک مو کراتین آگرادو',
      seoTitle: 'ماسک مو کراتین آگرادو اصل اسپانیا ۵۰۰ میل | تضمین اصالت گلی کالا',
      metaDescription: 'قیمت و خرید آنلاین ماسک مو کراتینه آگرادو اسپانیایی در گلی کالا نماینده رسمی برند آگرادو با ضمانت تعویض و بازگشت وجه.',
      score: 96
    }
  },
  {
    id: 'amalfi-body-lotion-aloe',
    name: 'لوسیون بدن آبرسان و آرامش بخش آمالفی عصاره آلوئه ورا ۵۰۰ میل',
    originalName: 'Amalfi Aloe Vera Soothing Body Lotion 500ml',
    brand: 'آمالفی',
    brandEn: 'Amalfi',
    category: 'مراقبت پوست',
    price: 365000,
    oldPrice: 420000,
    discountPercent: 13,
    rating: 4.9,
    reviewsCount: 114,
    stock: 40,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اسپانیا',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1608248597359-540b68a6fcf7?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'لوسیون بدن آمالفی اسپانیا با عصاره غنی آلوئه ورا ارگانیک برای رفع سریع خشکی ، التهاب پوستی و خارش بدن با بافت سبک و جذب فوری.',
    fullDescription: 'لوسیون بدن آمالفی ساخت کارخانجات معتبر کویرمد در والنسیا اسپانیا می باشد. فرمولاسیون طبیعی این محصول احساس مخملی و شادابی بی نظیر به پوست هدیه می دهد. رایحه ملایم و ماندگار اروپایی در کنار جذب سریع بدون حس چربی از برترین مزایای رقابتی این لوسیون است.',
    features: [
      'جذب سریع زیر ۳۰ ثانیه بدون چسبندگی',
      'حاوی ژل تازه آلوئه ورا و ویتامین E',
      'آبرسانی پیوسته ۲۴ ساعته سلول های اپیدرم',
      'مناسب مصرف روزانه بعد از استحمام'
    ],
    specifications: {
      'کشور سازنده': 'اسپانیا',
      'حجم': '۵۰۰ میلی لیتر',
      'ترکیبات موثر': 'آلوئه ورا طبیعی و روغن بادام شیرین',
      'رایحه': 'طبیعی و ملایم خنک'
    },
    batchCodeExample: 'ES-AMF-331902',
    complementaryProductIds: ['amalfi-argan-serum', 'syro-micellar-water'],
    rankMathSeo: {
      focusKeyword: 'لوسیون بدن آمالفی اصل اسپانیا',
      seoTitle: 'خرید لوسیون بدن آلوئه ورا آمالفی اسپانیا | نماینده رسمی گلی کالا',
      metaDescription: 'خرید لوسیون بدن آمالفی اورجینال اسپانیا با قیمت عمده و ضمانت بی قید و شرط اصالت فیزیکی کالا در فروشگاه معتبر گلی کالا.',
      score: 97
    }
  },
  {
    id: 'amalfi-argan-serum',
    name: 'سرم موی مغذی حاوی روغن آرگان خالص آمالفی ۱۰۰ میل',
    originalName: 'Amalfi Argan Oil Hair Elixir Serum 100ml',
    brand: 'آمالفی',
    brandEn: 'Amalfi',
    category: 'مراقبت مو',
    price: 395000,
    oldPrice: 470000,
    discountPercent: 16,
    rating: 4.9,
    reviewsCount: 87,
    stock: 15,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اسپانیا',
    image: 'https://images.unsplash.com/photo-1608248597359-540b68a6fcf7?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1608248597359-540b68a6fcf7?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'سرم مو آرگان آمالفی اصل اسپانیا درخشان کننده طبیعی ، محافظ حرارتی در برابر سشوار و اتوی مو و برطرف کننده فوری گره مو.',
    fullDescription: 'روغن آرگان مراکشی غنی شده آمالفی با تکنولوژی پیشرفته در اسپانیا فرموله گردیده است. این سرم محافظ لایه خارجی تارهای مو در دمای بالای ۲۲۰ درجه سانتی گراد است و مانع از کدر شدن و سوختگی بافت مو می شود.',
    features: [
      'محافظت حرارتی فوق العاده قبل از سشوار و براشینگ',
      'درخشش چشمگیر بدون چرب کردن مو',
      'غنی از اسید های چرب امگا ۶ و ۹ و آنتی اکسیدان',
      'بدون الکل خشک کننده مو'
    ],
    specifications: {
      'کشور سازنده': 'اسپانیا',
      'حجم': '۱۰۰ میلی لیتر',
      'فرمول': 'روغن آرگان خالص فشرده سرد',
      'ماندگاری اثر': '۴۸ ساعت'
    },
    batchCodeExample: 'ES-AMF-881204',
    complementaryProductIds: ['agrado-keratin-shampoo', 'agrado-keratin-mask'],
    rankMathSeo: {
      focusKeyword: 'سرم آرگان آمالفی اصل',
      seoTitle: 'خرید سرم مو آرگان آمالفی اصل اسپانیا ۱۰۰ میل | گلی کالا',
      metaDescription: 'سرم موی آرگان آمالفی ساخت اسپانیا با اصالت قطعی از نماینده رسمی در ایران. مشاهده قیمت ، نقد و بررسی و ارسال فوری در گلی کالا.',
      score: 95
    }
  },
  {
    id: 'syro-micellar-water',
    name: 'میسلار واتر پاک کننده تخصصی آرایش سایرو ۴۰۰ میل',
    originalName: 'Syro Sensitive Skin Cleansing Micellar Water 400ml',
    brand: 'سایرو',
    brandEn: 'Syro',
    category: 'مراقبت پوست',
    price: 340000,
    oldPrice: 410000,
    discountPercent: 17,
    rating: 4.8,
    reviewsCount: 76,
    stock: 22,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اروپا',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'میسلار واتر ملایم سایرو پاک کننده ۲ در ۱ آرایش چشم ، لب و صورت با فناوری میسل های جاذب بدون نیاز به شستشوی خشن.',
    fullDescription: 'میسلار واتر برند اروپایی سایرو مناسب حتی حساس ترین پوست ها طراحی شده است. ذرات میسل روغنی با اتصال به آلودگی ها و مواد آرایشی ضد آب آنها را بدون سوزش چشم از بین می برند. این محصول توسط درماتولوژیست های برجسته اروپایی تست و تایید شده است.',
    features: [
      'پاک کننده کامل آرایش ضد آب حتی ریمل ۲۴ ساعته',
      'تسکین دهنده پوست ملتهب و قرمز',
      'بدون عطر مصنوعی و الکل مضر',
      'دارای استانداردهای سختگیرانه آزمایشگاهی اتحادیه اروپا'
    ],
    specifications: {
      'کشور سازنده': 'اتحادیه اروپا',
      'حجم': '۴۰۰ میلی لیتر',
      'نوع پوست': 'انواع پوست به ویژه پوست های به شدت حساس',
      'PH': 'سازگار با پی اچ طبیعی اشک چشم ۵.۵'
    },
    batchCodeExample: 'EU-SYR-552910',
    complementaryProductIds: ['syro-hydra-gel-wash', 'amalfi-body-lotion-aloe'],
    rankMathSeo: {
      focusKeyword: 'میسلار واتر سایرو اصل',
      seoTitle: 'خرید میسلار واتر سایرو اروپایی اصل ۴۰۰ میل با ضمانت | گلی کالا',
      metaDescription: 'خرید میسلار واتر سایرو Syro اروپایی اصل با برچسب اصالت کالا و استعلام بچ کد آزمایشگاهی از نماینده رسمی در گلی کالا.',
      score: 96
    }
  },
  {
    id: 'syro-hydra-gel-wash',
    name: 'ژل شستشوی صورت هیدرا فوم سایرو حجم ۲۵۰ میل',
    originalName: 'Syro Deep Hydrating Facial Cleansing Gel 250ml',
    brand: 'سایرو',
    brandEn: 'Syro',
    category: 'مراقبت پوست',
    price: 310000,
    oldPrice: 380000,
    discountPercent: 18,
    rating: 4.7,
    reviewsCount: 63,
    stock: 30,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اروپا',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'ژل شستشوی عمیق منافذ با ایجاد کف سبک و غنی شده با هیالورونیک اسید برای حفظ رطوبت پوست بعد از شستشو.',
    fullDescription: 'شستشوی روزانه صورت با صابون های سنتی پی اچ پوست را اسیدی و تخریب می نماید. ژل شستشوی صورت سایرو با فرمولاسیون هایپوآلرژنیک پاکسازی ملایم را بدون حس کشیدگی و خشکی رقم می زند.',
    features: [
      'حاوی هیالورونیک اسید آبرسان سلولی',
      'پاکسازی عمیق چربی های اکسید شده منافذ',
      'احساس سبکی و شادابی طولانی مدت',
      'تایید شده توسط متخصصان پوست اروپا'
    ],
    specifications: {
      'کشور سازنده': 'اتحادیه اروپا',
      'حجم': '۲۵۰ میلی لیتر',
      'سازگاری': 'پوست مختلط تا چرب و نرمال'
    },
    batchCodeExample: 'EU-SYR-992011',
    complementaryProductIds: ['syro-micellar-water'],
    rankMathSeo: {
      focusKeyword: 'ژل شستشو سایرو اصل',
      seoTitle: 'خرید ژل شستشوی صورت هیدرا سایرو اصل اروپا | گلی کالا',
      metaDescription: 'ژل شستشوی صورت سایرو اصل با هیالورونیک اسید برای پاکسازی عمقی منافذ در گلی کالا با تضمین اصالت و ضمانت بازگشت وجه.',
      score: 95
    }
  },
  {
    id: 'garnier-vitamin-c-serum',
    name: 'سرم ویتامین سی روشن کننده گارنیر اصل فرانسه ۳۰ میل',
    originalName: 'Garnier SkinActive Vitamin C Anti-Dark Spot Serum 30ml',
    brand: 'سایر برندهای اروپایی',
    brandEn: 'Other',
    category: 'مراقبت پوست',
    price: 520000,
    oldPrice: 620000,
    discountPercent: 16,
    rating: 4.9,
    reviewsCount: 189,
    stock: 12,
    isOfficialAgency: false,
    authenticityGuaranteed: true,
    originCountry: 'فرانسه',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'سرم روشن کننده ضد لک ویتامین سی گارنیر اورجینال فرانسه با غلظت بالای ۳.۵ درصد ویتامین سی و نیاسینامید برای رفع لک های قهوه ای.',
    fullDescription: 'محصولات خارجی موجود در گلی کالا همگی به همراه ضمانت قطعی اصالت و فاکتور رسمی عرضه می شوند. سرم ویتامین سی گارنیر تولید شده در فرانسه یکی از پرفروش ترین سرم های روشن کننده و ضد پیری در بازارهای جهانی است.',
    features: [
      'کاهش محسوس لک های قهوه ای ظرف ۶ روز',
      'حاوی ترکیب طلایی ویتامین سی ، نیاسینامید و سالیسیلیک اسید',
      'بافت زودجذب و غیر چسبنده',
      'ضمانت اصالت ۱۰۰ درصدی گلی کالا با بررسی بچ کد'
    ],
    specifications: {
      'کشور سازنده': 'فرانسه',
      'حجم': '۳۰ میلی لیتر',
      'کاربرد': 'رفع تیرگی ، لک های آفتاب و جای جوش'
    },
    batchCodeExample: 'FR-GAR-781923',
    complementaryProductIds: ['syro-micellar-water', 'amalfi-body-lotion-aloe'],
    rankMathSeo: {
      focusKeyword: 'سرم ویتامین سی گارنیر اصل فرانسه',
      seoTitle: 'خرید سرم ویتامین سی گارنیر اصل فرانسه با ضمانت اصالت | گلی کالا',
      metaDescription: 'سرم ویتامین سی اصل گارنیر ساخت فرانسه با تضمین قطعی اصالت کالا و ارسال سریع به سراسر ایران در فروشگاه گلی کالا.',
      score: 94
    }
  },
  {
    id: 'amalfi-shower-gel-coconut',
    name: 'شامپو بدن مغذی کرمی آمالفی با عصاره نارگیل ۷۵۰ میل',
    originalName: 'Amalfi Creamy Coconut Body Bath Gel 750ml',
    brand: 'آمالفی',
    brandEn: 'Amalfi',
    category: 'بهداشت بدن',
    price: 330000,
    oldPrice: 390000,
    discountPercent: 15,
    rating: 4.8,
    reviewsCount: 88,
    stock: 35,
    isOfficialAgency: true,
    authenticityGuaranteed: true,
    originCountry: 'اسپانیا',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'شامپو بدن کرمی آمالفی اسپانیا با رایحه دلنشین نارگیل استوایی و خواص رطوبت رسانی قوی برای داشتن پوستی نرم و با لطافت ابریشم.',
    fullDescription: 'شامپو بدن کرمی آمالفی شوینده ای لوکس و غلیظ است که کف بسیار ملایمی تولید می کند. فرمول غنی آن چربی طبیعی پوست را حفظ کرده و احساس طراوت و شادابی ماندگاری در طول روز به شما می بخشد.',
    features: [
      'کف بسیار ابریشمی و رایحه بی نظیر نارگیل تازه',
      'جلوگیری از خشکی و کشیدگی پوست پس از حمام',
      'حجم اقتصادی و با صرفه ۷۵۰ میلی لیتر',
      'دارای برچسب شبنم اصالت واردات رسمی'
    ],
    specifications: {
      'کشور سازنده': 'اسپانیا',
      'حجم': '۷۵۰ میلی لیتر',
      'نوع محصول': 'ژل حمام کرمی'
    },
    batchCodeExample: 'ES-AMF-667104',
    complementaryProductIds: ['amalfi-body-lotion-aloe'],
    rankMathSeo: {
      focusKeyword: 'شامپو بدن آمالفی اسپانیا',
      seoTitle: 'خرید شامپو بدن نارگیل آمالفی اسپانیا ۷۵۰ میل | نماینده گلی کالا',
      metaDescription: 'قیمت و خرید آنلاین شامپو بدن کرمی آمالفی اسپانیا با رایحه نارگیل اصل در فروشگاه گلی کالا نماینده رسمی برند در ایران.',
      score: 95
    }
  }
];

export const REVIEWS_DATA: Review[] = [
  {
    id: 'rev-1',
    productId: 'agrado-keratin-shampoo',
    userName: 'سارا مقدم',
    rating: 5,
    date: '۲ روز پیش',
    comment: 'من موهامو کراتین کرده بودم و همیشه نگران فیک بودن شامپوها بودم. از گلی کالا خریدم بچ کدشو استعلام گرفتم دقیقا سرتیفیکیت اسپانیا تایید شد. موهام به شدت نرم و بدون وز مونده. واقعا از بابت اصالت خیالم راحت شد.',
    verifiedPurchase: true,
    confirmedAuthentic: true,
    pros: ['اصالت کاملا تایید شده با بچ کد', 'کف عالی و بدون آسیب به کراتین', 'بسته بندی محکم ضد ضربه'],
    cons: ['ای کاش سایز یک لیتری هم موجود بشه']
  },
  {
    id: 'rev-2',
    productId: 'agrado-keratin-shampoo',
    userName: 'مهرداد رضایی',
    rating: 5,
    date: '۵ روز پیش',
    comment: 'نماینده رسمی بودن گلی کالا کاملا مشخصه چون قیمت هاش نسبت به پیج های اینستاگرام خیلی منطقی تره و لیبل اصالت کالا و برچسب شبنم داره. تبریک میگم به این مدیریت درجه یک.',
    verifiedPurchase: true,
    confirmedAuthentic: true,
    pros: ['قیمت منصفانه نمایندگی', 'ارسال بسیار سریع تیپاکس']
  },
  {
    id: 'rev-3',
    productId: 'amalfi-body-lotion-aloe',
    userName: 'الهام سمیعی',
    rating: 5,
    date: '۱ هفته پیش',
    comment: 'لوسیون آمالفی بوی بهشت میده! اصلا چرب نیست و سریع جذب پوست میشه. برای پوست من که اگزماییه بهترین انتخابی بود که داشتم.',
    verifiedPurchase: true,
    confirmedAuthentic: true,
    pros: ['جذب فوری زیر یک دقیقه', 'بدون سوزش و حساسیت', 'بسته بندی شیک اسپانیایی']
  },
  {
    id: 'rev-4',
    productId: 'syro-micellar-water',
    userName: 'نگین کریمی',
    rating: 5,
    date: '۳ روز پیش',
    comment: 'میسلار سایرو حتی خط چشم های ضد آب رو بدون کشیدن پوست پاک میکنه و چشمام قرمز نمیشه. بچ کد روی بطری رو در بخش استعلام سایت زدم و مستقیما ثبت شد.',
    verifiedPurchase: true,
    confirmedAuthentic: true,
    pros: ['بدون سوزش چشم', 'حجم عالی و با صرفه']
  }
];

export const BLOG_POSTS_DATA: BlogPost[] = [
  {
    id: 'amalfi-agrado-syro-guide',
    title: 'راهنمای جامع شناخت محصولات آمالفی ، آگرادو و سایرو : چرا برندهای اروپایی گلی کالا رتبه اول مراقبت مو و پوست هستند ؟',
    slug: 'amalfi-agrado-syro-ultimate-guide',
    brandFocus: 'راهنمای جامع',
    publishDate: '۱۴ آبان ۱۴۰۵',
    readTime: '۶ دقیقه مطالعه',
    author: 'تیم تخصصی درماتولوژی گلی کالا',
    coverImage: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1200&q=80',
    summary: 'بررسی مقایسه ای ترکیبات فعال ، نحوه اثرگذاری و استانداردهای سختگیرانه اتحادیه اروپا در محصولات وارداتی رسمی گلی کالا.',
    keywords: ['نماینده رسمی آمالفی', 'نماینده رسمی آگرادو', 'نماینده رسمی سایرو', 'تشخیص اصالت کالای اروپایی', 'خرید محصولات اسپانیایی اصل'],
    seoRankMathScore: 99,
    relatedProductIds: ['agrado-keratin-shampoo', 'amalfi-body-lotion-aloe', 'syro-micellar-water'],
    content: `در دنیای امروز مراقبت از زیبایی و سلامت فردی ، دسترسی به محصولات اورجینال اروپایی یکی از بزرگ ترین چالش های مصرف کنندگان ایرانی است. متاسفانه بازار پر از کالاهای تقلبی بی کیفیت با بسته بندی های مشابه شده است. فروشگاه گلی کالا مفتخر است به عنوان نماینده رسمی و مستقیم برندهای برجسته اروپایی آمالفی (Amalfi) ، آگرادو (Agrado) و سایرو (Syro) در ایران ، کالاهایی با اصالت صد درصدی و تضمین آزمایشگاهی ارائه نماید.

در این مقاله تخصصی به بررسی تفاوت های ساختاری این سه برند مطرح قاره سبز می پردازیم :

۱. برند آگرادو اسپانیا (Agrado) : پادشاه لاین های احیای مو و کراتین تراپی
آگرادو یکی از شناخته شده ترین آزمایشگاه های تولیدی در والنسیا اسپانیا می باشد. فرمولاسیون محصولات مویی آگرادو متکی بر کراتین های هیدرولیز شده زنجیره کوتاه است که به سادگی به لایه مدولای مو نفوذ می کنند و تارهای آسیب دیده بر اثر حرارت یا مواد شیمیایی را ترمیم می سازند.

۲. برند آمالفی اسپانیا (Amalfi) : تلفیق گیاهان مدیترانه ای و لوسیون های مغذی
آمالفی با بهره گیری از عصاره های ارگانیک نظیر آلوئه ورا ، روغن زیتون بکر مدیترانه و نارگیل خالص ، محصولاتی تولید می کند که سد دفاعی اپیدرم پوست را احیا کرده و مانع از هدررفت ترانس اپیدرمال آب می شوند.

۳. برند سایرو اروپا (Syro) : درماتولوژی ملایم و فرمول های ضد حساسیت
برند سایرو با تمرکز بر پوست های واکنشی و به شدت حساس به فرمولاسیونی دست یافته است که عاری از صابون ، الکل و پارابن بوده و حتی برای حساس ترین نواحی اطراف چشم نیز کاملا بی خطر است.`,
    tableData: {
      headers: ['شاخص بررسی', 'برند آمالفی (Amalfi)', 'برند آگرادو (Agrado)', 'برند سایرو (Syro)'],
      rows: [
        ['کشور مبدا', 'اسپانیا', 'اسپانیا', 'اتحادیه اروپا'],
        ['حوزه تخصص اصلی', 'لوسیون های بدن و ژل حمام مغذی', 'شامپو و ماسک کراتینه مو', 'شوینده ها و میسلار تخصصی صورت'],
        ['ماده موثره کلیدی', 'آلوئه ورا طبیعی و روغن آرگان', 'کراتین هیدرولیز شده فعال', 'هیالورونیک اسید و میسل های هوشمند'],
        ['ضمانت اصالت در گلی کالا', 'دارای برچسب و بچ کد رسمی', 'دارای تاییدیه آزمایشگاهی اسپانیا', 'ضمانت کتبی بازگشت وجه']
      ]
    }
  },
  {
    id: 'how-to-check-original-batch-code',
    title: 'آموزش گام به گام استعلام بچ کد (Batch Code) محصولات آرایشی بهداشتی اروپایی و تایید اصالت کالا',
    slug: 'batch-code-verification-guide',
    brandFocus: 'راهنمای جامع',
    publishDate: '۱۰ آبان ۱۴۰۵',
    readTime: '۵ دقیقه مطالعه',
    author: 'واحد کنترل کیفیت گلی کالا',
    coverImage: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=1200&q=80',
    summary: 'چگونه در کمتر از یک دقیقه تاریخ تولید ، انقضا و کارخانه سازنده محصول خریداری شده از آمالفی و آگرادو را راستی آزمایی کنیم ؟',
    keywords: ['استعلام بچ کد', 'تشخیص اصالت آگرادو', 'تشخیص اصالت آمالفی', 'کد رهگیری گلی کالا'],
    seoRankMathScore: 98,
    relatedProductIds: ['agrado-keratin-shampoo', 'amalfi-argan-serum'],
    content: `بچ کد یا Batch Code یک کد اختصاصی حک شده روی کف یا انتهای قوطی محصولات خارجی است که نشان دهنده سری ساخت ، خط تولید و سال تولید دقیق محصول در کارخانه اروپایی است.

در فروشگاه گلی کالا کلیه کالاهای عرضه شده از برندهای آمالفی ، آگرادو و سایرو دارای بچ کدهای فعال و قابل ردیابی هستند.

مراحل استعلام آنلاین بچ کد در گلی کالا :
۱. به بخش سامانه استعلام اصالت در سایت گلی کالا مراجعه فرمایید.
۲. کد مندرج روی بدنه کالا (مثلا ES-AGR-882941) را وارد کنید.
۳. اطلاعات رسمی کارخانه ، کشور مبدا و تاریخ انقضا بلافاصله نمایش داده می شود.`,
    tableData: {
      headers: ['نشانه اصالت', 'محصول اصلی در گلی کالا', 'محصول تقلبی بازار'],
      rows: [
        ['حکاکی بچ کد', 'لیزری برجسته و شفاف در انتهای قوطی', 'چاپ جوهری کدر یا بدون بچ کد'],
        ['کیفیت درب و پمپ', 'روان بدون نشتی با پلمپ محافظ', 'درب شل با نشت مواد حین حمل'],
        ['بافت و رایحه', 'رایحه طبیعی و بافت یکدست غلیظ', 'بوی تند الکل و بافت دوفاز و آبکی'],
        ['پشتیبانی و گارانتی', 'ضمانت بازگشت وجه بی قید و شرط', 'فاقد هرگونه پاسخگویی']
      ]
    }
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'GK-98214',
    trackingCode: 'GK-98214',
    postTrackingCode: '319482710599281720',
    date: '۱۴ آبان ۱۴۰۵ - ساعت ۱۱:۴۵',
    items: [
      {
        productId: 'agrado-keratin-shampoo',
        productName: 'شامپو کراتین تخصصی آگرادو اسپانیا حجم ۷۵۰ میل',
        price: 495000,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80'
      },
      {
        productId: 'amalfi-body-lotion-aloe',
        productName: 'لوسیون بدن آبرسان آمالفی عصاره آلوئه ورا ۵۰۰ میل',
        price: 365000,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80'
      }
    ],
    totalAmount: 1355000,
    status: 'تحویل به پست',
    shippingMethod: 'تیپاکس اکسپرس',
    customerName: 'کامران گلی',
    phone: '۰۹۱۲۳۴۵۶۷۸۹',
    address: 'تهران ، منطقه ۵ ، بلوار جنت آباد جنوبی ، کوچه بنفشه ، پلاک ۱۲ ، زنگ ۴',
    smsAlertsSent: [
      {
        timestamp: '۱۴ آبان ۱۴۰۵ - ۱۱:۴۷',
        message: 'گلی کالا : سفارش شما با شناسه GK-98214 با موفقیت ثبت شد و در مرحله پردازش قرار گرفت.'
      },
      {
        timestamp: '۱۴ آبان ۱۴۰۵ - ۱۳:۱۵',
        message: 'گلی کالا : سفارش شما از انبار مرکزی خارج و به تیپاکس تحویل گردید. کد رهگیری : 319482710599281720'
      }
    ]
  },
  {
    id: 'GK-97450',
    trackingCode: 'GK-97450',
    postTrackingCode: '8849201948210928',
    date: '۲۸ مهر ۱۴۰۵ - ساعت ۱۶:۲۰',
    items: [
      {
        productId: 'syro-micellar-water',
        productName: 'میسلار واتر پاک کننده تخصصی آرایش سایرو ۴۰۰ میل',
        price: 340000,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80'
      }
    ],
    totalAmount: 340000,
    status: 'تحویل داده شده',
    shippingMethod: 'پست پیشتاز',
    customerName: 'کامران گلی',
    phone: '۰۹۱۲۳۴۵۶۷۸۹',
    address: 'تهران ، بلوار جنت آباد جنوبی ، پلاک ۱۲',
    smsAlertsSent: [
      {
        timestamp: '۲۸ مهر ۱۴۰۵ - ۱۶:۲۲',
        message: 'گلی کالا : سفارش شما ثبت شد.'
      },
      {
        timestamp: '۲۹ مهر ۱۴۰۵ - ۱۰:۰۰',
        message: 'گلی کالا : مرسوله شما تحویل پست پیشتاز شد.'
      },
      {
        timestamp: '۱ آبان ۱۴۰۵ - ۱۴:۳۰',
        message: 'گلی کالا : سفارش شما با موفقیت به گیرنده تحویل داده شد. از اعتماد شما به نمایندگی رسمی گلی کالا سپاسگزاریم.'
      }
    ]
  }
];

export const ELEMENTOR_WORDPRESS_SNIPPETS = {
  elementorCustomCss: `/* ===================================================
   * کدهای بهینه سازی اختصاصی گلی کالا (golikala.com)
   * قابل قرارگیری در بخش Elementor > Custom CSS یا استایل قالب
   * افزایش سرعت لود و استایل مدرن مینیمال کارت ها و هدر
   * =================================================== */

:root {
  --gk-primary: #e11d48;
  --gk-primary-hover: #be123c;
  --gk-dark: #0f172a;
  --gk-gold: #f59e0b;
  --gk-border-radius: 16px;
  --gk-card-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.02);
}

/* کارت های فوق العاده مدرن و سبک برای محصولات المنتور */
.elementor-widget-woocommerce-products .product,
.gk-product-card {
  border-radius: var(--gk-border-radius) !important;
  border: 1px solid #f1f5f9 !important;
  box-shadow: var(--gk-card-shadow) !important;
  transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1) !important;
  background: #ffffff !important;
  overflow: hidden !important;
}

.elementor-widget-woocommerce-products .product:hover,
.gk-product-card:hover {
  transform: translateY(-6px) !important;
  box-shadow: 0 20px 30px -10px rgba(225, 29, 72, 0.12) !important;
  border-color: #fecdd3 !important;
}

/* بج تضمین اصالت اروپایی روی محصولات */
.gk-authentic-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
  color: #065f46;
  font-weight: 700;
  font-size: 11px;
  border-radius: 20px;
  border: 1px solid #a7f3d0;
}

/* دکمه های شیک و مینیمال */
.elementor-button, .gk-btn-primary {
  border-radius: 12px !important;
  font-weight: 700 !important;
  letter-spacing: normal !important;
  transition: all 0.25s ease !important;
}

/* حذف پرش صفحه و شتاب دهی سخت افزاری برای افزایش نمره PageSpeed */
img {
  content-visibility: auto;
  aspect-ratio: auto;
}`,
  rankMathSchemaJsonLd: `{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://golikala.com/#organization",
      "name": "گلی کالا | نماینده رسمی محصولات اروپایی",
      "url": "https://golikala.com",
      "logo": "https://golikala.com/wp-content/uploads/logo.png",
      "description": "نماینده رسمی و واردکننده انحصاری برندهای آمالفی، آگرادو و سایرو در ایران با تضمین کتبی اصالت کالا",
      "sameAs": [
        "https://www.instagram.com/golikala",
        "https://t.me/golikala"
      ],
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+98-21-12345678",
        "contactType": "customer service",
        "areaServed": "IR",
        "availableLanguage": "Persian"
      }
    },
    {
      "@type": "WebSite",
      "@id": "https://golikala.com/#website",
      "url": "https://golikala.com",
      "name": "گلی کالا",
      "publisher": {
        "@id": "https://golikala.com/#organization"
      },
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://golikala.com/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
  ]
}`
};
