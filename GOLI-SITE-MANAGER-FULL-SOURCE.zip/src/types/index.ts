export interface Product {
  id: string;
  name: string;
  originalName: string;
  brand: 'آمالفی' | 'آگرادو' | 'سایرو' | 'سایر برندهای اروپایی';
  brandEn: 'Amalfi' | 'Agrado' | 'Syro' | 'Other';
  category: 'مراقبت مو' | 'مراقبت پوست' | 'بهداشت بدن' | 'ماسک و لوسیون';
  price: number;
  oldPrice?: number;
  discountPercent?: number;
  rating: number;
  reviewsCount: number;
  stock: number;
  isOfficialAgency: boolean;
  authenticityGuaranteed: boolean;
  originCountry: string;
  image: string;
  gallery: string[];
  shortDescription: string;
  fullDescription: string;
  features: string[];
  specifications: Record<string, string>;
  batchCodeExample: string;
  complementaryProductIds: string[];
  rankMathSeo: {
    focusKeyword: string;
    seoTitle: string;
    metaDescription: string;
    score: number;
  };
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  verifiedPurchase: boolean;
  confirmedAuthentic: boolean;
  pros?: string[];
  cons?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  trackingCode: string;
  postTrackingCode: string;
  date: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'در حال پردازش' | 'آماده‌سازی در انبار' | 'تحویل به پست' | 'تحویل داده شده';
  shippingMethod: 'پست پیشتاز' | 'تیپاکس اکسپرس' | 'پیک فوری تهران';
  customerName: string;
  phone: string;
  address: string;
  smsAlertsSent: {
    timestamp: string;
    message: string;
  }[];
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  brandFocus: 'آمالفی' | 'آگرادو' | 'سایرو' | 'راهنمای جامع';
  publishDate: string;
  readTime: string;
  author: string;
  coverImage: string;
  summary: string;
  content: string;
  keywords: string[];
  tableData?: {
    headers: string[];
    rows: string[][];
  };
  relatedProductIds: string[];
  seoRankMathScore: number;
}

export interface FilterState {
  searchQuery: string;
  selectedBrands: string[];
  selectedCategories: string[];
  minPrice: number;
  maxPrice: number;
  inStockOnly: boolean;
  hasDiscountOnly: boolean;
  sortBy: 'popular' | 'newest' | 'price-asc' | 'price-desc' | 'rating';
}
