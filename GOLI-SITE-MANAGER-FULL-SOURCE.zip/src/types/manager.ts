export interface SiteConnection {
  siteUrl: string;
  name: string;
  description: string;
  status: 'CONNECTED' | 'STANDBY_READY' | 'DISCONNECTED';
  latencyMs: number;
  wpVersion: string;
  wcVersion: string;
  elementorVersion: string;
  rankMathVersion: string;
  activeTheme: string;
  serverType: string;
  phpVersion: string;
  sslActive: boolean;
  litespeedActive: boolean;
  lastPingTime: string;
}

export interface WordPressPage {
  id: number;
  title: string;
  slug: string;
  status: 'publish' | 'draft' | 'pending';
  isElementor: boolean;
  template: string;
  date: string;
  modified: string;
  author: string;
  rankMathScore: number;
  focusKeyword: string;
  elementorDocType?: 'wp-page' | 'header' | 'footer' | 'product-archive' | 'landing';
}

export interface ElementorTemplate {
  id: number;
  title: string;
  type: 'header' | 'footer' | 'single-product' | 'product-archive' | 'section' | 'popup';
  status: 'active' | 'draft';
  instances: string;
  lastEdited: string;
  author: string;
  hasCustomCss: boolean;
  cssLinesCount: number;
}

export interface WooProduct {
  id: number;
  name: string;
  sku: string;
  price: number;
  regularPrice: number;
  salePrice?: number;
  stockStatus: 'instock' | 'outofstock' | 'onbackorder';
  stockQuantity: number;
  brand: 'آگرادو' | 'آمالفی' | 'سایرو' | 'سایر برندهای اروپایی';
  brandEn: 'Agrado' | 'Amalfi' | 'Sairo' | 'Other';
  category: string;
  image: string;
  isWholesaleAvailable: boolean;
  wholesalePrice?: number;
  variationsCount: number;
  rankMathScore: number;
  officialAgencyGuaranteed: boolean;
}

export interface WooOrder {
  id: number;
  orderNumber: string;
  date: string;
  customerName: string;
  customerPhone: string;
  total: number;
  status: 'در حال پردازش' | 'تکمیل شده' | 'در انتظار پرداخت' | 'ارسال شده با تیپاکس';
  paymentGateway: 'زرین‌پال (Zarinpal)' | 'شاپرک سامان' | 'واریز به حساب';
  postTrackingCode?: string;
  itemsCount: number;
  shippingCity: string;
}

export interface SeoAuditItem {
  id: number;
  pageTitle: string;
  url: string;
  focusKeyword: string;
  score: number;
  issuesCount: number;
  titleLength: number;
  descLength: number;
  canonicalOk: boolean;
  schemaType: string;
  indexingStatus: 'ایندکس شده در گوگل' | 'در صف بررسی' | 'هشدار noindex';
  searchConsoleImpressions?: number;
  searchConsoleClicks?: number;
}

export interface MediaItem {
  id: number;
  title: string;
  fileName: string;
  url: string;
  width: number;
  height: number;
  fileSizeKb: number;
  format: 'webp' | 'jpeg' | 'png' | 'svg';
  altText: string;
  hasAlt: boolean;
  isOversized: boolean;
  associatedProduct?: string;
}

export interface SiteHealthMetric {
  id: string;
  title: string;
  value: string;
  status: 'good' | 'warning' | 'critical';
  recommendation: string;
  category: 'performance' | 'security' | 'database' | 'compatibility';
}

export interface BackupSnapshot {
  id: string;
  name: string;
  type: 'elementor_document' | 'custom_css' | 'page_full' | 'global_styles' | 'woo_pricing';
  target: string;
  date: string;
  author: string;
  sizeKb: number;
  verified: boolean;
  canRollback: boolean;
}

export interface AiAgentTask {
  id: string;
  prompt: string;
  timestamp: string;
  targetArea: string;
  riskLevel: 'پایین' | 'متوسط' | 'بالا';
  status: 'برنامه‌ریزی شده' | 'در انتظار تایید' | 'اجرا شده در وبسایت' | 'بازگردانی شده (Rollback)';
  planSummary: string;
  steps: string[];
  suggestedCss?: string;
  suggestedStructure?: string;
  seoRecommendations?: {
    focusKeyword: string;
    seoTitle: string;
    metaDescription: string;
  };
  requiresApproval: boolean;
  dryRunVerified: boolean;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  user: string;
  module: string;
  action: string;
  status: 'success' | 'warning' | 'error';
  details: string;
}
