import React, { useState, useMemo } from 'react';
import { 
  Filter, 
  ArrowUpDown, 
  Check, 
  RotateCcw, 
  Search, 
  SlidersHorizontal, 
  Sparkles,
  ShieldCheck,
  Tag
} from 'lucide-react';
import { Product, FilterState } from '../types';
import { ProductCard } from './ProductCard';

interface ShopPageProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onCheckBatchCode: (product: Product) => void;
  onAddToCompare?: (product: Product) => void;
  initialBrandFilter?: string;
}

export const ShopPage: React.FC<ShopPageProps> = ({
  products,
  onAddToCart,
  onQuickView,
  onCheckBatchCode,
  onAddToCompare,
  initialBrandFilter,
}) => {
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    selectedBrands: initialBrandFilter ? [initialBrandFilter] : [],
    selectedCategories: [],
    minPrice: 0,
    maxPrice: 1000000,
    inStockOnly: false,
    hasDiscountOnly: false,
    sortBy: 'popular',
  });

  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Available unique brands & categories
  const brands = ['آمالفی', 'آگرادو', 'سایرو', 'سایر برندهای اروپایی'];
  const categories = ['مراقبت مو', 'مراقبت پوست', 'بهداشت بدن'];

  // Toggle brand selection
  const handleToggleBrand = (b: string) => {
    setFilters(prev => {
      const exists = prev.selectedBrands.includes(b);
      return {
        ...prev,
        selectedBrands: exists 
          ? prev.selectedBrands.filter(x => x !== b) 
          : [...prev.selectedBrands, b]
      };
    });
  };

  // Toggle category selection
  const handleToggleCategory = (c: string) => {
    setFilters(prev => {
      const exists = prev.selectedCategories.includes(c);
      return {
        ...prev,
        selectedCategories: exists 
          ? prev.selectedCategories.filter(x => x !== c) 
          : [...prev.selectedCategories, c]
      };
    });
  };

  // Reset filters
  const handleResetFilters = () => {
    setFilters({
      searchQuery: '',
      selectedBrands: [],
      selectedCategories: [],
      minPrice: 0,
      maxPrice: 1000000,
      inStockOnly: false,
      hasDiscountOnly: false,
      sortBy: 'popular',
    });
  };

  // Filter & sort logic
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Search
      if (filters.searchQuery.trim() !== '') {
        const query = filters.searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesOriginal = p.originalName.toLowerCase().includes(query);
        const matchesBrand = p.brand.toLowerCase().includes(query);
        if (!matchesName && !matchesOriginal && !matchesBrand) return false;
      }

      // Brand
      if (filters.selectedBrands.length > 0 && !filters.selectedBrands.includes(p.brand)) {
        return false;
      }

      // Category
      if (filters.selectedCategories.length > 0 && !filters.selectedCategories.includes(p.category)) {
        return false;
      }

      // In stock
      if (filters.inStockOnly && p.stock <= 0) {
        return false;
      }

      // Discount
      if (filters.hasDiscountOnly && (!p.discountPercent || p.discountPercent <= 0)) {
        return false;
      }

      // Price Range
      if (p.price < filters.minPrice || p.price > filters.maxPrice) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'popular') return b.reviewsCount - a.reviewsCount;
      if (filters.sortBy === 'newest') return b.rating - a.rating;
      if (filters.sortBy === 'price-asc') return a.price - b.price;
      if (filters.sortBy === 'price-desc') return b.price - a.price;
      if (filters.sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });
  }, [products, filters]);

  return (
    <div className="py-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header Breadcrumb & Title */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="text-right">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
              فروشگاه تخصصی محصولات اروپایی گلی کالا
            </h1>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">
              نمایندگی انحصاری آمالفی ، آگرادو و سایرو با ضمانت ۱۰۰٪ اصالت کالا و ارسال سریع
            </p>
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <span className="text-xs font-bold text-slate-600 bg-white border border-slate-200 px-3 py-1.5 rounded-xl shadow-2xs">
              نمایش {filteredProducts.length.toLocaleString('fa-IR')} محصول اصل
            </span>
            <button
              onClick={() => setMobileFilterOpen(true)}
              className="lg:hidden flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold shadow-2xs"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>فیلترها</span>
            </button>
          </div>
        </div>

        {/* Main Layout: Sidebar Filters + Products Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Desktop Filters Sidebar */}
          <div className="hidden lg:block lg:col-span-3 space-y-6 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs text-right">
            
            {/* Header of Filters */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                <SlidersHorizontal className="w-4 h-4 text-rose-600" />
                <span>فیلترهای پیشرفته</span>
              </div>
              <button
                onClick={handleResetFilters}
                className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1 transition-colors"
                title="پاک کردن فیلترها"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>بازنشانی</span>
              </button>
            </div>

            {/* Brand Filter */}
            <div>
              <h3 className="text-xs font-bold text-slate-800 mb-2.5">برندهای اروپایی :</h3>
              <div className="space-y-1.5">
                {brands.map(brand => {
                  const isChecked = filters.selectedBrands.includes(brand);
                  return (
                    <label
                      key={brand}
                      onClick={() => handleToggleBrand(brand)}
                      className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-md border flex items-center justify-center transition-colors ${
                          isChecked ? 'bg-rose-600 border-rose-600 text-white' : 'border-slate-300 bg-white'
                        }`}>
                          {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className={`font-medium ${isChecked ? 'text-rose-600 font-bold' : 'text-slate-700'}`}>
                          {brand}
                        </span>
                      </div>
                      {['آمالفی', 'آگرادو', 'سایرو'].includes(brand) && (
                        <span className="text-[10px] bg-rose-50 text-rose-700 font-bold px-1.5 py-0.5 rounded-sm">
                          نمایندگی
                        </span>
                      )}
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Category Filter */}
            <div className="pt-3 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-800 mb-2.5">دسته بندی محصول :</h3>
              <div className="space-y-1.5">
                {categories.map(cat => {
                  const isChecked = filters.selectedCategories.includes(cat);
                  return (
                    <label
                      key={cat}
                      onClick={() => handleToggleCategory(cat)}
                      className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-md border flex items-center justify-center transition-colors ${
                          isChecked ? 'bg-rose-600 border-rose-600 text-white' : 'border-slate-300 bg-white'
                        }`}>
                          {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className={`font-medium ${isChecked ? 'text-rose-600 font-bold' : 'text-slate-700'}`}>
                          {cat}
                        </span>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Quick Status Toggles */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <label 
                onClick={() => setFilters(p => ({ ...p, inStockOnly: !p.inStockOnly }))}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer text-xs"
              >
                <span className="font-medium text-slate-700">فقط کالاهای موجود در انبار</span>
                <div className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                  filters.inStockOnly ? 'bg-rose-600' : 'bg-slate-300'
                }`}>
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    filters.inStockOnly ? 'translate-x-0' : '-translate-x-4'
                  }`} />
                </div>
              </label>

              <label 
                onClick={() => setFilters(p => ({ ...p, hasDiscountOnly: !p.hasDiscountOnly }))}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer text-xs"
              >
                <span className="font-medium text-slate-700">فقط کالاهای دارای تخفیف</span>
                <div className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                  filters.hasDiscountOnly ? 'bg-rose-600' : 'bg-slate-300'
                }`}>
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    filters.hasDiscountOnly ? 'translate-x-0' : '-translate-x-4'
                  }`} />
                </div>
              </label>
            </div>

            {/* Maximum Price Slider */}
            <div className="pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-slate-800">حداکثر قیمت :</span>
                <span className="font-black text-rose-600">
                  {filters.maxPrice.toLocaleString('fa-IR')} تومان
                </span>
              </div>
              <input
                type="range"
                min={200000}
                max={1000000}
                step={20000}
                value={filters.maxPrice}
                onChange={(e) => setFilters(p => ({ ...p, maxPrice: Number(e.target.value) }))}
                className="w-full accent-rose-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>۲۰۰ هزار تومان</span>
                <span>۱ میلیون تومان</span>
              </div>
            </div>

            {/* Authenticity Guarantee Callout */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-emerald-50 to-teal-50 border border-emerald-200 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-emerald-900 mb-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>ضمانت کتبی اصالت کالا</span>
              </div>
              <p className="text-[11px] text-emerald-700 leading-relaxed font-normal">
                تمامی کالاهای خریداری شده دارای شناسه معتبر بازرگانی و هولوگرام تضمین اصالت گلی کالا می باشند.
              </p>
            </div>

          </div>

          {/* Products Content Area */}
          <div className="lg:col-span-9 space-y-6">
            
            {/* Sorting Toolbar */}
            <div className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
              
              <div className="flex items-center gap-2 overflow-x-auto">
                <span className="text-slate-400 font-bold flex items-center gap-1 shrink-0">
                  <ArrowUpDown className="w-3.5 h-3.5" />
                  <span>مرتب‌سازی :</span>
                </span>

                <button
                  onClick={() => setFilters(p => ({ ...p, sortBy: 'popular' }))}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                    filters.sortBy === 'popular' ? 'bg-rose-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  محبوب ترین
                </button>

                <button
                  onClick={() => setFilters(p => ({ ...p, sortBy: 'newest' }))}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                    filters.sortBy === 'newest' ? 'bg-rose-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  جدیدترین
                </button>

                <button
                  onClick={() => setFilters(p => ({ ...p, sortBy: 'price-asc' }))}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                    filters.sortBy === 'price-asc' ? 'bg-rose-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  ارزان ترین
                </button>

                <button
                  onClick={() => setFilters(p => ({ ...p, sortBy: 'price-desc' }))}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                    filters.sortBy === 'price-desc' ? 'bg-rose-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  گران ترین
                </button>
              </div>

              {/* Active Filters summary */}
              {filters.selectedBrands.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-400">برند انتخابی :</span>
                  {filters.selectedBrands.map(b => (
                    <span 
                      key={b} 
                      className="bg-rose-100 text-rose-800 text-[10px] px-2 py-0.5 rounded-md font-bold flex items-center gap-1"
                    >
                      {b}
                      <button onClick={() => handleToggleBrand(b)} className="hover:text-red-900">×</button>
                    </span>
                  ))}
                </div>
              )}

            </div>

            {/* Products Grid */}
            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-slate-800">
                  هیچ محصولی با فیلترهای انتخابی شما یافت نشد !
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  لطفا فیلترها یا محدوده قیمت را تغییر دهید تا محصولات برندهای آمالفی ، آگرادو و سایرو نمایش داده شوند.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 transition-colors"
                >
                  حذف همه فیلترها
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
                {filteredProducts.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={onAddToCart}
                    onQuickView={onQuickView}
                    onCheckBatchCode={onCheckBatchCode}
                    onAddToCompare={onAddToCompare}
                  />
                ))}
              </div>
            )}

          </div>

        </div>

      </div>

      {/* Mobile Filters Drawer */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
          <div className="bg-white w-4/5 max-w-sm h-full p-5 overflow-y-auto space-y-6 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <span className="font-bold text-sm text-slate-800">فیلترهای پیشرفته</span>
              <button 
                onClick={() => setMobileFilterOpen(false)}
                className="text-xs font-bold text-slate-500 hover:text-slate-800"
              >
                بستن ✕
              </button>
            </div>

            {/* Brands on Mobile */}
            <div>
              <h4 className="text-xs font-bold text-slate-800 mb-2">برندها :</h4>
              <div className="space-y-2">
                {brands.map(brand => (
                  <button
                    key={brand}
                    onClick={() => handleToggleBrand(brand)}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs ${
                      filters.selectedBrands.includes(brand) ? 'bg-rose-50 text-rose-700 font-bold' : 'text-slate-700'
                    }`}
                  >
                    <span>{brand}</span>
                    {filters.selectedBrands.includes(brand) && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setMobileFilterOpen(false)}
              className="w-full py-3 bg-rose-600 text-white rounded-xl text-xs font-bold"
            >
              مشاهده {filteredProducts.length} محصول
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
