import React, { useState } from 'react';
import { 
  Layers, 
  Code2, 
  Copy, 
  Check, 
  ShieldCheck, 
  Download, 
  ExternalLink, 
  Sparkles,
  FileCheck2,
  Lock
} from 'lucide-react';
import { ElementorTemplate } from '../../types/manager';
import { COMPANION_PLUGIN_CODE } from '../../data/managerMockData';

interface ElementorManagerProps {
  templates: ElementorTemplate[];
}

export const ElementorManager: React.FC<ElementorManagerProps> = ({
  templates,
}) => {
  const [activeTab, setActiveTab] = useState<'templates' | 'bridge' | 'custom-css'>('templates');
  const [copiedBridge, setCopiedBridge] = useState(false);
  const [copiedCss, setCopiedCss] = useState(false);

  const customCssCode = `/* ========================================================
 * استایل‌های یکپارچه و بهینه‌سازی شده گلیکالا برای المنتور پرو
 * سازگار با پوسته فرزند باکالا (Bakala Child Theme)
 * ======================================================== */

:root {
  --goli-forest-green: #0f382c;
  --goli-forest-light: #164e3f;
  --goli-olive-green: #3d5a45;
  --goli-gold: #d4af37;
  --goli-gold-hover: #c5a059;
  --goli-warm-ivory: #fcfbf7;
  --goli-radius: 16px;
  --goli-shadow: 0 10px 25px -5px rgba(15, 56, 44, 0.08), 0 8px 10px -6px rgba(15, 56, 44, 0.04);
}

/* کارت‌های مدرن و بدون پرش چیدمان ووکامرس */
.elementor-widget-woocommerce-products .product {
  border-radius: var(--goli-radius) !important;
  border: 1px solid rgba(212, 175, 55, 0.2) !important;
  background: #ffffff !important;
  box-shadow: var(--goli-shadow) !important;
  transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1) !important;
  overflow: hidden !important;
}

.elementor-widget-woocommerce-products .product:hover {
  transform: translateY(-5px) !important;
  border-color: var(--goli-gold) !important;
  box-shadow: 0 20px 30px -10px rgba(15, 56, 44, 0.15) !important;
}

/* نشان تایید اصالت اروپایی روی محصولات */
.goli-authentic-seal {
  background: linear-gradient(135deg, #0f382c 0%, #164e3f 100%);
  color: #f3e5ab;
  border: 1px solid rgba(212, 175, 55, 0.4);
  font-weight: 800;
  border-radius: 20px;
  padding: 4px 10px;
  font-size: 11px;
}`;

  const handleCopyBridge = () => {
    navigator.clipboard.writeText(COMPANION_PLUGIN_CODE);
    setCopiedBridge(true);
    setTimeout(() => setCopiedBridge(false), 2000);
  };

  const handleCopyCss = () => {
    navigator.clipboard.writeText(customCssCode);
    setCopiedCss(true);
    setTimeout(() => setCopiedCss(false), 2000);
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
            <Layers className="w-4 h-4 text-[#d4af37]" />
            <span>مدیریت المنتور پرو، تم بیلدر و افزونه هماهنگ‌ساز Companion Bridge</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black">
            قالب‌ها، هدر، فوتر و ساختارهای سندی المنتور golikala.com
          </h1>
          <p className="text-xs text-[#c4d6ce]">
            دسترسی ایمن به متادیتای `_elementor_data` بدون آسیب به جداول وردپرس.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-[#08241c] p-1 rounded-2xl border border-[#1b4e3e] text-xs font-bold">
          <button
            onClick={() => setActiveTab('templates')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'templates' ? 'bg-[#d4af37] text-[#0f382c] font-black' : 'text-[#c4d6ce]'
            }`}
          >
            قالب‌های تم بیلدر ({templates.length})
          </button>
          <button
            onClick={() => setActiveTab('bridge')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'bridge' ? 'bg-[#d4af37] text-[#0f382c] font-black' : 'text-[#c4d6ce]'
            }`}
          >
            کد افزونه Companion Bridge
          </button>
          <button
            onClick={() => setActiveTab('custom-css')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'custom-css' ? 'bg-[#d4af37] text-[#0f382c] font-black' : 'text-[#c4d6ce]'
            }`}
          >
            کدهای Custom CSS
          </button>
        </div>
      </div>

      {/* TAB 1: THEME BUILDER TEMPLATES */}
      {activeTab === 'templates' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-black text-slate-900">
              قالب‌های فعال تم بیلدر المنتور پرو (Elementor Theme Builder) :
            </h3>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-full">
              سازگار با Bakala Child Theme
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map((tpl) => (
              <div key={tpl.id} className="p-4 rounded-2xl border border-slate-200 bg-[#fcfbf7] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] bg-[#0f382c] text-[#f3e5ab] font-bold px-2 py-0.5 rounded-md">
                    {tpl.type}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">ID: {tpl.id}</span>
                </div>

                <h4 className="text-xs sm:text-sm font-black text-slate-900 leading-snug">
                  {tpl.title}
                </h4>

                <div className="text-xs text-slate-500 space-y-1">
                  <div>شرایط نمایش : <strong className="text-slate-800">{tpl.instances}</strong></div>
                  <div>آخرین ویرایش : <span className="font-mono text-slate-600">{tpl.lastEdited}</span></div>
                </div>

                <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
                  <span className="text-emerald-700 font-bold">وضعیت : فعال (Active)</span>
                  <span className="text-slate-500 font-mono text-[11px]">{tpl.cssLinesCount} خط CSS اختصاصی</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: COMPANION PLUGIN CODE (PART 8) */}
      {activeTab === 'bridge' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <span>کد سورس کامل افزونه هماهنگ‌ساز Goli Companion Bridge</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                این افزونه اختصاصی را در مسیر `wp-content/plugins/goli-companion/` قرار دهید تا اتصال امن REST API به المنتور برقرار شود.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <a
                href="/goli-companion-bridge.zip"
                download="goli-companion-bridge.zip"
                className="px-4 py-2 bg-gradient-to-r from-[#d4af37] to-[#c5a059] hover:from-[#c5a059] hover:to-[#b38e4a] text-[#0f382c] rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>دانلود مستقیم فایل زیپ افزونه وردپرس (.zip)</span>
              </a>

              <button
                onClick={handleCopyBridge}
                className="px-4 py-2 bg-[#0f382c] hover:bg-[#164e3f] text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                {copiedBridge ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedBridge ? 'کپی شد !' : 'کپی کل کد PHP'}</span>
              </button>
            </div>
          </div>

          <div className="relative rounded-2xl bg-[#0a2920] border border-slate-800 p-4 text-left dir-ltr overflow-x-auto text-xs font-mono text-emerald-400 leading-relaxed max-h-96">
            <pre>{COMPANION_PLUGIN_CODE}</pre>
          </div>
        </div>
      )}

      {/* TAB 3: CUSTOM CSS MANAGER */}
      {activeTab === 'custom-css' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-black text-slate-900">
                کدهای سفارشی استایل گلیکالا برای Elementor Custom CSS
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                بهینه‌سازی کارت‌های ووکامرس، نشان‌های تایید اصالت و رنگ‌های سازمانی.
              </p>
            </div>

            <button
              onClick={handleCopyCss}
              className="px-4 py-2 bg-[#0f382c] hover:bg-[#164e3f] text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              {copiedCss ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedCss ? 'کپی شد !' : 'کپی کدهای CSS'}</span>
            </button>
          </div>

          <div className="relative rounded-2xl bg-[#0a2920] border border-slate-800 p-4 text-left dir-ltr overflow-x-auto text-xs font-mono text-cyan-300 leading-relaxed max-h-96">
            <pre>{customCssCode}</pre>
          </div>
        </div>
      )}

    </div>
  );
};
