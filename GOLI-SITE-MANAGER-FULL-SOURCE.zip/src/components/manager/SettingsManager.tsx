import React, { useState } from 'react';
import { 
  Settings, 
  Key, 
  Server, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Cpu, 
  RefreshCw, 
  ExternalLink, 
  Zap, 
  Lock, 
  Globe, 
  Layers, 
  Sliders, 
  Eye, 
  FileCode 
} from 'lucide-react';
import { INITIAL_CONNECTION } from '../../data/managerMockData';

export function SettingsManager() {
  const [siteUrl, setSiteUrl] = useState(INITIAL_CONNECTION.siteUrl);
  const [username, setUsername] = useState('newadmin');
  const [appPassword, setAppPassword] = useState('••••••••••••••••••••');
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'CONNECTED' | 'TESTING' | 'ERROR'>('CONNECTED');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Security Toggles
  const [securitySettings, setSecuritySettings] = useState({
    disableXmlRpc: true,
    hideWpVersion: true,
    enforceSsl: true,
    twoFactorAuth: true,
    litespeedAutoPurge: true,
    aiStrictApproval: true
  });

  const handleTestConnection = () => {
    setIsTestingConnection(true);
    setConnectionStatus('TESTING');
    setTimeout(() => {
      setIsTestingConnection(false);
      setConnectionStatus('CONNECTED');
      setActionNotice('اتصال با موفقیت برقرار شد. وب‌سرویس وردپرس و افزونه رابط Goli Bridge با تاخیر ۱۲۸ میلی‌ثانیه پاسخگو هستند.');
      setTimeout(() => setActionNotice(null), 5000);
    }, 1200);
  };

  const handleToggleSecurity = (key: keyof typeof securitySettings) => {
    setSecuritySettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-[#0f382c]/10 text-[#0f382c]">
              <Settings className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800">تنظیمات اتصال و امنیت پلتفرم (Platform & API Settings)</h2>
          </div>
          <p className="text-sm text-slate-500">
            پیکربندی کلیدهای امنیتی REST API، گواهینامه اتصال پل ارتباطی Companion Bridge و سیاست‌های امنیتی
          </p>
        </div>

        <button
          onClick={handleTestConnection}
          disabled={isTestingConnection}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0f382c] text-white text-sm font-semibold hover:bg-[#174d3d] transition shadow-xs disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isTestingConnection ? 'animate-spin' : ''}`} />
          <span>{isTestingConnection ? 'در حال پینگ سرور...' : 'تست مجدد اتصال زنده'}</span>
        </button>
      </div>

      {actionNotice && (
        <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Grid: Credentials & AI Config */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* WordPress REST API Connection */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Server className="w-4 h-4 text-[#0f382c]" />
              <span>پیکربندی اتصال به وردپرس (WordPress REST API)</span>
            </h3>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>متصل به {INITIAL_CONNECTION.siteUrl}</span>
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-600 block mb-1">نشانی وب‌سایت وردپرس (Site URL)</label>
              <input
                type="text"
                value={siteUrl}
                onChange={(e) => setSiteUrl(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 font-mono text-left"
                dir="ltr"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 block mb-1">نام کاربری مجاز مدیر کل (Admin Username)</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 font-mono text-left"
                dir="ltr"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 block mb-1">رمز عبور اپلیکیشن وردپرس (Application Password)</label>
              <div className="relative">
                <input
                  type="password"
                  value={appPassword}
                  onChange={(e) => setAppPassword(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 font-mono text-left"
                  dir="ltr"
                />
                <Key className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                تولید شده در پنل وردپرس {'>'} کاربران {'>'} شناسنامه شما {'>'} گذرواژه‌های کاربردی
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
              <div className="flex items-center justify-between">
                <span>وضعیت افزونه رابط اختصاصی:</span>
                <span className="font-bold text-emerald-700">goli-companion-bridge.php v2.4.0 فعال</span>
              </div>
              <div className="flex items-center justify-between text-slate-400 text-[11px]">
                <span>مسیر اندپوینت اختصاصی:</span>
                <span className="font-mono">/wp-json/goli/v1/health</span>
              </div>
            </div>
          </div>
        </div>

        {/* Gemini AI Engine Configuration */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#0f382c]" />
              <span>موتور هوش مصنوعی Goli AI Agent (Gemini 2.5 Flash)</span>
            </h3>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-[#0f382c]/10 text-[#0f382c]">
              @google/genai SDK
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-600 block mb-1">مدل فعال هوش مصنوعی</label>
              <select className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-white font-mono text-left" dir="ltr">
                <option value="gemini-2.5-flash">gemini-2.5-flash (توصیه شده - سریع، دقیق و دارای استدلال زنده)</option>
                <option value="gemini-2.5-pro">gemini-2.5-pro (استدلال عمیق برای بهینه‌سازی کدهای المنتور)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">دمای مدل (Temperature)</label>
                <input
                  type="text"
                  readOnly
                  value="0.2 (دقت حداکثری و حداقل خطا)"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-600"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">حالت اجرایی گردش‌کار</label>
                <input
                  type="text"
                  readOnly
                  value="۱۴ مرحله‌ای با اعتبارسنجی Dry-run"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-600"
                />
              </div>
            </div>

            <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-800 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>حفاظت سرور-ساید از کلیدهای محرمانه</span>
              </div>
              <p className="text-[11px] text-emerald-700 leading-relaxed">
                کلیدهای GEMINI_API_KEY و اعتبارنامه‌های دسترسی به صورت کاملاً امن در بک‌اند Node.js/Express پردازش می‌شوند و هیچ‌گونه کلید یا رمزی در مرورگر کلاینت فاش نمی‌شود.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Security Hardening Toggles */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2 pb-3 border-b border-slate-100">
          <Lock className="w-4 h-4 text-[#0f382c]" />
          <span>پیکربندی امنیت و ایزولاسیون سرور وردپرس (WordPress Hardening)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-100 hover:border-slate-200 transition">
            <div>
              <div className="text-xs font-bold text-slate-800">غیرفعال‌سازی سرویس آسیب‌پذیر XML-RPC</div>
              <div className="text-[11px] text-slate-500">جلوگیری از حملات Brute-Force و حملات انعکاسی DDoS</div>
            </div>
            <button
              onClick={() => handleToggleSecurity('disableXmlRpc')}
              className={`w-11 h-6 rounded-full transition-colors relative ${securitySettings.disableXmlRpc ? 'bg-[#0f382c]' : 'bg-slate-300'}`}
            >
              <span className={`block w-4 h-4 rounded-full bg-white transition-transform ${securitySettings.disableXmlRpc ? 'translate-x-1' : 'translate-x-6'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-100 hover:border-slate-200 transition">
            <div>
              <div className="text-xs font-bold text-slate-800">مخفی‌سازی نگارش وردپرس (Hide WP Version)</div>
              <div className="text-[11px] text-slate-500">حذف متاتگ generator در سورس HTML صفحات</div>
            </div>
            <button
              onClick={() => handleToggleSecurity('hideWpVersion')}
              className={`w-11 h-6 rounded-full transition-colors relative ${securitySettings.hideWpVersion ? 'bg-[#0f382c]' : 'bg-slate-300'}`}
            >
              <span className={`block w-4 h-4 rounded-full bg-white transition-transform ${securitySettings.hideWpVersion ? 'translate-x-1' : 'translate-x-6'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-100 hover:border-slate-200 transition">
            <div>
              <div className="text-xs font-bold text-slate-800">الزام تایید دستی پیش از اجرای تغییرات هوش مصنوعی</div>
              <div className="text-[11px] text-slate-500">هیچ کد CSS یا کانتینری بدون تایید مدیر در دیتابیس ذخیره نمی‌شود</div>
            </div>
            <button
              onClick={() => handleToggleSecurity('aiStrictApproval')}
              className={`w-11 h-6 rounded-full transition-colors relative ${securitySettings.aiStrictApproval ? 'bg-[#0f382c]' : 'bg-slate-300'}`}
            >
              <span className={`block w-4 h-4 rounded-full bg-white transition-transform ${securitySettings.aiStrictApproval ? 'translate-x-1' : 'translate-x-6'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-100 hover:border-slate-200 transition">
            <div>
              <div className="text-xs font-bold text-slate-800">پاک‌سازی هوشمند کش لایت‌اسپید پس از ذخیره</div>
              <div className="text-[11px] text-slate-500">ارسال خودکار وب‌هوک Purge All به سرور LiteSpeed Enterprise</div>
            </div>
            <button
              onClick={() => handleToggleSecurity('litespeedAutoPurge')}
              className={`w-11 h-6 rounded-full transition-colors relative ${securitySettings.litespeedAutoPurge ? 'bg-[#0f382c]' : 'bg-slate-300'}`}
            >
              <span className={`block w-4 h-4 rounded-full bg-white transition-transform ${securitySettings.litespeedAutoPurge ? 'translate-x-1' : 'translate-x-6'}`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
