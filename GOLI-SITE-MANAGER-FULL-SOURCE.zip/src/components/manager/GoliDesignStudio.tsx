import React, { useState } from 'react';
import { 
  Palette, 
  Monitor, 
  Tablet, 
  Smartphone, 
  Layers, 
  Sparkles, 
  Check, 
  RotateCcw, 
  Save, 
  Eye, 
  Sliders, 
  ArrowLeftRight, 
  ShieldCheck, 
  CheckCircle2, 
  Download,
  Code2,
  FileCheck2
} from 'lucide-react';
import { WordPressPage } from '../../types/manager';

interface GoliDesignStudioProps {
  pages: WordPressPage[];
  onSaveSnapshot: (name: string, data: any) => void;
}

export const GoliDesignStudio: React.FC<GoliDesignStudioProps> = ({
  pages,
  onSaveSnapshot,
}) => {
  const [selectedPageId, setSelectedPageId] = useState<number>(12); // Homepage
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [viewMode, setViewMode] = useState<'editor' | 'diff' | 'export'>('editor');

  // Goli Brand Design System State (PART 5.1)
  const [forestGreen, setForestGreen] = useState('#0f382c');
  const [oliveGreen, setOliveGreen] = useState('#3d5a45');
  const [champagneGold, setChampagneGold] = useState('#d4af37');
  const [warmIvory, setWarmIvory] = useState('#fcfbf7');
  const [borderRadius, setBorderRadius] = useState(16);
  const [fontFamily, setFontFamily] = useState('Vazirmatn');

  // Editable Section content
  const [heroTitle, setHeroTitle] = useState('نمایندگی رسمی و انحصاری محصولات اروپایی آمالفی، آگرادو و سایرو در ایران');
  const [heroSubtitle, setHeroSubtitle] = useState('واردات مستقیم از اسپانیا با تضمین کتبی ۱۰۰٪ اصالت فیزیکی، استعلام بچ‌کد آزمایشگاهی و ارسال سریع تیپاکس.');
  const [ctaButtonText, setCtaButtonText] = useState('مشاهده و خرید محصولات با ضمانت اصالت');
  const [savedNotice, setSavedNotice] = useState(false);

  const selectedPage = pages.find(p => p.id === selectedPageId) || pages[0];

  const handleSaveDesign = () => {
    onSaveSnapshot(`طراحی جدید ${selectedPage.title} با پالت سبز جنگلی و طلایی`, {
      pageId: selectedPageId,
      colors: { forestGreen, oliveGreen, champagneGold, warmIvory },
      borderRadius,
      fontFamily,
      content: { heroTitle, heroSubtitle, ctaButtonText }
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Studio Header & Navigation */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
            <Palette className="w-4 h-4 text-[#d4af37]" />
            <span>Goli Design Studio — محیط تخصصی بازطراحی المنتور و دیزاین سیستم</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black">
            استودیوی بازطراحی هویت بصری و تجربه کاربری وبسایت
          </h1>
          <p className="text-xs text-[#c4d6ce]">
            پالت سبز تیره جنگلی (#0f382c)، طلایی شامپاینی (#d4af37) و عاجی گرم (#fcfbf7) مطابق سند فنی گلیکالا.
          </p>
        </div>

        {/* Viewport & View Mode controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Viewport Toggles */}
          <div className="flex items-center bg-[#08241c] p-1 rounded-2xl border border-[#1b4e3e]">
            <button
              onClick={() => setViewport('desktop')}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                viewport === 'desktop' ? 'bg-[#d4af37] text-[#0f382c] shadow-xs' : 'text-[#c4d6ce] hover:text-white'
              }`}
              title="پیش‌نمایش دسکتاپ (1280px)"
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewport('tablet')}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                viewport === 'tablet' ? 'bg-[#d4af37] text-[#0f382c] shadow-xs' : 'text-[#c4d6ce] hover:text-white'
              }`}
              title="پیش‌نمایش تبلت (768px)"
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewport('mobile')}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                viewport === 'mobile' ? 'bg-[#d4af37] text-[#0f382c] shadow-xs' : 'text-[#c4d6ce] hover:text-white'
              }`}
              title="پیش‌نمایش موبایل (375px)"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center bg-[#08241c] p-1 rounded-2xl border border-[#1b4e3e] text-xs">
            <button
              onClick={() => setViewMode('editor')}
              className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-all ${
                viewMode === 'editor' ? 'bg-white/20 text-white' : 'text-[#c4d6ce]'
              }`}
            >
              ویرایشگر زنده
            </button>
            <button
              onClick={() => setViewMode('diff')}
              className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-all ${
                viewMode === 'diff' ? 'bg-white/20 text-white' : 'text-[#c4d6ce]'
              }`}
            >
              مقایسه قبل و بعد
            </button>
          </div>

          <button
            onClick={handleSaveDesign}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] rounded-xl text-xs font-black shadow-md cursor-pointer hover:scale-102 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>ذخیره نسخه</span>
          </button>
        </div>
      </div>

      {savedNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>نسخه بازطراحی شده با موفقیت به همراه متادیتای المنتور در تاریخچه تغییرات ذخیره گردید.</span>
        </div>
      )}

      {/* Main Studio Grid: Controls & Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Controls Sidebar (4 cols) */}
        <div className="lg:col-span-4 space-y-5 bg-white rounded-3xl border border-slate-200 p-5 shadow-xs">
          
          {/* Target Page Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              انتخاب صفحه یا قالب المنتور جهت بازطراحی :
            </label>
            <select
              value={selectedPageId}
              onChange={(e) => setSelectedPageId(Number(e.target.value))}
              className="w-full p-2.5 bg-[#fcfbf7] border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-hidden focus:border-[#0f382c]"
            >
              {pages.map(p => (
                <option key={p.id} value={p.id}>
                  {p.title} ({p.slug})
                </option>
              ))}
            </select>
          </div>

          {/* Unified Design System Palette Controls (PART 5.1) */}
          <div className="space-y-3 pt-3 border-t border-slate-100 text-xs">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Palette className="w-4 h-4 text-[#0f382c]" />
              <span>پالت رنگ‌های سازمانی بازرگانی گلی :</span>
            </h4>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <span className="text-slate-500 block">سبز جنگلی اصلی :</span>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={forestGreen}
                    onChange={(e) => setForestGreen(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0"
                  />
                  <span className="font-mono font-bold text-slate-800">{forestGreen}</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <span className="text-slate-500 block">طلایی شامپاینی :</span>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={champagneGold}
                    onChange={(e) => setChampagneGold(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0"
                  />
                  <span className="font-mono font-bold text-slate-800">{champagneGold}</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <span className="text-slate-500 block">سبز زیتونی ثانویه :</span>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={oliveGreen}
                    onChange={(e) => setOliveGreen(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0"
                  />
                  <span className="font-mono font-bold text-slate-800">{oliveGreen}</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                <span className="text-slate-500 block">عاجی گرم سطوح :</span>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={warmIvory}
                    onChange={(e) => setWarmIvory(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0"
                  />
                  <span className="font-mono font-bold text-slate-800">{warmIvory}</span>
                </div>
              </div>
            </div>

            {/* Border Radius */}
            <div className="space-y-1 pt-1">
              <div className="flex justify-between">
                <span className="text-slate-600 font-bold">شعاع گردی دکمه‌ها و کانتینرها :</span>
                <span className="font-mono font-bold text-[#0f382c]">{borderRadius}px</span>
              </div>
              <input
                type="range"
                min={4}
                max={30}
                value={borderRadius}
                onChange={(e) => setBorderRadius(Number(e.target.value))}
                className="w-full accent-[#0f382c] cursor-pointer"
              />
            </div>
          </div>

          {/* Text and Section Customizer */}
          <div className="space-y-3 pt-3 border-t border-slate-100 text-xs">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-[#0f382c]" />
              <span>ویرایش محتوای سکشن اصلی :</span>
            </h4>

            <div>
              <label className="block text-slate-600 font-bold mb-1">عنوان اصلی سکشن :</label>
              <textarea
                rows={2}
                value={heroTitle}
                onChange={(e) => setHeroTitle(e.target.value)}
                className="w-full p-2 bg-[#fcfbf7] border border-slate-200 rounded-xl text-xs outline-hidden focus:border-[#0f382c]"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-bold mb-1">زیرعنوان و توضیحات رسمی :</label>
              <textarea
                rows={2}
                value={heroSubtitle}
                onChange={(e) => setHeroSubtitle(e.target.value)}
                className="w-full p-2 bg-[#fcfbf7] border border-slate-200 rounded-xl text-xs outline-hidden focus:border-[#0f382c]"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-bold mb-1">متن دکمه اکشن (CTA) :</label>
              <input
                type="text"
                value={ctaButtonText}
                onChange={(e) => setCtaButtonText(e.target.value)}
                className="w-full p-2 bg-[#fcfbf7] border border-slate-200 rounded-xl text-xs outline-hidden focus:border-[#0f382c]"
              />
            </div>
          </div>

        </div>

        {/* Live Canvas Preview (8 cols) */}
        <div className="lg:col-span-8 flex justify-center">
          <div 
            className={`bg-white rounded-3xl shadow-2xl overflow-hidden border-4 border-[#0f382c] transition-all duration-300 ${
              viewport === 'desktop' 
                ? 'w-full' 
                : viewport === 'tablet' 
                ? 'w-[768px] max-w-full' 
                : 'w-[375px] max-w-full'
            }`}
          >
            
            {/* Virtual Browser Top */}
            <div className="bg-[#0f382c] px-4 py-2 text-white flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-400" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              </div>
              <span className="text-[11px] text-[#fcfbf7]">https://golikala.com/{selectedPage.slug}/</span>
              <span className="text-[10px] bg-[#d4af37] text-[#0f382c] font-bold px-2 py-0.5 rounded-md">
                {viewport === 'desktop' ? 'Desktop 1280px' : viewport === 'tablet' ? 'Tablet 768px' : 'Mobile 375px'}
              </span>
            </div>

            {/* Canvas Body */}
            {viewMode === 'editor' && (
              <div className="p-6 space-y-6 text-right" style={{ backgroundColor: warmIvory }}>
                
                {/* Announcement Bar */}
                <div 
                  className="p-2.5 text-white text-xs font-bold text-center flex items-center justify-center gap-2 shadow-xs"
                  style={{ backgroundColor: forestGreen, borderRadius: `${borderRadius}px` }}
                >
                  <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
                  <span>نمایندگی رسمی و انحصاری محصولات اروپایی آمالفی، آگرادو و سایرو در ایران</span>
                </div>

                {/* Hero Section Container */}
                <div 
                  className="p-6 sm:p-8 border relative overflow-hidden"
                  style={{ 
                    backgroundColor: forestGreen, 
                    borderRadius: `${borderRadius}px`,
                    borderColor: 'rgba(212, 175, 55, 0.3)'
                  }}
                >
                  <div className="relative z-10 space-y-4 max-w-xl text-white">
                    <span 
                      className="inline-block px-3 py-1 rounded-full text-xs font-bold"
                      style={{ backgroundColor: 'rgba(212, 175, 55, 0.2)', color: '#f3e5ab' }}
                    >
                      واردات رسمی و مستقیم بازرگانی گلی
                    </span>

                    <h2 className="text-xl sm:text-2xl font-black leading-tight text-white">
                      {heroTitle}
                    </h2>

                    <p className="text-xs sm:text-sm text-[#c4d6ce] leading-relaxed font-normal">
                      {heroSubtitle}
                    </p>

                    <div className="pt-2 flex flex-wrap gap-3">
                      <button
                        className="px-5 py-2.5 text-xs font-black shadow-md cursor-pointer transition-transform hover:scale-102"
                        style={{ 
                          backgroundColor: champagneGold, 
                          color: forestGreen,
                          borderRadius: `${borderRadius}px` 
                        }}
                      >
                        {ctaButtonText}
                      </button>

                      <button
                        className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition-colors"
                        style={{ borderRadius: `${borderRadius}px` }}
                      >
                        استعلام آنلاین بچ‌کد اصالت
                      </button>
                    </div>
                  </div>
                </div>

                {/* 3 Brand Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  {[
                    { name: 'آگرادو (Agrado Spain)', desc: 'شامپو و ماسک کراتینه تخصصی احیای مو' },
                    { name: 'آمالفی (Amalfi Spain)', desc: 'لوسیون های آبرسان آلوئه ورا و روغن آرگان' },
                    { name: 'سایرو (Syro Europe)', desc: 'میسلار واتر درماتولوژی پوست های به شدت حساس' }
                  ].map((b, i) => (
                    <div 
                      key={i}
                      className="p-4 bg-white border border-slate-200 shadow-2xs space-y-1.5"
                      style={{ borderRadius: `${borderRadius}px` }}
                    >
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-md inline-block bg-[#0f382c]/10 text-[#0f382c]">
                        نمایندگی رسمی
                      </span>
                      <h4 className="text-xs font-black text-slate-900">{b.name}</h4>
                      <p className="text-[11px] text-slate-500 font-normal">{b.desc}</p>
                    </div>
                  ))}
                </div>

              </div>
            )}

            {/* Before and After Visual Diff Mode */}
            {viewMode === 'diff' && (
              <div className="p-6 space-y-6 text-right">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Before */}
                  <div className="p-5 rounded-2xl bg-slate-100 border border-slate-300 space-y-3 opacity-80">
                    <span className="text-xs font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded-md">
                      طراحی قدیمی (قالب معمولی)
                    </span>
                    <h4 className="text-sm font-bold text-slate-700">فروشگاه لوازم بهداشتی و آرایشی</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-normal">
                      قالب استاندارد ووکامرس بدون مشخص بودن هویت نمایندگی رسمی برندهای آگرادو و آمالفی و بدون دیزاین سیستم یکپارچه.
                    </p>
                  </div>

                  {/* After */}
                  <div 
                    className="p-5 rounded-2xl text-white space-y-3 shadow-lg"
                    style={{ backgroundColor: forestGreen, borderRadius: `${borderRadius}px` }}
                  >
                    <span className="text-xs font-bold px-2 py-0.5 rounded-md" style={{ backgroundColor: champagneGold, color: forestGreen }}>
                      طراحی جدید Goli Design Studio
                    </span>
                    <h4 className="text-sm font-black text-white">{heroTitle}</h4>
                    <p className="text-xs text-[#c4d6ce] leading-relaxed font-normal">
                      هویت لوکس سبز تیره و طلایی، تضمین ۱۰۰٪ اصالت اروپایی و سازگاری کامل با المنتور.
                    </p>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
};
