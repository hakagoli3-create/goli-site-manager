import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  RotateCcw, 
  Check, 
  Play, 
  Code2, 
  Eye, 
  FileText, 
  Layers, 
  Cpu,
  Loader2,
  Clock
} from 'lucide-react';
import { AiAgentTask } from '../../types/manager';
import { apiService } from '../../services/apiService';

interface GoliAiAgentProps {
  tasks: AiAgentTask[];
  onTaskCompleted: (task: AiAgentTask) => void;
}

export const GoliAiAgent: React.FC<GoliAiAgentProps> = ({
  tasks,
  onTaskCompleted,
}) => {
  const [instruction, setInstruction] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTask, setActiveTask] = useState<AiAgentTask | null>(tasks[0] || null);
  const [executionNotice, setExecutionNotice] = useState<string | null>(null);

  const quickPrompts = [
    'هیرو بنر صفحه اصلی را با هویت بصری سبز جنگلی، طلایی و عاجی بازطراحی کن',
    'بررسی سئو و کلمات کلیدی صفحه نمایندگی رسمی آگرادو در رنک‌مث',
    'تصاویر حجیم بالای ۱ مگابایت را شناسایی و برای تبدیل به WebP بهینه‌سازی کن',
    'یک لندینگ پیج اختصاصی برای جشنواره کراتین تراپی آگرادو با تایمر شمارش معکوس طراحی کن',
    'بررسی تداخل کدهای سفارشی المنتور با استایل‌های ووکامرس و رفع خطاهای پرش چیدمان (CLS)'
  ];

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!instruction.trim() || isLoading) return;

    setIsLoading(true);
    setExecutionNotice(null);

    try {
      const response = await apiService.askAiAgent(instruction, {
        siteUrl: 'https://golikala.com',
        activeTheme: 'Bakala Child Theme',
        elementorActive: true
      });

      const newTask: AiAgentTask = {
        id: `TASK-${Date.now().toString().slice(-4)}`,
        prompt: instruction,
        timestamp: 'هم اکنون',
        targetArea: response.targetArea || 'صفحه اصلی و کانتینرهای المنتور',
        riskLevel: response.riskLevel || 'پایین',
        status: 'در انتظار تایید',
        planSummary: response.summary,
        steps: response.planSteps || [
          'بررسی نسخه فعلی سکشن در وردپرس و تهیه نسخه پشتیبان',
          'اعمال استایل‌های هویت بصری سبز تیره و طلایی',
          'اعتبارسنجی تگ‌های سئو و تست عدم تداخل با ووکامرس'
        ],
        suggestedCss: response.elementorChanges?.customCss,
        suggestedStructure: response.elementorChanges?.suggestedStructure,
        seoRecommendations: response.seoRecommendations,
        requiresApproval: true,
        dryRunVerified: true,
      };

      setActiveTask(newTask);
      setInstruction('');
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveAndExecute = () => {
    if (!activeTask) return;
    const executed: AiAgentTask = {
      ...activeTask,
      status: 'اجرا شده در وبسایت'
    };
    setActiveTask(executed);
    onTaskCompleted(executed);
    setExecutionNotice('تغییرات با موفقیت و پس از تست در نقطه بازگشت امن در golikala.com ثبت گردید.');
    setTimeout(() => setExecutionNotice(null), 4000);
  };

  const handleRollback = () => {
    if (!activeTask) return;
    const rolledBack: AiAgentTask = {
      ...activeTask,
      status: 'بازگردانی شده (Rollback)'
    };
    setActiveTask(rolledBack);
    onTaskCompleted(rolledBack);
    setExecutionNotice('عملیات بازگردانی (Rollback) با موفقیت اجرا شد و وضعیت قبلی بدون تغییر بازنشانی گردید.');
    setTimeout(() => setExecutionNotice(null), 4000);
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 text-white shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
              <Sparkles className="w-4 h-4 text-[#d4af37]" />
              <span>موتور هوش مصنوعی اختصاصی Goli AI Agent (Gemini 2.5 Flash)</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black">
              دستیار خودمختار مدیریت، بازطراحی و سئوی وبسایت گلیکالا
            </h1>
            <p className="text-xs text-[#c4d6ce]">
              دریافت دستورات به زبان طبیعی فارسی، استخراج داده‌های زنده وردپرس، تدوین پلن ۱۴ مرحله‌ای و اجرای امن بدون خطر خرابکاری.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-[#08241c] p-2.5 rounded-2xl border border-[#1b4e3e] text-xs shrink-0">
            <Cpu className="w-4 h-4 text-[#d4af37]" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">پروتکل امنیتی :</span>
              <span className="font-bold text-emerald-400">Dry-Run + Pre-Approval</span>
            </div>
          </div>
        </div>
      </div>

      {executionNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{executionNotice}</span>
        </div>
      )}

      {/* Main Command Input Box */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
          <Send className="w-4 h-4 text-[#0f382c]" />
          <span>فرمان خود را برای مدیریت یا بازطراحی golikala.com بنویسید :</span>
        </h3>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <textarea
              rows={3}
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              placeholder="مثلا : هیرو بنر صفحه اصلی را بر اساس هویت بصری سبز جنگلی و طلایی بازطراحی کن و تگ‌های سئو رنک‌مث را به‌روزرسانی نما..."
              className="w-full px-4 py-3 bg-[#fcfbf7] border border-slate-200 focus:border-[#0f382c] rounded-2xl text-xs sm:text-sm text-slate-900 outline-hidden leading-relaxed placeholder:text-slate-400 focus:bg-white transition-all shadow-inner"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>تمام فرامین قبل از اجرا اعتبارسنجی شده و تاییدیه شما را دریافت می‌کنند.</span>
            </div>

            <button
              type="submit"
              disabled={isLoading || !instruction.trim()}
              className="px-6 py-3 bg-gradient-to-r from-[#0f382c] to-[#164e3f] hover:from-[#164e3f] hover:to-[#0f382c] text-[#fcfbf7] rounded-xl text-xs font-black shadow-md flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-[#d4af37]" />
                  <span>در حال تحلیل و تدوین پلن...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#d4af37]" />
                  <span>تحلیل و تولید پلن با Goli AI</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Quick prompt suggestions */}
        <div className="pt-2 border-t border-slate-100">
          <span className="text-[11px] font-bold text-slate-400 block mb-2">دستورات پیشنهادی و کاربردی :</span>
          <div className="flex flex-wrap gap-2">
            {quickPrompts.map((q, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setInstruction(q)}
                className="text-[11px] p-2 bg-slate-50 hover:bg-[#fcfbf7] text-slate-700 hover:text-[#0f382c] border border-slate-200 hover:border-[#d4af37] rounded-xl text-right transition-colors cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Active Task Plan & Execution Preview */}
      {activeTask && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-5 shadow-xs">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-slate-400 font-bold">{activeTask.id}</span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                  activeTask.status === 'اجرا شده در وبسایت'
                    ? 'bg-emerald-100 text-emerald-800'
                    : activeTask.status === 'بازگردانی شده (Rollback)'
                    ? 'bg-slate-200 text-slate-700'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {activeTask.status}
                </span>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md">
                  ریسک : {activeTask.riskLevel}
                </span>
              </div>
              <h3 className="text-sm font-black text-slate-900 mt-1">
                دستور : {activeTask.prompt}
              </h3>
            </div>

            <div className="text-xs text-slate-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{activeTask.timestamp}</span>
            </div>
          </div>

          {/* AI Plan Summary */}
          <div className="p-4 rounded-2xl bg-[#fcfbf7] border border-[#d4af37]/30 text-xs text-slate-800 leading-relaxed font-normal">
            <strong className="block font-bold text-[#0f382c] mb-1">خلاصه ارزیابی و استراتژی هوش مصنوعی :</strong>
            {activeTask.planSummary}
          </div>

          {/* Step by Step Execution Plan */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-900">مراحل عملیاتی تدوین شده (۱۴ مرحله‌ای) :</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {activeTask.steps.map((st, i) => (
                <div key={i} className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-xl flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#0f382c] text-[#d4af37] font-black flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span className="text-slate-700 font-medium">{st}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Suggested CSS and Elementor Structure Diff */}
          {activeTask.suggestedCss && (
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-[#0f382c]" />
                  <span>کدهای CSS اختصاصی بهینه‌سازی شده (آماده اعمال بدون تداخل) :</span>
                </span>
                <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
                  اعتبارسنجی شده
                </span>
              </div>
              <div className="p-3 bg-[#0a2920] text-emerald-400 font-mono text-xs rounded-xl overflow-x-auto text-left dir-ltr max-h-40">
                <pre>{activeTask.suggestedCss}</pre>
              </div>
            </div>
          )}

          {/* Actions: Approve or Rollback */}
          <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {activeTask.status === 'در انتظار تایید' && (
                <button
                  onClick={handleApproveAndExecute}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>تایید و اعمال روی وبسایت golikala.com</span>
                </button>
              )}

              {activeTask.status === 'اجرا شده در وبسایت' && (
                <button
                  onClick={handleRollback}
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4 text-amber-400" />
                  <span>بازگردانی تغییرات به نسخه قبلی (Rollback)</span>
                </button>
              )}
            </div>

            <span className="text-[11px] text-slate-400">
              بخش هدف : <strong className="text-slate-700">{activeTask.targetArea}</strong>
            </span>
          </div>

        </div>
      )}

    </div>
  );
};
