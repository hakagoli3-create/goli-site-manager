import React, { useState } from 'react';
import { 
  FileText, 
  ExternalLink, 
  Edit3, 
  Sparkles, 
  RefreshCw, 
  Search, 
  CheckCircle2, 
  Layers, 
  ArrowUpRight, 
  Filter, 
  Plus, 
  ShieldCheck, 
  Calendar, 
  Cpu, 
  Globe 
} from 'lucide-react';
import { WordPressPage } from '../../types/manager';
import { WORDPRESS_PAGES } from '../../data/managerMockData';

interface PagesManagerProps {
  pages?: WordPressPage[];
  onOpenDesignStudio?: (pageId: number) => void;
  onPreviewPage?: (slug: string) => void;
}

export function PagesManager({ pages: initialPages = WORDPRESS_PAGES, onOpenDesignStudio, onPreviewPage }: PagesManagerProps) {
  const [pages, setPages] = useState<WordPressPage[]>(initialPages);

  React.useEffect(() => {
    if (initialPages && initialPages.length > 0) {
      setPages(initialPages);
    }
  }, [initialPages]);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'elementor' | 'high-seo' | 'low-seo'>('all');
  const [editingPage, setEditingPage] = useState<WordPressPage | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [purgingId, setPurgingId] = useState<number | null>(null);

  // Filters
  const filteredPages = pages.filter(page => {
    const matchesSearch = page.title.includes(searchQuery) || page.slug.includes(searchQuery) || page.focusKeyword.includes(searchQuery);
    if (!matchesSearch) return false;

    if (filterType === 'elementor') return page.isElementor;
    if (filterType === 'high-seo') return page.rankMathScore >= 95;
    if (filterType === 'low-seo') return page.rankMathScore < 95;
    return true;
  });

  // Purge LiteSpeed Cache for a single page
  const handlePurgePageCache = (page: WordPressPage) => {
    setPurgingId(page.id);
    setTimeout(() => {
      setPurgingId(null);
      setActionNotice(`کش لایت‌اسپید برای برگه "${page.title}" با موفقیت در سراسر شبکه CDN پاک‌سازی شد.`);
      setTimeout(() => setActionNotice(null), 4000);
    }, 800);
  };

  // Save quick SEO edits
  const handleSaveSeoEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPage) return;

    setPages(prev => prev.map(p => p.id === editingPage.id ? editingPage : p));
    setActionNotice(`تنظیمات رنک‌مث برای برگه "${editingPage.title}" با موفقیت در وردپرس ذخیره شد.`);
    setEditingPage(null);
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-[#0f382c]/10 text-[#0f382c]">
              <Layers className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800">مدیریت برگه‌ها و صفحات وردپرس (WordPress Pages)</h2>
          </div>
          <p className="text-sm text-slate-500">
            رصد وضعیت ویرایشگر المنتور، نمرات سئوی رنک‌مث، کلمات کلیدی کانونی و بازطراحی زنده
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => onOpenDesignStudio && onOpenDesignStudio(12)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#0f382c] to-[#3d5a45] text-white text-sm font-semibold hover:opacity-95 transition shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-[#d4af37]" />
            <span>ویرایش صفحه اصلی در استودیو دیزاین</span>
          </button>
        </div>
      </div>

      {actionNotice && (
        <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'all' ? 'bg-[#0f382c] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            همه برگه‌ها ({pages.length})
          </button>
          <button
            onClick={() => setFilterType('elementor')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'elementor' ? 'bg-[#0f382c] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            ساخته شده با المنتور ({pages.filter(p => p.isElementor).length})
          </button>
          <button
            onClick={() => setFilterType('high-seo')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'high-seo' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
            }`}
          >
            سئوی عالی رنک‌مث (≥ ۹۵)
          </button>
        </div>

        <div className="relative w-full md:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو در برگه‌ها یا کلمات کلیدی..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:outline-hidden focus:border-[#0f382c]"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-2" />
        </div>
      </div>

      {/* Pages Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
              <tr>
                <th className="py-3 px-4">عنوان برگه</th>
                <th className="py-3 px-4">شناسه و اسلاگ</th>
                <th className="py-3 px-4 text-center">وضعیت المنتور</th>
                <th className="py-3 px-4 text-center">نمره رنک‌مث پرو</th>
                <th className="py-3 px-4">کلمه کلیدی کانونی</th>
                <th className="py-3 px-4">آخرین ویرایش</th>
                <th className="py-3 px-4 text-center">عملیات مدیریت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPages.map(page => (
                <tr key={page.id} className="hover:bg-slate-50/70 transition">
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-800 text-sm">{page.title}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">نویسنده: {page.author} • قالب: {page.template}</div>
                  </td>

                  <td className="py-3.5 px-4 font-mono">
                    <span className="text-slate-500 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      /{page.slug}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-0.5">ID: {page.id}</div>
                  </td>

                  <td className="py-3.5 px-4 text-center">
                    {page.isElementor ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        <Cpu className="w-3 h-3 text-emerald-600" />
                        <span>Elementor Pro</span>
                      </span>
                    ) : (
                      <span className="text-slate-400 text-xs">ویرایشگر پیش‌فرض</span>
                    )}
                  </td>

                  <td className="py-3.5 px-4 text-center">
                    <span className={`inline-flex items-center justify-center font-bold px-2.5 py-1 rounded-full text-xs font-mono ${
                      page.rankMathScore >= 95 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : page.rankMathScore >= 80 
                        ? 'bg-amber-100 text-amber-800' 
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {page.rankMathScore}/100
                    </span>
                  </td>

                  <td className="py-3.5 px-4 max-w-xs">
                    <div className="text-slate-700 font-medium truncate" title={page.focusKeyword}>
                      {page.focusKeyword}
                    </div>
                  </td>

                  <td className="py-3.5 px-4 text-slate-500 whitespace-nowrap">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      <span>{page.modified}</span>
                    </div>
                  </td>

                  <td className="py-3.5 px-4 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => onOpenDesignStudio && onOpenDesignStudio(page.id)}
                        className="p-1.5 rounded-lg bg-[#0f382c]/10 text-[#0f382c] hover:bg-[#0f382c]/20 transition"
                        title="ویرایش در استودیو دیزاین گلی"
                      >
                        <Sparkles className="w-4 h-4 text-[#0f382c]" />
                      </button>

                      <button
                        onClick={() => setEditingPage(page)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition"
                        title="ویرایش سریع سئو و کلمات کلیدی"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handlePurgePageCache(page)}
                        disabled={purgingId === page.id}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition"
                        title="پاک‌سازی کش لایت‌اسپید این صفحه"
                      >
                        <RefreshCw className={`w-4 h-4 ${purgingId === page.id ? 'animate-spin text-emerald-600' : ''}`} />
                      </button>

                      <button
                        onClick={() => onPreviewPage && onPreviewPage(page.slug)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 transition"
                        title="پیش‌نمایش زنده در فروشگاه"
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SEO Quick Edit Modal */}
      {editingPage && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800 flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-[#0f382c]" />
                <span>ویرایش سریع سئو و متادیتا (Rank Math Pro)</span>
              </h3>
              <button onClick={() => setEditingPage(null)} className="text-slate-400 hover:text-slate-600 text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSeoEdit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">عنوان برگه در سئو (Title Tag)</label>
                <input
                  type="text"
                  value={editingPage.title}
                  onChange={(e) => setEditingPage({ ...editingPage, title: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#0f382c]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">کلمه کلیدی کانونی (Focus Keyword)</label>
                <input
                  type="text"
                  value={editingPage.focusKeyword}
                  onChange={(e) => setEditingPage({ ...editingPage, focusKeyword: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#0f382c]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">اسلاگ برگه (Slug)</label>
                  <input
                    type="text"
                    value={editingPage.slug}
                    onChange={(e) => setEditingPage({ ...editingPage, slug: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">نمره تخمینی رنک‌مث</label>
                  <input
                    type="number"
                    max={100}
                    min={0}
                    value={editingPage.rankMathScore}
                    onChange={(e) => setEditingPage({ ...editingPage, rankMathScore: parseInt(e.target.value) || 0 })}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingPage(null)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0f382c] text-white text-xs font-semibold hover:bg-[#174d3d]"
                >
                  ذخیره تغییرات در وردپرس
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
