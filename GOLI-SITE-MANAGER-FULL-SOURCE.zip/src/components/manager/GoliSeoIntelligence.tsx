import React, { useState } from 'react';
import { 
  TrendingUp, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  Copy, 
  Check, 
  ExternalLink, 
  Eye, 
  Globe, 
  BarChart2, 
  Code2,
  FileSearch
} from 'lucide-react';
import { SeoAuditItem } from '../../types/manager';

interface GoliSeoIntelligenceProps {
  seoItems: SeoAuditItem[];
}

export const GoliSeoIntelligence: React.FC<GoliSeoIntelligenceProps> = ({
  seoItems,
}) => {
  const [selectedItem, setSelectedItem] = useState<SeoAuditItem>(seoItems[0]);
  const [copiedSchema, setCopiedSchema] = useState(false);

  const jsonLdSchemaCode = `{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://golikala.com/#organization",
      "name": "بازرگانی گلی کالا",
      "url": "https://golikala.com",
      "logo": "https://golikala.com/wp-content/uploads/logo.png",
      "description": "نماینده رسمی و واردکننده مستقیم برندهای اروپایی آمالفی، آگرادو و سایرو در ایران با ضمانت کتبی اصالت کالا",
      "sameAs": [
        "https://www.instagram.com/golikala",
        "https://t.me/golikala"
      ]
    },
    {
      "@type": "WebSite",
      "@id": "https://golikala.com/#website",
      "url": "https://golikala.com",
      "name": "گلی کالا | فروشگاه تخصصی محصولات اروپایی",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://golikala.com/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
  ]
}`;

  const handleCopySchema = () => {
    navigator.clipboard.writeText(jsonLdSchemaCode);
    setCopiedSchema(true);
    setTimeout(() => setCopiedSchema(false), 2000);
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
            <TrendingUp className="w-4 h-4 text-[#d4af37]" />
            <span>Goli SEO Intelligence — مدیریت یکپارچه رنک‌مث پرو و سرچ کنسول گوگل</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black">
            تحلیل سئو، اسکیماهای ساختاریافته و کلمات کلیدی کانونی
          </h1>
          <p className="text-xs text-[#c4d6ce]">
            پایش رتبه‌های ارگانیک برندهای آگرادو، آمالفی و سایرو بر اساس آخرین آپدیت الگوریتم‌های ۲۰۲۶ گوگل.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#08241c] p-3 rounded-2xl border border-[#1b4e3e] text-xs">
          <BarChart2 className="w-5 h-5 text-[#d4af37]" />
          <div>
            <span className="text-[10px] text-slate-400 block">نمره میانگین رنک‌مث :</span>
            <strong className="text-emerald-400 font-mono text-sm">۹۸ / ۱۰۰ (عالی)</strong>
          </div>
        </div>
      </div>

      {/* SEO Audit Table & Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Audit List (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-black text-slate-900">
            برگه‌های شاخص و وضعیت سئو در وبسایت golikala.com :
          </h3>

          <div className="space-y-2.5">
            {seoItems.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  selectedItem.id === item.id
                    ? 'border-[#0f382c] bg-[#fcfbf7] shadow-xs'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs">
                  <span className="font-bold text-slate-900 line-clamp-1">{item.pageTitle}</span>
                  <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md text-[11px]">
                    نمره : {item.score}
                  </span>
                </div>

                <div className="py-2 space-y-1 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span>کلمه کلیدی کانونی :</span>
                    <strong className="text-[#0f382c]">{item.focusKeyword}</strong>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>آدرس URL :</span>
                    <span>{item.url}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{item.indexingStatus}</span>
                  </span>
                  <span className="text-slate-400 font-mono">
                    {item.searchConsoleImpressions?.toLocaleString('fa-IR')} ایمپرشن | {item.searchConsoleClicks?.toLocaleString('fa-IR')} کلیک
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: SERP & Schema Inspector (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Google SERP Preview Box */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-3 shadow-xs text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="font-bold text-slate-900 flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-blue-600" />
                <span>پیش‌نمایش در نتایج جستجوی گوگل (Google SERP)</span>
              </span>
              <span className="text-[10px] text-slate-400">Desktop & Mobile</span>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-1 text-right">
              <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                <span>https://golikala.com</span>
                <span>›</span>
                <span>{selectedItem.url.replace('https://golikala.com/', '')}</span>
              </div>
              <div className="text-sm font-bold text-blue-700 hover:underline cursor-pointer leading-snug">
                {selectedItem.pageTitle}
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                فروشگاه اینترنتی گلی کالا، نماینده رسمی و مستقیم برندهای برجسته اروپایی آمالفی، آگرادو و سایرو در ایران با ضمانت قطعی اصالت کالا و ارسال سریع تیپاکس.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block">طول عنوان :</span>
                <strong className="text-emerald-700">{selectedItem.titleLength} کاراکتر (ایده‌آل)</strong>
              </div>
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block">طول متا دسکریپشن :</span>
                <strong className="text-emerald-700">{selectedItem.descLength} کاراکتر (ایده‌آل)</strong>
              </div>
            </div>
          </div>

          {/* JSON-LD Schema Inspector */}
          <div className="bg-[#0f382c] text-white rounded-3xl border border-[#d4af37]/30 p-6 space-y-3 shadow-md">
            <div className="flex items-center justify-between pb-2 border-b border-[#1b4e3e]">
              <span className="font-bold text-xs flex items-center gap-1.5 text-[#fcfbf7]">
                <Code2 className="w-4 h-4 text-[#d4af37]" />
                <span>اسکیمای رسمی JSON-LD رنک‌مث</span>
              </span>
              <button
                onClick={handleCopySchema}
                className="text-[11px] text-[#d4af37] hover:underline flex items-center gap-1 cursor-pointer"
              >
                {copiedSchema ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSchema ? 'کپی شد' : 'کپی اسکیما'}</span>
              </button>
            </div>

            <div className="p-3 bg-[#08241c] rounded-xl text-[11px] font-mono text-emerald-400 text-left dir-ltr max-h-48 overflow-y-auto leading-relaxed">
              <pre>{jsonLdSchemaCode}</pre>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
