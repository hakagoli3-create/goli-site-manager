import React from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  RefreshCw, 
  ExternalLink, 
  CheckCircle2, 
  Store, 
  Sliders, 
  Wifi, 
  User,
  Zap
} from 'lucide-react';
import { SiteConnection } from '../../types/manager';

interface TopBarProps {
  connection: SiteConnection;
  isChecking: boolean;
  onRefreshConnection: () => void;
  activeAppMode: 'manager' | 'storefront';
  setActiveAppMode: (mode: 'manager' | 'storefront') => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  connection,
  isChecking,
  onRefreshConnection,
  activeAppMode,
  setActiveAppMode,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0f382c] text-white border-b border-[#1b4e3e] shadow-md text-right">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        
        {/* Right: Brand and Mode Switcher */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#d4af37] to-[#f3e5ab] flex items-center justify-center text-[#0f382c] font-black shadow-md shadow-[#0f382c]/40 shrink-0">
            <Sparkles className="w-5 h-5 text-[#0f382c]" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm sm:text-base font-black tracking-tight text-[#fcfbf7]">
                GOLI SITE MANAGER
              </span>
              <span className="text-[10px] bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40 px-2 py-0.5 rounded-full font-bold">
                نسخه پرو ۲۰۲۶
              </span>
            </div>
            <div className="text-[11px] text-[#c4d6ce] flex items-center gap-1.5 font-medium">
              <span>مدیریت هوشمند وردپرس و المنتور :</span>
              <strong className="text-white">golikala.com</strong>
            </div>
          </div>
        </div>

        {/* Center: Live Connection Pill */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-[#08241c] border border-[#1b4e3e] text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-300 font-bold">اتصال زنده وردپرس :</span>
          </div>
          <span className="font-mono text-white text-[11px] font-bold">https://golikala.com</span>
          <span className="text-slate-400">|</span>
          <span className="text-[#d4af37] font-mono text-[11px]">{connection.latencyMs}ms</span>
          <span className="text-slate-400">|</span>
          <span className="text-emerald-400 font-bold text-[10px]">LiteSpeed Active</span>
        </div>

        {/* Left: Mode Switcher & Admin Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Refresh Connection Button */}
          <button
            onClick={onRefreshConnection}
            disabled={isChecking}
            className="p-2 rounded-xl bg-[#08241c] hover:bg-[#164e3f] text-[#c4d6ce] hover:text-white border border-[#1b4e3e] transition-colors cursor-pointer"
            title="بررسی مجدد اتصال زنده"
          >
            <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin text-[#d4af37]' : ''}`} />
          </button>

          {/* Mode Switcher Buttons */}
          <div className="flex items-center bg-[#08241c] p-1 rounded-2xl border border-[#1b4e3e]">
            <button
              onClick={() => setActiveAppMode('manager')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeAppMode === 'manager'
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] shadow-sm font-black'
                  : 'text-[#c4d6ce] hover:text-white'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>پنل مدیریت سایت</span>
            </button>

            <button
              onClick={() => setActiveAppMode('storefront')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeAppMode === 'storefront'
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] shadow-sm font-black'
                  : 'text-[#c4d6ce] hover:text-white'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>پیش‌نمایش زنده فروشگاه</span>
            </button>
          </div>

          {/* Admin User Badge */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#08241c] border border-[#1b4e3e] text-xs">
            <User className="w-3.5 h-3.5 text-[#d4af37]" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-normal">مدیر سایت :</span>
              <span className="font-bold text-white text-[11px]">newadmin</span>
            </div>
          </div>

        </div>

      </div>
    </header>
  );
};
