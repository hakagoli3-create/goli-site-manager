import React, { useState } from 'react';
import { 
  Database, 
  RotateCcw, 
  ShieldCheck, 
  FileCode, 
  Clock, 
  HardDrive, 
  Plus, 
  CheckCircle2, 
  AlertTriangle, 
  Eye, 
  Download, 
  ArrowLeftRight,
  Sparkles,
  Info
} from 'lucide-react';
import { BackupSnapshot } from '../../types/manager';
import { BACKUP_SNAPSHOTS } from '../../data/managerMockData';

export function BackupManager() {
  const [snapshots, setSnapshots] = useState<BackupSnapshot[]>(BACKUP_SNAPSHOTS);
  const [selectedSnapshot, setSelectedSnapshot] = useState<BackupSnapshot | null>(snapshots[0]);
  const [isCreating, setIsCreating] = useState(false);
  const [newSnapshotName, setNewSnapshotName] = useState('');
  const [newSnapshotTarget, setNewSnapshotTarget] = useState('صفحه اصلی (ID: 12)');
  const [newSnapshotType, setNewSnapshotType] = useState<BackupSnapshot['type']>('elementor_document');
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [diffViewMode, setDiffViewMode] = useState<'split' | 'unified'>('split');

  // Trigger snapshot rollback
  const handleRollback = (snapshot: BackupSnapshot) => {
    if (!confirm(`آیا از بازگردانی (Rollback) به نسخه "${snapshot.name}" اطمینان دارید؟ تغییرات اعمال شده بعد از تاریخ ${snapshot.date} جایگزین خواهند شد.`)) {
      return;
    }

    setRestoringId(snapshot.id);
    setTimeout(() => {
      setRestoringId(null);
      setActionNotice(`نسخه "${snapshot.name}" با موفقیت روی سرور بازگردانی شد. کش لایت‌اسپید به طور خودکار پاک‌سازی گردید.`);
      setTimeout(() => setActionNotice(null), 6000);
    }, 1500);
  };

  // Create new snapshot
  const handleCreateSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSnapshotName.trim()) return;

    const newSnap: BackupSnapshot = {
      id: `SNAP-${Date.now().toString().slice(-6)}`,
      name: newSnapshotName,
      type: newSnapshotType,
      target: newSnapshotTarget,
      date: 'هم اکنون',
      author: 'مدیر کل (newadmin)',
      sizeKb: 145,
      verified: true,
      canRollback: true
    };

    setSnapshots([newSnap, ...snapshots]);
    setSelectedSnapshot(newSnap);
    setIsCreating(false);
    setNewSnapshotName('');
    setActionNotice(`نقطه بازگشت جدید "${newSnap.name}" با شناسه ${newSnap.id} با موفقیت در پایگاه داده ذخیره شد.`);
    setTimeout(() => setActionNotice(null), 5000);
  };

  // Sample mock diff content between live and snapshot
  const diffContent = {
    live: `/* نسخه فعال جاری در وردپرس (Live Production) */
.goli-hero-container {
  background: linear-gradient(135deg, #0f382c 0%, #174d3d 100%);
  border-radius: 24px;
  padding: 48px 32px;
  box-shadow: 0 20px 40px rgba(15, 56, 44, 0.15);
}

.brand-badge-agrado {
  color: #d4af37;
  font-weight: 800;
  border: 1px solid rgba(212, 175, 55, 0.3);
}

.product-guarantee-text {
  content: "ضمانت قطعی اصالت کالا و نمایندگی رسمی";
  font-size: 14px;
}`,
    snapshot: `/* نسخه ذخیره شده در نقطه بازگشت (Snapshot: ${selectedSnapshot?.id}) */
.goli-hero-container {
  background: #0f382c;
  border-radius: 16px;
  padding: 40px 24px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.brand-badge-agrado {
  color: #e2c974;
  font-weight: 700;
  border: 1px solid rgba(226, 201, 116, 0.2);
}

.product-guarantee-text {
  content: "تضمین اصالت کالا";
  font-size: 13px;
}`
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-[#0f382c]/10 text-[#0f382c]">
              <Database className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800">مدیریت نقاط بازگشت و پشتیبان‌ها (Backup & Rollback)</h2>
          </div>
          <p className="text-sm text-slate-500">
            ثبت اسنپ‌شات پیش از هر تغییر هوش مصنوعی، مقایسه زنده تفاوت‌ها (Diff) و بازگردانی فوری با یک کلیک
          </p>
        </div>

        <button
          onClick={() => setIsCreating(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0f382c] text-white hover:bg-[#174d3d] text-sm font-semibold transition shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>ایجاد نقطه بازگشت دستی (Snapshot)</span>
        </button>
      </div>

      {actionNotice && (
        <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Create Modal */}
      {isCreating && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-scale-up">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800 flex items-center gap-2">
                <HardDrive className="w-5 h-5 text-[#0f382c]" />
                <span>ایجاد اسنپ‌شات نقطه بازگشت جدید</span>
              </h3>
              <button 
                onClick={() => setIsCreating(false)}
                className="text-slate-400 hover:text-slate-600 text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSnapshot} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">عنوان و توضیح نسخه پشتیبان</label>
                <input
                  type="text"
                  required
                  placeholder="مثلاً: قبل از به‌روزرسانی هدر المنتور و قیمت‌های آگرادو"
                  value={newSnapshotName}
                  onChange={(e) => setNewSnapshotName(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#0f382c]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">نوع پشتیبان</label>
                  <select
                    value={newSnapshotType}
                    onChange={(e) => setNewSnapshotType(e.target.value as BackupSnapshot['type'])}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-white"
                  >
                    <option value="elementor_document">سند المنتور (Elementor Data)</option>
                    <option value="custom_css">استایل‌های CSS سراسری</option>
                    <option value="woo_pricing">جدول قیمت‌های ووکامرس</option>
                    <option value="page_full">کامل برگه به همراه متاها</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">هدف (Target)</label>
                  <input
                    type="text"
                    value={newSnapshotTarget}
                    onChange={(e) => setNewSnapshotTarget(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-800 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  این نسخه پشتیبان در پایگاه داده سرور گلیکالا به صورت امن فشرده و امضا می‌شود تا در صورت نیاز به سرعت بدون هیچ قطعی بازگردانی شود.
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0f382c] text-white text-xs font-semibold hover:bg-[#174d3d]"
                >
                  ثبت اسنپ‌شات فوری
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main Snapshots List & Diff Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Snapshots List (1 col) */}
        <div className="space-y-3">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            نقاط بازگشت موجود ({snapshots.length})
          </div>

          <div className="space-y-2">
            {snapshots.map(snap => (
              <div
                key={snap.id}
                onClick={() => setSelectedSnapshot(snap)}
                className={`p-4 rounded-xl border cursor-pointer transition text-right ${
                  selectedSnapshot?.id === snap.id
                    ? 'bg-emerald-50/50 border-[#0f382c] ring-2 ring-[#0f382c]/10'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="font-mono text-xs font-bold text-slate-800">{snap.id}</span>
                  </div>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                    {snap.type === 'elementor_document' ? 'المنتور' : snap.type === 'custom_css' ? 'کد CSS' : 'داده ووکامرس'}
                  </span>
                </div>

                <p className="text-xs font-semibold text-slate-700 mb-2 line-clamp-2">
                  {snap.name}
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-100 pt-2">
                  <span>{snap.target}</span>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{snap.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Diff Inspector & Rollback Console (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          {selectedSnapshot ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
              {/* Snapshot header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold bg-[#0f382c] text-white px-2 py-0.5 rounded">
                      {selectedSnapshot.id}
                    </span>
                    <h3 className="font-bold text-slate-800 text-base">{selectedSnapshot.name}</h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    ایجاد شده توسط <strong className="text-slate-700">{selectedSnapshot.author}</strong> در {selectedSnapshot.date} • حجم: {selectedSnapshot.sizeKb} KB
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleRollback(selectedSnapshot)}
                    disabled={restoringId === selectedSnapshot.id}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-xs disabled:opacity-50"
                  >
                    <RotateCcw className={`w-3.5 h-3.5 ${restoringId === selectedSnapshot.id ? 'animate-spin' : ''}`} />
                    <span>{restoringId === selectedSnapshot.id ? 'در حال بازگردانی...' : 'بازگردانی به این نسخه (Rollback)'}</span>
                  </button>

                  <button
                    onClick={() => {
                      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(selectedSnapshot, null, 2));
                      const downloadAnchor = document.createElement('a');
                      downloadAnchor.setAttribute("href", dataStr);
                      downloadAnchor.setAttribute("download", `${selectedSnapshot.id}.json`);
                      downloadAnchor.click();
                    }}
                    className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
                    title="دانلود فایل پشتیبان JSON"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Diff View Mode Switcher */}
              <div className="flex items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                  <ArrowLeftRight className="w-4 h-4 text-[#0f382c]" />
                  <span>مقایسه تفاوت‌های ساختاری (Diff Viewer)</span>
                </div>

                <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200 text-xs">
                  <button
                    onClick={() => setDiffViewMode('split')}
                    className={`px-2.5 py-1 rounded font-medium transition ${
                      diffViewMode === 'split' ? 'bg-[#0f382c] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    نمای دو ستونه (Split)
                  </button>
                  <button
                    onClick={() => setDiffViewMode('unified')}
                    className={`px-2.5 py-1 rounded font-medium transition ${
                      diffViewMode === 'unified' ? 'bg-[#0f382c] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    نمای یکپارچه (Unified)
                  </button>
                </div>
              </div>

              {/* Code Diff Display */}
              {diffViewMode === 'split' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs text-left" dir="ltr">
                  {/* Current Live */}
                  <div className="bg-slate-900 text-slate-200 rounded-xl p-4 overflow-x-auto border border-slate-800">
                    <div className="flex items-center justify-between text-[11px] text-emerald-400 font-sans mb-2 pb-2 border-b border-slate-800">
                      <span className="font-bold">● نسخه زنده سرور (Live Active)</span>
                      <span className="text-slate-500">کنونی</span>
                    </div>
                    <pre className="text-emerald-300/90 whitespace-pre leading-relaxed">{diffContent.live}</pre>
                  </div>

                  {/* Selected Snapshot */}
                  <div className="bg-slate-900 text-slate-200 rounded-xl p-4 overflow-x-auto border border-slate-800">
                    <div className="flex items-center justify-between text-[11px] text-amber-400 font-sans mb-2 pb-2 border-b border-slate-800">
                      <span className="font-bold">○ نقطه بازگشت ({selectedSnapshot.id})</span>
                      <span className="text-slate-500">{selectedSnapshot.date}</span>
                    </div>
                    <pre className="text-amber-300/90 whitespace-pre leading-relaxed">{diffContent.snapshot}</pre>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-900 text-slate-200 rounded-xl p-4 overflow-x-auto border border-slate-800 font-mono text-xs text-left" dir="ltr">
                  <div className="text-[11px] text-slate-400 font-sans mb-2 pb-2 border-b border-slate-800">
                    --- {selectedSnapshot.id} ({selectedSnapshot.date})<br />
                    +++ live_production.css (Current)
                  </div>
                  <pre className="whitespace-pre leading-relaxed">
                    <span className="text-rose-400">- .goli-hero-container &#123; background: #0f382c; border-radius: 16px; &#125;</span><br />
                    <span className="text-emerald-400">+ .goli-hero-container &#123; background: linear-gradient(135deg, #0f382c 0%, #174d3d 100%); border-radius: 24px; &#125;</span><br />
                    <span className="text-slate-500">  .brand-badge-agrado &#123;</span><br />
                    <span className="text-rose-400">-   color: #e2c974; border: 1px solid rgba(226, 201, 116, 0.2);</span><br />
                    <span className="text-emerald-400">+   color: #d4af37; border: 1px solid rgba(212, 175, 55, 0.3);</span><br />
                    <span className="text-slate-500">  &#125;</span>
                  </pre>
                </div>
              )}

              {/* Safety Checklist */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>بررسی استانداردهای ایمنی بازگردانی (Rollback Safety Policy)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5 bg-white p-2 rounded-lg border border-slate-100">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>تایید امضای دیجیتال اسنپ‌شات</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white p-2 rounded-lg border border-slate-100">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>عدم مغایرت با دیتابیس سفارشات</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white p-2 rounded-lg border border-slate-100">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>پاک‌سازی هوشمند کش لایت‌اسپید</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400">
              <Database className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-xs font-medium">یک نسخه پشتیبان را از لیست سمت راست انتخاب کنید.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
