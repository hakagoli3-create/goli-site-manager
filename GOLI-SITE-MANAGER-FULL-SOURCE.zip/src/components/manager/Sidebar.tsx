import React from 'react';
import { 
  LayoutDashboard, 
  Sparkles, 
  Palette, 
  FileText, 
  Layers, 
  ShoppingBag, 
  TrendingUp, 
  Image as ImageIcon, 
  Zap, 
  History, 
  Settings, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

export type ManagerTab = 
  | 'overview'
  | 'agent'
  | 'studio'
  | 'pages'
  | 'elementor'
  | 'commerce'
  | 'seo'
  | 'media'
  | 'health'
  | 'backup'
  | 'settings';

interface SidebarProps {
  currentTab: ManagerTab;
  onSelectTab: (tab: ManagerTab) => void;
  ordersCount?: number;
  aiPendingCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  ordersCount = 3,
  aiPendingCount = 0,
}) => {
  const menuItems: { id: ManagerTab; label: string; icon: any; badge?: string; badgeColor?: string }[] = [
    { id: 'overview', label: 'داشبورد مرکزی', icon: LayoutDashboard },
    { id: 'agent', label: 'دستیار هوش مصنوعی', icon: Sparkles, badge: 'فعال', badgeColor: 'bg-[#d4af37] text-[#0f382c]' },
    { id: 'studio', label: 'استودیوی دیزاین', icon: Palette, badge: 'ویژه', badgeColor: 'bg-emerald-500 text-white' },
    { id: 'pages', label: 'برگه‌ها و صفحات', icon: FileText },
    { id: 'elementor', label: 'مدیریت المنتور', icon: Layers },
    { id: 'commerce', label: 'فروشگاه و سفارشات', icon: ShoppingBag, badge: ordersCount > 0 ? `${ordersCount} جدید` : undefined, badgeColor: 'bg-rose-500 text-white' },
    { id: 'seo', label: 'هوش سئو و رنک‌مث', icon: TrendingUp, badge: '۹۸٪', badgeColor: 'bg-emerald-600 text-white' },
    { id: 'media', label: 'مدیریت رسانه و بنرها', icon: ImageIcon },
    { id: 'health', label: 'سرعت و سلامت سایت', icon: Zap },
    { id: 'backup', label: 'پشتیبان‌ها و بازگشت', icon: History },
    { id: 'settings', label: 'تنظیمات و Bridge', icon: Settings },
  ];

  return (
    <aside className="w-full lg:w-64 bg-[#0a2920] border-l border-[#1b4e3e] flex flex-col shrink-0 text-right">
      
      {/* Brand & Identity Card */}
      <div className="p-4 border-b border-[#1b4e3e] bg-[#07211a]">
        <div className="flex items-center gap-2 text-xs font-bold text-[#d4af37] mb-1">
          <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
          <span>پلتفرم مدیریتی بازرگانی گلی</span>
        </div>
        <div className="text-xs text-[#c4d6ce] leading-relaxed">
          مدیریت یکپارچه وبسایت <strong>golikala.com</strong> و نمایندگی رسمی برندهای آمالفی، آگرادو و سایرو
        </div>
      </div>

      {/* Nav Items */}
      <nav className="p-3 space-y-1 overflow-y-auto flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-l from-[#164e3f] to-[#0f382c] text-white border border-[#d4af37]/50 shadow-md shadow-black/20'
                  : 'text-[#c4d6ce] hover:text-white hover:bg-[#123e32]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#d4af37]' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${item.badgeColor || 'bg-slate-700 text-white'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* External Link to WordPress admin */}
      <div className="p-3 border-t border-[#1b4e3e] bg-[#07211a]">
        <a
          href="https://golikala.com/wp-admin/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between p-2.5 rounded-xl bg-[#0f382c] hover:bg-[#164e3f] border border-[#1b4e3e] text-[11px] font-bold text-[#c4d6ce] hover:text-white transition-colors"
        >
          <span>ورود مستقیم به wp-admin</span>
          <ExternalLink className="w-3.5 h-3.5 text-[#d4af37]" />
        </a>
      </div>

    </aside>
  );
};
