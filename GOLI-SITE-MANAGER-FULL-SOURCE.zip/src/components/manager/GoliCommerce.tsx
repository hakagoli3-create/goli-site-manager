import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  SlidersHorizontal, 
  Edit3, 
  Check, 
  X, 
  Package, 
  Truck, 
  DollarSign, 
  ShieldCheck, 
  TrendingUp, 
  Users,
  CheckCircle2
} from 'lucide-react';
import { WooProduct, WooOrder } from '../../types/manager';

interface GoliCommerceProps {
  products: WooProduct[];
  orders: WooOrder[];
  onUpdateProductStock: (productId: number, newStock: number, newPrice: number) => void;
  onUpdateOrderStatus: (orderId: number, newStatus: WooOrder['status'], postCode?: string) => void;
}

export const GoliCommerce: React.FC<GoliCommerceProps> = ({
  products,
  orders,
  onUpdateProductStock,
  onUpdateOrderStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'wholesale'>('products');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  
  // Edit Product Modal / State
  const [editingProduct, setEditingProduct] = useState<WooProduct | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);
  const [editNotice, setEditNotice] = useState(false);

  // Edit Order State
  const [editingOrder, setEditingOrder] = useState<WooOrder | null>(null);
  const [editOrderStatus, setEditOrderStatus] = useState<WooOrder['status']>('در حال پردازش');
  const [editPostCode, setEditPostCode] = useState<string>('');

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.includes(searchQuery) || p.sku.includes(searchQuery);
    const matchesBrand = selectedBrand === 'all' || p.brand === selectedBrand;
    return matchesSearch && matchesBrand;
  });

  const handleStartEdit = (p: WooProduct) => {
    setEditingProduct(p);
    setEditPrice(p.price);
    setEditStock(p.stockQuantity);
  };

  const handleSaveProductEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    onUpdateProductStock(editingProduct.id, editStock, editPrice);
    setEditingProduct(null);
    setEditNotice(true);
    setTimeout(() => setEditNotice(false), 2500);
  };

  const handleSaveOrderEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;
    onUpdateOrderStatus(editingOrder.id, editOrderStatus, editPostCode || editingOrder.postTrackingCode);
    setEditingOrder(null);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Commerce Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
            <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
            <span>Goli Commerce — مدیریت ووکامرس و سفارشات گلیکالا</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black">
            مدیریت محصولات، موجودی انبار، قیمت‌گذاری و سفارشات
          </h1>
          <p className="text-xs text-[#c4d6ce]">
            همگام با درگاه پرداخت زرین‌پال، کانال فروش عمده همکاران و سیستم رهگیری تیپاکس.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-[#08241c] p-1 rounded-2xl border border-[#1b4e3e] text-xs font-bold">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'products' ? 'bg-[#d4af37] text-[#0f382c] font-black' : 'text-[#c4d6ce]'
            }`}
          >
            محصولات ({products.length})
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'orders' ? 'bg-[#d4af37] text-[#0f382c] font-black' : 'text-[#c4d6ce]'
            }`}
          >
            سفارشات ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab('wholesale')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'wholesale' ? 'bg-[#d4af37] text-[#0f382c] font-black' : 'text-[#c4d6ce]'
            }`}
          >
            کانال فروش عمده (B2B)
          </button>
        </div>
      </div>

      {editNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>قیمت و موجودی کالا با موفقیت در ووکامرس به‌روزرسانی شد و کش لایت‌اسپید این محصول پاکسازی گردید.</span>
        </div>
      )}

      {/* TAB 1: PRODUCTS MANAGER */}
      {activeTab === 'products' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          
          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="relative w-full sm:w-80">
              <input
                type="text"
                placeholder="جستجو در نام محصول، کد SKU یا برند..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-10 py-2.5 bg-[#fcfbf7] border border-slate-200 rounded-xl outline-hidden focus:border-[#0f382c]"
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
              <span className="text-slate-400 font-bold shrink-0">فیلتر برند :</span>
              {['all', 'آگرادو', 'آمالفی', 'سایرو'].map(b => (
                <button
                  key={b}
                  onClick={() => setSelectedBrand(b)}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 cursor-pointer ${
                    selectedBrand === b ? 'bg-[#0f382c] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {b === 'all' ? 'همه برندها' : b}
                </button>
              ))}
            </div>
          </div>

          {/* Products Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-2xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#fcfbf7] border-b border-slate-200 text-slate-700 font-bold">
                <tr>
                  <th className="py-3 px-4">کالا و کد SKU</th>
                  <th className="py-3 px-4">برند و کشور</th>
                  <th className="py-3 px-4">قیمت فروش</th>
                  <th className="py-3 px-4">موجودی انبار</th>
                  <th className="py-3 px-4">سئو رنک‌مث</th>
                  <th className="py-3 px-4 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img src={p.image} alt="" className="w-10 h-10 object-cover rounded-lg border border-slate-200 shrink-0" />
                        <div>
                          <div className="font-bold text-slate-900 line-clamp-1">{p.name}</div>
                          <span className="text-[10px] font-mono text-slate-400 font-bold">SKU: {p.sku}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-bold text-[#0f382c] bg-[#0f382c]/10 px-2 py-0.5 rounded-md text-[11px]">
                        {p.brand} ({p.brandEn})
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-black text-slate-900">{formatPrice(p.price)}</div>
                      {p.regularPrice > p.price && (
                        <span className="text-[10px] text-slate-400 line-through block">
                          {formatPrice(p.regularPrice)}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${p.stockQuantity > 20 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                        <span className="font-mono font-bold text-slate-800">{p.stockQuantity} عدد</span>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md text-[11px]">
                        {p.rankMathScore} / ۱۰۰
                      </span>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleStartEdit(p)}
                        className="px-3 py-1.5 bg-[#fcfbf7] hover:bg-[#0f382c] text-slate-700 hover:text-white border border-slate-200 hover:border-[#0f382c] rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 mx-auto"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>ویرایش سریع</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* TAB 2: ORDERS MANAGER */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-black text-slate-900">لیست سفارشات زنده ووکامرس :</h3>
            <span className="text-xs text-slate-400">اتصال لحظه‌ای به درگاه زرین‌پال و شاپرک</span>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-2xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#fcfbf7] border-b border-slate-200 text-slate-700 font-bold">
                <tr>
                  <th className="py-3 px-4">شماره سفارش</th>
                  <th className="py-3 px-4">خریدار و شهر</th>
                  <th className="py-3 px-4">مبلغ کل</th>
                  <th className="py-3 px-4">درگاه پرداخت</th>
                  <th className="py-3 px-4">وضعیت مرسوله</th>
                  <th className="py-3 px-4">کد رهگیری تیپاکس</th>
                  <th className="py-3 px-4 text-center">تغییر وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((o) => (
                  <tr key={o.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#0f382c]">{o.orderNumber}</td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{o.customerName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{o.customerPhone} ({o.shippingCity})</div>
                    </td>
                    <td className="py-3 px-4 font-black text-slate-900">{formatPrice(o.total)}</td>
                    <td className="py-3 px-4 font-medium text-slate-600">{o.paymentGateway}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        o.status === 'ارسال شده با تیپاکس' || o.status === 'تکمیل شده'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {o.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] font-bold text-slate-700">
                      {o.postTrackingCode || 'در انتظار صدور'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => {
                          setEditingOrder(o);
                          setEditOrderStatus(o.status);
                          setEditPostCode(o.postTrackingCode || '');
                        }}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-[11px] font-bold"
                      >
                        به‌روزرسانی
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: WHOLESALE B2B CHANNEL (PART 1.2) */}
      {activeTab === 'wholesale' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-black text-slate-900">
                پیکربندی کانال فروش عمده همکاران بازرگانی گلی (B2B Wholesale Portal)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                تخصیص قیمت‌های عمده انحصاری برای داروخانه‌ها، سالن‌های زیبایی و فروشگاه‌های سراسر کشور.
              </p>
            </div>
            <span className="text-xs bg-[#d4af37]/20 text-[#0f382c] border border-[#d4af37]/40 px-3 py-1 rounded-full font-black">
              کانال عمده فعال است
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-400 block font-bold">حداقل تیراژ سفارش عمده :</span>
              <strong className="text-base font-black text-slate-900 font-mono">۱۲ عدد (۱ کارتن)</strong>
              <p className="text-[11px] text-slate-500">تخفیف پله‌ای برای خریدهای بالای ۵ کارتن</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-400 block font-bold">تسهیلات حمل و نقل :</span>
              <strong className="text-base font-black text-slate-900">باربری رایگان به باربری مقصد</strong>
              <p className="text-[11px] text-slate-500">بسته‌بندی استاندارد صادراتی کارخانه‌ای</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-400 block font-bold">تضمین اصالت عمده :</span>
              <strong className="text-base font-black text-emerald-700">ارائه فاکتور رسمی بازرگانی</strong>
              <p className="text-[11px] text-slate-500">دارای تاییدیه آزمایشگاهی و بچ‌کد فعال</p>
            </div>
          </div>
        </div>
      )}

      {/* Quick Edit Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 text-right shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h4 className="text-sm font-black text-slate-900">ویرایش قیمت و موجودی ووکامرس</h4>
              <button onClick={() => setEditingProduct(null)} className="p-1 hover:bg-slate-100 rounded-lg">
                <X className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            <p className="text-xs text-slate-600 font-bold truncate">{editingProduct.name}</p>

            <form onSubmit={handleSaveProductEdit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">قیمت فروش عادی (تومان) :</label>
                <input
                  type="number"
                  value={editPrice}
                  onChange={(e) => setEditPrice(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-[#0f382c] font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">موجودی انبار مرکزی (تعداد) :</label>
                <input
                  type="number"
                  value={editStock}
                  onChange={(e) => setEditStock(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-[#0f382c] font-mono font-bold"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#0f382c] hover:bg-[#164e3f] text-white font-bold rounded-xl transition-colors cursor-pointer"
                >
                  ذخیره در ووکامرس
                </button>
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2.5 border border-slate-200 text-slate-600 font-bold rounded-xl"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Order Status Edit Modal */}
      {editingOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 text-right shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h4 className="text-sm font-black text-slate-900">به‌روزرسانی سفارش {editingOrder.orderNumber}</h4>
              <button onClick={() => setEditingOrder(null)} className="p-1 hover:bg-slate-100 rounded-lg">
                <X className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            <form onSubmit={handleSaveOrderEdit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">وضعیت سفارش در ووکامرس :</label>
                <select
                  value={editOrderStatus}
                  onChange={(e) => setEditOrderStatus(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                >
                  <option value="در حال پردازش">در حال پردازش (Processing)</option>
                  <option value="ارسال شده با تیپاکس">ارسال شده با تیپاکس (Shipped)</option>
                  <option value="تکمیل شده">تکمیل شده (Completed)</option>
                  <option value="در انتظار پرداخت">در انتظار پرداخت (On-hold)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">کد رهگیری پستی / تیپاکس :</label>
                <input
                  type="text"
                  value={editPostCode}
                  onChange={(e) => setEditPostCode(e.target.value)}
                  placeholder="مثلا : 319482710599281720"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#0f382c] hover:bg-[#164e3f] text-white font-bold rounded-xl"
                >
                  ثبت و ارسال پیامک وضعیت
                </button>
                <button
                  type="button"
                  onClick={() => setEditingOrder(null)}
                  className="px-4 py-2.5 border border-slate-200 text-slate-600 rounded-xl"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
