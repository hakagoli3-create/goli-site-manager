import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Layers, 
  FileText, 
  ShoppingBag, 
  TrendingUp, 
  Zap, 
  History, 
  Server, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeft, 
  RotateCcw, 
  Database, 
  Lock, 
  Cpu, 
  Activity,
  Check
} from 'lucide-react';
import { SiteConnection, AiAgentTask, ActivityLog } from '../../types/manager';
import { ManagerTab } from './Sidebar';

interface DashboardOverviewProps {
  connection: SiteConnection;
  onNavigateTab: (tab: ManagerTab) => void;
  aiTasks: AiAgentTask[];
  activityLogs: ActivityLog[];
  onTriggerQuickBackup: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  connection,
  onNavigateTab,
  aiTasks,
  activityLogs,
  onTriggerQuickBackup,
}) => {
  const [cacheCleared, setCacheCleared] = useState(false);
  const [backupNotice, setBackupNotice] = useState(false);

  const handleClearLiteSpeedCache = () => {
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 2500);
  };

  const handleBackup = () => {
    onTriggerQuickBackup();
    setBackupNotice(true);
    setTimeout(() => setBackupNotice(false), 2500);
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Top Banner: Official Representation & Live Status */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
              <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
              <span>سیستم مدیریت مرکزی وبسایت golikala.com</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white">
              داشبورد مانیتورینگ و مدیریت هوشمند گلی کالا
            </h1>

            <p className="text-xs sm:text-sm text-[#c4d6ce] max-w-2xl leading-relaxed">
              اتصال زنده به وردپرس، ووکامرس، المنتور پرو، رنک‌مث و وب‌سرور لایت‌اسپید با پشتیبانی کامل از نمایندگی رسمی برندهای آمالفی، آگرادو و سایرو.
            </p>
          </div>

          {/* Quick Action CTAs */}
          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={() => onNavigateTab('agent')}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] rounded-xl text-xs font-black shadow-lg shadow-black/20 hover:scale-102 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>ارسال دستور به Goli AI</span>
            </button>

            <button
              onClick={() => onNavigateTab('studio')}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#08241c] hover:bg-[#164e3f] text-white border border-[#1b4e3e] rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              <Layers className="w-4 h-4 text-[#d4af37]" />
              <span>ورود به استودیوی دیزاین</span>
            </button>
          </div>

        </div>

        {/* Ambient background glow */}
        <div className="absolute top-0 right-1/4 w-80 h-80 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {backupNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>پشتیبان جدید از ساختار المنتور و استایل‌های وبسایت با موفقیت در مخزن امن ذخیره گردید.</span>
        </div>
      )}

      {cacheCleared && (
        <div className="p-4 bg-amber-500/20 border border-amber-500/40 rounded-2xl text-xs font-bold text-amber-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-amber-400" />
          <span>کش لایت‌اسپید (LiteSpeed Cache) و دیتای موقت CSS/JS با موفقیت پاکسازی شد.</span>
        </div>
      )}

      {/* 5 Core Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        
        <div 
          onClick={() => onNavigateTab('pages')}
          className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-[#0f382c] transition-all shadow-xs cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold text-slate-600">برگه‌های فعال</span>
            <FileText className="w-4 h-4 text-[#0f382c]" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 font-mono">۲۴</div>
          <div className="text-[10px] text-emerald-700 font-bold mt-1">همگی با المنتور طراحی شده</div>
        </div>

        <div 
          onClick={() => onNavigateTab('commerce')}
          className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-[#0f382c] transition-all shadow-xs cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold text-slate-600">محصولات ووکامرس</span>
            <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 font-mono">۱۴۲</div>
          <div className="text-[10px] text-emerald-700 font-bold mt-1">۸۸ قلم برندهای آگرادو و آمالفی</div>
        </div>

        <div 
          onClick={() => onNavigateTab('commerce')}
          className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-[#0f382c] transition-all shadow-xs cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold text-slate-600">سفارشات موفق</span>
            <Activity className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 font-mono">۱,۲۸۰</div>
          <div className="text-[10px] text-rose-600 font-bold mt-1">۳ سفارش در حال پردازش</div>
        </div>

        <div 
          onClick={() => onNavigateTab('seo')}
          className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-[#0f382c] transition-all shadow-xs cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold text-slate-600">میانگین سئو رنک‌مث</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">۹۸ / ۱۰۰</div>
          <div className="text-[10px] text-emerald-700 font-bold mt-1">اسکیماهای رسمی تایید شده</div>
        </div>

        <div 
          onClick={() => onNavigateTab('health')}
          className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-[#0f382c] transition-all shadow-xs cursor-pointer col-span-2 sm:col-span-1"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold text-slate-600">شاخص سلامت سایت</span>
            <Zap className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">۹۴٪ (عالی)</div>
          <div className="text-[10px] text-slate-500 font-medium mt-1">TTFB زیر ۲۵۰ میلی‌ثانیه</div>
        </div>

      </div>

      {/* Diagnostics Grid: Technical Environment inspection */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Environment Specification Card (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-[#0f382c]" />
              <h3 className="text-sm font-black text-slate-900">
                مشخصات فنی محیط متصل به golikala.com
              </h3>
            </div>
            <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              تایید دسترسی manage_options
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <span className="text-slate-400 block mb-0.5 text-[11px]">نسخه وردپرس :</span>
              <strong className="text-slate-900 font-mono">{connection.wpVersion} (فارسی / RTL)</strong>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <span className="text-slate-400 block mb-0.5 text-[11px]">نسخه المنتور :</span>
              <strong className="text-slate-900 font-mono">{connection.elementorVersion}</strong>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <span className="text-slate-400 block mb-0.5 text-[11px]">نسخه ووکامرس :</span>
              <strong className="text-slate-900 font-mono">{connection.wcVersion}</strong>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <span className="text-slate-400 block mb-0.5 text-[11px]">افزونه سئو :</span>
              <strong className="text-slate-900 font-mono">{connection.rankMathVersion}</strong>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <span className="text-slate-400 block mb-0.5 text-[11px]">پوسته فعال (Theme) :</span>
              <strong className="text-slate-900">{connection.activeTheme}</strong>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
              <span className="text-slate-400 block mb-0.5 text-[11px]">وب‌سرور و کش :</span>
              <strong className="text-slate-900 font-mono">{connection.serverType}</strong>
            </div>
          </div>

          {/* Quick Management Tools */}
          <div className="pt-2 flex flex-wrap gap-2">
            <button
              onClick={handleBackup}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Database className="w-3.5 h-3.5 text-[#0f382c]" />
              <span>پشتیبان‌گیری اضطراری از المنتور</span>
            </button>

            <button
              onClick={handleClearLiteSpeedCache}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>پاکسازی کش لایت‌اسپید</span>
            </button>

            <button
              onClick={() => onNavigateTab('settings')}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              <span>کد افزونه Companion Bridge</span>
            </button>
          </div>
        </div>

        {/* AI Agent Status & Recent Plan (5 cols) */}
        <div className="lg:col-span-5 bg-gradient-to-b from-[#0f382c] to-[#07211a] text-white rounded-3xl p-6 space-y-4 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#1b4e3e]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#d4af37]" />
                <h3 className="text-sm font-black text-white">
                  وضعیت Goli AI Agent
                </h3>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                مدل Gemini 2.5 Flash
              </span>
            </div>

            <div className="mt-4 space-y-3">
              <div className="p-3.5 rounded-2xl bg-[#08241c] border border-[#1b4e3e] text-xs space-y-1">
                <span className="text-[#d4af37] font-bold block">آخرین تسک اجرا شده :</span>
                <p className="text-slate-200 leading-relaxed font-normal">
                  {aiTasks[0]?.prompt || 'بازطراحی هیرو بنر صفحه اصلی با پالت رسمی سبز جنگلی و طلایی گلیکالا'}
                </p>
                <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400">
                  <span>وضعیت : <strong className="text-emerald-400">تایید و اعمال شده</strong></span>
                  <span>ریسک : <strong>پایین</strong></span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-[#08241c]/60 border border-[#1b4e3e] text-xs text-[#c4d6ce] leading-relaxed">
                موتور هوش مصنوعی به پایگاه داده المنتور و متادیتای رنک‌مث متصل است و تمامی تغییرات با ایجاد نقطه بازگشت (Rollback) اعمال می‌گردند.
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('agent')}
            className="w-full py-2.5 bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-2 cursor-pointer hover:scale-101 transition-all"
          >
            <span>ارسال فرمان جدید به دستیار هوش مصنوعی</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Activity Logs & Audit Trail */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-slate-700" />
            <h3 className="text-sm font-black text-slate-900">
              لاگ مانیتورینگ و تاریخچه تغییرات سایت (Audit Trail)
            </h3>
          </div>
          <span className="text-xs text-slate-400">ثبت بدون تاخیر رویدادهای سرور</span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {activityLogs.map((log) => (
            <div key={log.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">{log.action}</span>
                  <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                    ماژول : {log.module}
                  </span>
                </div>
                <p className="text-slate-500 font-normal">{log.details}</p>
              </div>

              <div className="flex items-center gap-3 text-[11px] text-slate-400 shrink-0">
                <span>{log.user}</span>
                <span>•</span>
                <span>{log.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
