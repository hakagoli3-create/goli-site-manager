import React, { useState } from 'react';
import { 
  Image as ImageIcon, 
  Search, 
  Filter, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Upload, 
  HardDrive, 
  RefreshCw, 
  FileText, 
  ExternalLink,
  SlidersHorizontal,
  Zap,
  Info
} from 'lucide-react';
import { MediaItem } from '../../types/manager';
import { MEDIA_ITEMS } from '../../data/managerMockData';

export function MediaManager() {
  const [mediaList, setMediaList] = useState<MediaItem[]>(MEDIA_ITEMS);
  const [filterType, setFilterType] = useState<'all' | 'missing-alt' | 'heavy' | 'webp'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Filter logic
  const filtered = mediaList.filter(item => {
    const matchesSearch = item.title.includes(searchQuery) || item.fileName.includes(searchQuery) || item.altText.includes(searchQuery);
    if (!matchesSearch) return false;

    if (filterType === 'missing-alt') return !item.hasAlt;
    if (filterType === 'heavy') return item.isOversized;
    if (filterType === 'webp') return item.format === 'webp';
    return true;
  });

  const missingAltCount = mediaList.filter(i => !i.hasAlt).length;
  const oversizedCount = mediaList.filter(i => i.isOversized).length;
  const webpCount = mediaList.filter(i => i.format === 'webp').length;
  const totalSizeKb = mediaList.reduce((acc, curr) => acc + curr.fileSizeKb, 0);

  // 1-Click AI fix all missing ALT texts
  const handleAiFixAllAlt = () => {
    setIsAiGenerating(true);
    setTimeout(() => {
      setMediaList(prev => prev.map(item => {
        if (!item.hasAlt) {
          const generatedAlt = `${item.title} - کالای اورجینال نمایندگی رسمی گلیکالا`;
          return {
            ...item,
            hasAlt: true,
            altText: generatedAlt
          };
        }
        return item;
      }));
      setIsAiGenerating(false);
      setActionNotice('متن جایگزین (ALT) سئو برای تمام تصاویر بدون متن بر اساس کلمات کلیدی هوشمند تولید و ذخیره شد.');
      setTimeout(() => setActionNotice(null), 5000);
    }, 1200);
  };

  const handleUpdateSingleAlt = (id: number, newAlt: string) => {
    setMediaList(prev => prev.map(item => item.id === id ? { ...item, altText: newAlt, hasAlt: newAlt.trim().length > 0 } : item));
    if (selectedItem?.id === id) {
      setSelectedItem(prev => prev ? { ...prev, altText: newAlt, hasAlt: newAlt.trim().length > 0 } : null);
    }
  };

  const handleConvertToWebp = (id: number) => {
    setMediaList(prev => prev.map(item => {
      if (item.id === id) {
        const newSize = Math.round(item.fileSizeKb * 0.45);
        return {
          ...item,
          format: 'webp',
          fileName: item.fileName.replace(/\.(png|jpg|jpeg)$/, '.webp'),
          fileSizeKb: newSize,
          isOversized: false
        };
      }
      return item;
    }));
    setActionNotice('تصویر با موفقیت به فرمت فشرده استاندارد WebP تبدیل گردید و حجم آن ۵۵٪ کاهش یافت.');
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header & Overview */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-[#0f382c]/10 text-[#0f382c]">
              <ImageIcon className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800">کتابخانه و مدیریت رسانه‌های وردپرس (Goli Media)</h2>
          </div>
          <p className="text-sm text-slate-500">
            بررسی، بهینه‌سازی فرمت WebP، رصد تصاویر بدون ALT سئو و همگام‌سازی با کتابخانه وردپرس
          </p>
        </div>

        <div className="flex items-center gap-3">
          {missingAltCount > 0 && (
            <button
              onClick={handleAiFixAllAlt}
              disabled={isAiGenerating}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#0f382c] to-[#3d5a45] text-white text-sm font-semibold hover:opacity-95 transition shadow-sm"
            >
              <Sparkles className={`w-4 h-4 text-[#d4af37] ${isAiGenerating ? 'animate-spin' : ''}`} />
              <span>{isAiGenerating ? 'در حال تولید هوشمند متون ALT...' : `تولید خودکار هوشمند ALT برای ${missingAltCount} تصویر`}</span>
            </button>
          )}

          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-medium transition">
            <Upload className="w-4 h-4" />
            <span>بارگذاری تصویر جدید</span>
          </button>
        </div>
      </div>

      {actionNotice && (
        <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">کل تصاویر کاتالوگ</span>
            <ImageIcon className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-800">{mediaList.length} فایل</div>
          <div className="text-xs text-slate-500 mt-1">متصل به پایگاه داده وردپرس</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">تصاویر بدون متن جایگزین (ALT)</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-600">{missingAltCount} مورد</div>
          <div className="text-xs text-amber-700/80 mt-1">نیاز به تکمیل جهت نمره رنک‌مث</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">ضریب فرمت فشرده WebP</span>
            <Zap className="w-4 h-4 text-[#d4af37]" />
          </div>
          <div className="text-2xl font-bold text-[#0f382c]">{Math.round((webpCount / mediaList.length) * 100)}%</div>
          <div className="text-xs text-emerald-600 mt-1">{webpCount} از {mediaList.length} مدرن و سبک</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">مجموع حجم اشغالی سرور</span>
            <HardDrive className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-slate-800">{totalSizeKb} کیلوبایت</div>
          <div className="text-xs text-slate-500 mt-1">میانگین {Math.round(totalSizeKb / mediaList.length)}KB هر فایل</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'all' ? 'bg-[#0f382c] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            همه رسانه‌ها ({mediaList.length})
          </button>
          <button
            onClick={() => setFilterType('missing-alt')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'missing-alt' ? 'bg-amber-500 text-white' : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>فاقد ALT ({missingAltCount})</span>
          </button>
          <button
            onClick={() => setFilterType('heavy')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'heavy' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            تصاویر سنگین {'>'} ۱۵۰KB ({oversizedCount})
          </button>
          <button
            onClick={() => setFilterType('webp')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterType === 'webp' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
            }`}
          >
            فقط WebP ({webpCount})
          </button>
        </div>

        <div className="relative w-full md:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو بر اساس نام، فایل یا ALT..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:outline-hidden focus:border-[#0f382c]"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-2" />
        </div>
      </div>

      {/* Media Grid & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Media Grid (2 cols) */}
        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4">
          {filtered.map(item => (
            <div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className={`group relative bg-white rounded-xl border p-2 cursor-pointer transition hover:shadow-md ${
                selectedItem?.id === item.id 
                  ? 'border-[#0f382c] ring-2 ring-[#0f382c]/20' 
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="relative aspect-square rounded-lg overflow-hidden bg-slate-100 mb-2">
                <img
                  src={item.url}
                  alt={item.altText || item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute top-1.5 right-1.5 flex gap-1">
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shadow-xs ${
                    item.format === 'webp' ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-white'
                  }`}>
                    {item.format.toUpperCase()}
                  </span>
                  {!item.hasAlt && (
                    <span className="bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow-xs" title="فاقد متن ALT">
                      بدون ALT
                    </span>
                  )}
                </div>
                {item.isOversized && (
                  <div className="absolute bottom-1.5 right-1.5 bg-rose-600/90 text-white text-[10px] px-1.5 py-0.5 rounded font-mono">
                    {item.fileSizeKb} KB
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <p className="text-xs font-semibold text-slate-800 line-clamp-1" title={item.title}>
                  {item.title}
                </p>
                <p className="text-[11px] text-slate-400 font-mono truncate">
                  {item.fileName}
                </p>
                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                  <span>{item.width}×{item.height}</span>
                  <span className="font-mono">{item.fileSizeKb} KB</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Media Details Inspector */}
        <div className="lg:col-span-1">
          {selectedItem ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs sticky top-24 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="font-bold text-sm text-slate-800">مشخصات تصویر در وردپرس</h3>
                <span className="text-xs font-mono text-slate-400">ID: {selectedItem.id}</span>
              </div>

              <div className="aspect-video rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
                <img
                  src={selectedItem.url}
                  alt={selectedItem.altText || selectedItem.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-500 block mb-1">نام فایل سرور</label>
                  <p className="text-xs font-mono bg-slate-50 p-2 rounded-lg text-slate-700 break-all select-all">
                    {selectedItem.fileName}
                  </p>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-500 block mb-1">عنوان (Title)</label>
                  <input
                    type="text"
                    value={selectedItem.title}
                    onChange={(e) => {
                      const updated = { ...selectedItem, title: e.target.value };
                      setSelectedItem(updated);
                      setMediaList(prev => prev.map(m => m.id === selectedItem.id ? updated : m));
                    }}
                    className="w-full text-xs p-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-[#0f382c]"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-500">متن جایگزین (Alt Text) برای سئو</label>
                    <button
                      onClick={() => {
                        const newAlt = `${selectedItem.title} نمایندگی رسمی گلیکالا`;
                        handleUpdateSingleAlt(selectedItem.id, newAlt);
                      }}
                      className="text-[11px] text-[#0f382c] font-semibold hover:underline flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-[#d4af37]" />
                      <span>پیشنهاد هوش مصنوعی</span>
                    </button>
                  </div>
                  <textarea
                    rows={3}
                    value={selectedItem.altText}
                    onChange={(e) => handleUpdateSingleAlt(selectedItem.id, e.target.value)}
                    placeholder="توضیح کوتاه تصویر برای گوگل و رنک‌مث..."
                    className={`w-full text-xs p-2 rounded-lg border focus:outline-hidden ${
                      selectedItem.hasAlt ? 'border-slate-200 focus:border-[#0f382c]' : 'border-amber-300 bg-amber-50/40 focus:border-amber-500'
                    }`}
                  />
                  {!selectedItem.hasAlt && (
                    <p className="text-[11px] text-amber-600 mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 shrink-0" />
                      <span>فاقد ALT است؛ اضافه کردن آن نمره سئوی صفحه محصول را بالا می‌برد.</span>
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg text-slate-600">
                  <div>
                    <span className="text-slate-400 block text-[10px]">ابعاد پیکسل</span>
                    <span className="font-semibold">{selectedItem.width} × {selectedItem.height}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">حجم فایل</span>
                    <span className="font-semibold">{selectedItem.fileSizeKb} KB</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">فرمت</span>
                    <span className="font-semibold uppercase">{selectedItem.format}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">محصول مرتبط</span>
                    <span className="font-semibold truncate">{selectedItem.associatedProduct || 'سراسری'}</span>
                  </div>
                </div>

                {selectedItem.format !== 'webp' && (
                  <button
                    onClick={() => handleConvertToWebp(selectedItem.id)}
                    className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition flex items-center justify-center gap-1.5"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>تبدیل فوری به فرمت مدرن WebP (-۵۵٪ حجم)</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400">
              <ImageIcon className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-xs font-medium">یک تصویر را از جدول انتخاب کنید تا مشخصات و سئوی آن نمایش داده شود.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
