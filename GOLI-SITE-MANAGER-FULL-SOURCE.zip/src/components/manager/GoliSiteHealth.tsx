import React, { useState } from 'react';
import { 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Activity, 
  RefreshCw, 
  Gauge, 
  Server, 
  Cpu, 
  Check,
  RotateCcw
} from 'lucide-react';
import { SiteHealthMetric } from '../../types/manager';

interface GoliSiteHealthProps {
  metrics: SiteHealthMetric[];
}

export const GoliSiteHealth: React.FC<GoliSiteHealthProps> = ({
  metrics,
}) => {
  const [isRunningAudit, setIsRunningAudit] = useState(false);
  const [auditCompleteNotice, setAuditCompleteNotice] = useState(false);

  const handleRunDiagnostics = () => {
    setIsRunningAudit(true);
    setAuditCompleteNotice(false);
    setTimeout(() => {
      setIsRunningAudit(false);
      setAuditCompleteNotice(true);
      setTimeout(() => setAuditCompleteNotice(false), 3000);
    }, 1500);
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Health Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-[#0f382c] via-[#164e3f] to-[#0a2920] border border-[#d4af37]/30 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f3e5ab] text-xs font-bold">
            <Zap className="w-4 h-4 text-[#d4af37]" />
            <span>Goli Site Health — پایش Core Web Vitals و کش لایت‌اسپید</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black">
            سلامت فنی، سرعت لود و بهینه‌سازی سرور golikala.com
          </h1>
          <p className="text-xs text-[#c4d6ce]">
            بررسی تخصصی زمان پاسخ سرور (TTFB)، رندر بزرگترین عنصر (LCP)، ثبات چیدمان (CLS) و هماهنگی با المنتور.
          </p>
        </div>

        <button
          onClick={handleRunDiagnostics}
          disabled={isRunningAudit}
          className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-[#0f382c] rounded-xl text-xs font-black shadow-md cursor-pointer hover:scale-102 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isRunningAudit ? 'animate-spin' : ''}`} />
          <span>{isRunningAudit ? 'در حال اجرای تست‌های زنده...' : 'اجرای اسکن فنی سلامت'}</span>
        </button>
      </div>

      {auditCompleteNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>اسکن کامل سرور لایت‌اسپید به پایان رسید. هیچ خطای بحرانی یا کندی در دیتابیس وردپرس یافت نشد.</span>
        </div>
      )}

      {/* Core Web Vitals Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] text-slate-400 block font-bold">زمان پاسخ سرور (TTFB)</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">۲۴۰ ms</div>
          <span className="text-[10px] text-emerald-600 font-bold block">محدوده سبز و سریع گوگل</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] text-slate-400 block font-bold">سرعت بزرگترین المان (LCP)</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">۱.۷ s</div>
          <span className="text-[10px] text-emerald-600 font-bold block">زیر ۲.۵ ثانیه (ایده‌آل)</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] text-slate-400 block font-bold">جابجایی چیدمان (CLS)</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">۰.۰۲</div>
          <span className="text-[10px] text-emerald-600 font-bold block">بدون پرش صفحه</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] text-slate-400 block font-bold">تعامل و پاسخ لمسی (INP)</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">۳۸ ms</div>
          <span className="text-[10px] text-emerald-600 font-bold block">پاسخ سریع برای موبایل</span>
        </div>
      </div>

      {/* Detailed Technical Metrics List */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <Gauge className="w-5 h-5 text-[#0f382c]" />
            <span>شاخص‌های دقیق بررسی فنی وردپرس و سرور :</span>
          </h3>
          <span className="text-xs text-slate-400">آخرین پایش خودکار : هم اکنون</span>
        </div>

        <div className="space-y-3">
          {metrics.map((m) => (
            <div key={m.id} className="p-4 rounded-2xl bg-[#fcfbf7] border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900">{m.title}</span>
                <span className="text-emerald-700 font-mono font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  {m.value}
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                {m.recommendation}
              </p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
