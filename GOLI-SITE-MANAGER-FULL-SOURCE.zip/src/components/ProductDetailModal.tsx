import React, { useState } from 'react';
import { 
  X, 
  Star, 
  ShieldCheck, 
  Truck, 
  CheckCircle2, 
  Award, 
  ShoppingBag, 
  QrCode, 
  MessageSquare, 
  Sparkles, 
  Link2, 
  Check, 
  Send, 
  ThumbsUp, 
  FileSearch, 
  ExternalLink,
  ArrowLeftRight
} from 'lucide-react';
import { Product, Review } from '../types';
import { BundleOfferCard } from './BundleOfferCard';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onAddBundleToCart?: (products: Product[]) => void;
  onAddToCompare?: (product: Product) => void;
  allProducts: Product[];
  onSelectProduct: (p: Product) => void;
  reviews: Review[];
  onAddReview: (review: Omit<Review, 'id' | 'date'>) => void;
  onOpenAuthenticity: (batchCode?: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onAddBundleToCart,
  onAddToCompare,
  allProducts,
  onSelectProduct,
  reviews,
  onAddReview,
  onOpenAuthenticity,
}) => {
  const [selectedImage, setSelectedImage] = useState(product.image);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'reviews' | 'seo'>('desc');
  const [addedNotice, setAddedNotice] = useState(false);
  const [compareNotice, setCompareNotice] = useState(false);

  // New Review Form State
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');
  const [confirmAuthentic, setConfirmAuthentic] = useState(true);
  const [newReviewSubmitted, setNewReviewSubmitted] = useState(false);

  const productReviews = reviews.filter(r => r.productId === product.id);

  // Complementary products
  const complementaryProducts = allProducts.filter(p => 
    product.complementaryProductIds?.includes(p.id)
  );

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewName.trim() || !newReviewComment.trim()) return;

    onAddReview({
      productId: product.id,
      userName: newReviewName,
      rating: newReviewRating,
      comment: newReviewComment,
      verifiedPurchase: true,
      confirmedAuthentic: confirmAuthentic,
    });

    setNewReviewName('');
    setNewReviewComment('');
    setNewReviewSubmitted(true);
    setTimeout(() => setNewReviewSubmitted(false), 3000);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div 
        className="relative bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Bar with Close */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80 shrink-0">
          <div className="flex items-center gap-2">
            <span className="bg-rose-100 text-rose-800 text-xs font-bold px-2.5 py-1 rounded-lg">
              {product.brand} ({product.brandEn})
            </span>
            <span className="text-xs text-slate-500">
              دسته بندی : {product.category}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors"
            title="بستن پنجره"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-8 flex-1">
          
          {/* Top Section: Gallery + Key Info */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            
            {/* Gallery Column */}
            <div className="md:col-span-5 space-y-4">
              <div className="relative aspect-square rounded-2xl overflow-hidden border border-slate-200 bg-slate-50">
                <img
                  src={selectedImage}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {product.isOfficialAgency && (
                  <div className="absolute top-3 right-3 bg-rose-600 text-white text-[10px] font-black px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
                    <span>نمایندگی رسمی گلی کالا</span>
                  </div>
                )}
              </div>

              {/* Thumbnails */}
              {product.gallery && product.gallery.length > 1 && (
                <div className="flex gap-2">
                  {product.gallery.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedImage(img)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                        selectedImage === img ? 'border-rose-600 scale-105' : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Batch Code Checker Card */}
              <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <div className="font-bold text-emerald-900 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>بچ کد رسمی کارخانه : {product.batchCodeExample}</span>
                  </div>
                  <div className="text-[11px] text-emerald-700">تولید اسپانیا / اروپا با تاییدیه بهداشتی</div>
                </div>

                <button
                  onClick={() => onOpenAuthenticity(product.batchCodeExample)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  استعلام بچ کد
                </button>
              </div>

            </div>

            {/* Product Details Column */}
            <div className="md:col-span-7 space-y-4">
              
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                  <span>نام لاتین : {product.originalName}</span>
                </div>
                <h1 className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
                  {product.name}
                </h1>
              </div>

              {/* Rating & Review Counter */}
              <div className="flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1 text-amber-500 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span className="font-black text-slate-800">{product.rating.toLocaleString('fa-IR')}</span>
                  <span className="text-slate-500">از ۵</span>
                </div>
                <span className="text-slate-400">|</span>
                <span className="text-slate-600 font-medium">{product.reviewsCount.toLocaleString('fa-IR')} خریدار راضی</span>
                <span className="text-slate-400">|</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  موجود در انبار تهران
                </span>
              </div>

              {/* Price Row */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-500 block mb-0.5">قیمت ویژه نمایندگی رسمی :</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-rose-600">
                      {formatPrice(product.price)}
                    </span>
                    {product.oldPrice && (
                      <span className="text-xs text-slate-400 line-through">
                        {product.oldPrice.toLocaleString('fa-IR')}
                      </span>
                    )}
                  </div>
                </div>

                {product.discountPercent && product.discountPercent > 0 && (
                  <span className="bg-rose-600 text-white text-xs font-black px-3 py-1 rounded-full shadow-xs">
                    {product.discountPercent.toLocaleString('fa-IR')}٪ تخفیف گلی کالا
                  </span>
                )}
              </div>

              {/* Short Description */}
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                {product.shortDescription}
              </p>

              {/* Quantity & Add to Cart */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <div className="flex items-center border border-slate-300 rounded-xl bg-white overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 text-slate-600 hover:bg-slate-100 font-bold"
                  >
                    -
                  </button>
                  <span className="px-4 py-2 font-black text-xs text-slate-800">
                    {quantity.toLocaleString('fa-IR')}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 text-slate-600 hover:bg-slate-100 font-bold"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-xl text-sm font-black transition-all shadow-md cursor-pointer ${
                    addedNotice 
                      ? 'bg-emerald-600 text-white shadow-emerald-200' 
                      : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-200 hover:scale-102'
                  }`}
                >
                  {addedNotice ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>به سبد خرید شما افزوده شد</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>افزودن به سبد خرید</span>
                    </>
                  )}
                </button>

                {onAddToCompare && (
                  <button
                    onClick={() => {
                      onAddToCompare(product);
                      setCompareNotice(true);
                      setTimeout(() => setCompareNotice(false), 2000);
                    }}
                    className="p-3 rounded-xl border border-slate-200 hover:border-rose-400 bg-white text-slate-700 hover:text-rose-600 transition-all flex items-center gap-1.5 text-xs font-bold shadow-2xs"
                    title="افزودن به جدول مقایسه کالا"
                  >
                    {compareNotice ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span className="text-emerald-700">اضافه شد</span>
                      </>
                    ) : (
                      <>
                        <ArrowLeftRight className="w-4 h-4" />
                        <span>مقایسه</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Trust badges */}
              <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] text-slate-500">
                <div className="flex items-center gap-1.5 p-2 rounded-lg bg-slate-100/70">
                  <Truck className="w-3.5 h-3.5 text-rose-600" />
                  <span>ارسال با تیپاکس و پست پیشتاز</span>
                </div>
                <div className="flex items-center gap-1.5 p-2 rounded-lg bg-slate-100/70">
                  <Award className="w-3.5 h-3.5 text-amber-600" />
                  <span>ضمانت برگشت وجه ۷ روزه</span>
                </div>
              </div>

            </div>

          </div>

          {/* Smart Routine Bundle Offer Recommender */}
          {onAddBundleToCart && (
            <BundleOfferCard
              primaryProduct={product}
              allProducts={allProducts}
              onAddBundleToCart={onAddBundleToCart}
            />
          )}

          {/* Complementary & Related Products for Internal Linking */}
          {complementaryProducts.length > 0 && (
            <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-black text-amber-950">
                    مکمل های پیشنهادی و ترکیبی این محصول (لینک داخلی گلی کالا)
                  </span>
                </div>
                <span className="text-[11px] text-amber-700">بهترین نتیجه در مصرف همزمان</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {complementaryProducts.map(comp => (
                  <div
                    key={comp.id}
                    onClick={() => {
                      onSelectProduct(comp);
                      setSelectedImage(comp.image);
                    }}
                    className="flex items-center gap-3 p-2.5 bg-white rounded-xl border border-amber-200 hover:border-rose-400 transition-all cursor-pointer shadow-2xs"
                  >
                    <img src={comp.image} alt={comp.name} className="w-12 h-12 object-cover rounded-lg shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-slate-900 truncate">{comp.name}</div>
                      <div className="text-[11px] text-rose-600 font-bold">{formatPrice(comp.price)}</div>
                    </div>
                    <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-lg shrink-0">
                      مشاهده
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab Navigation: Descriptions / Specifications / Reviews / RankMath SEO */}
          <div>
            <div className="flex border-b border-slate-200 text-xs sm:text-sm font-bold gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setActiveTab('desc')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'desc' 
                    ? 'border-rose-600 text-rose-600 font-black' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                توضیحات تخصصی و اثرات
              </button>
              <button
                onClick={() => setActiveTab('specs')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'specs' 
                    ? 'border-rose-600 text-rose-600 font-black' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                جدول مشخصات و ترکیبات
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'reviews' 
                    ? 'border-rose-600 text-rose-600 font-black' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <span>نظرات خریداران و تایید اصالت</span>
                <span className="bg-slate-200 text-slate-700 text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                  {productReviews.length.toLocaleString('fa-IR')}
                </span>
              </button>
              <button
                onClick={() => setActiveTab('seo')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1 ${
                  activeTab === 'seo' 
                    ? 'border-emerald-600 text-emerald-700 font-black' 
                    : 'border-transparent text-emerald-700/80 hover:text-emerald-900'
                }`}
              >
                <FileSearch className="w-3.5 h-3.5" />
                <span>تحلیل سئو و رنک مث (Rank Math)</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="pt-4">
              
              {/* Tab 1: Description */}
              {activeTab === 'desc' && (
                <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
                  <p className="bg-slate-50 p-4 rounded-2xl border border-slate-200/70 font-normal">
                    {product.fullDescription}
                  </p>

                  <h3 className="font-bold text-slate-900 text-sm pt-2">
                    ویژگی های برجسته محصول اروپایی :
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {product.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="text-xs text-slate-800 font-medium">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 2: Specifications Table */}
              {activeTab === 'specs' && (
                <div className="overflow-hidden border border-slate-200 rounded-2xl">
                  <table className="w-full text-right text-xs">
                    <tbody>
                      {Object.entries(product.specifications).map(([key, val], idx) => (
                        <tr key={key} className={idx % 2 === 0 ? 'bg-slate-50' : 'bg-white'}>
                          <td className="py-3 px-4 font-bold text-slate-700 w-1/3 border-b border-slate-200/60">
                            {key}
                          </td>
                          <td className="py-3 px-4 text-slate-600 border-b border-slate-200/60 font-medium">
                            {val}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Tab 3: Reviews & Authenticity Feedback */}
              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  
                  {/* Reviews List */}
                  <div className="space-y-3">
                    {productReviews.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl border border-slate-200">
                        هنوز نظری برای این کالا ثبت نشده است. اولین خریدار باشید که نظر خود و تاییدیه اصالت را ثبت می کند !
                      </div>
                    ) : (
                      productReviews.map(rev => (
                        <div key={rev.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-slate-900">{rev.userName}</span>
                              {rev.verifiedPurchase && (
                                <span className="bg-slate-200 text-slate-700 text-[10px] px-2 py-0.5 rounded-full font-medium">
                                  خریدار تایید شده
                                </span>
                              )}
                              {rev.confirmedAuthentic && (
                                <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                  <span>تایید اصالت کالا توسط خریدار</span>
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-400">{rev.date}</span>
                          </div>

                          {/* Stars */}
                          <div className="flex items-center gap-1 text-amber-500">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`}
                              />
                            ))}
                          </div>

                          {/* Comment */}
                          <p className="text-xs text-slate-700 leading-relaxed font-normal">
                            {rev.comment}
                          </p>

                          {/* Pros & Cons */}
                          {rev.pros && rev.pros.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {rev.pros.map((p, i) => (
                                <span key={i} className="text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md font-medium">
                                  + {p}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>

                  {/* Add Review Form */}
                  <form onSubmit={handleReviewSubmit} className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-1.5">
                        <MessageSquare className="w-4 h-4 text-rose-600" />
                        <span>ثبت نظر و تجربه اصالت سنجی شما</span>
                      </h4>
                      <span className="text-[11px] text-slate-400">نظرات پس از تایید نمایش داده می شوند</span>
                    </div>

                    {newReviewSubmitted && (
                      <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800 flex items-center gap-2">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>نظر و تاییدیه اصالت شما با موفقیت ثبت شد و به زودی منتشر می گردد.</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">نام و نام خانوادگی :</label>
                        <input
                          type="text"
                          required
                          value={newReviewName}
                          onChange={(e) => setNewReviewName(e.target.value)}
                          placeholder="مثلا : کامران گلی"
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:border-rose-500 focus:bg-white"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">امتیاز شما به کیفیت محصول :</label>
                        <div className="flex items-center gap-2 py-1.5">
                          {[1, 2, 3, 4, 5].map((st) => (
                            <button
                              key={st}
                              type="button"
                              onClick={() => setNewReviewRating(st)}
                              className="focus:outline-hidden"
                            >
                              <Star className={`w-5 h-5 ${st <= newReviewRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`} />
                            </button>
                          ))}
                          <span className="text-xs font-bold text-slate-600 mr-2">
                            {newReviewRating.toLocaleString('fa-IR')} از ۵
                          </span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">متن دیدگاه شما :</label>
                      <textarea
                        required
                        rows={3}
                        value={newReviewComment}
                        onChange={(e) => setNewReviewComment(e.target.value)}
                        placeholder="نظر خود را درباره اثرگذاری ، رایحه و اصالت بسته بندی بنویسید..."
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:border-rose-500 focus:bg-white leading-relaxed"
                      />
                    </div>

                    {/* Authenticity verification checkbox */}
                    <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
                      <input
                        type="checkbox"
                        id="auth-check"
                        checked={confirmAuthentic}
                        onChange={(e) => setConfirmAuthentic(e.target.checked)}
                        className="w-4 h-4 text-emerald-600 rounded-md border-slate-300 focus:ring-emerald-500"
                      />
                      <label htmlFor="auth-check" className="text-xs font-bold text-emerald-900 cursor-pointer">
                        من اصالت کالا ، بسته بندی و بچ کد اسپانیایی / اروپایی این محصول را تایید می نمایم.
                      </label>
                    </div>

                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-2 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>ثبت دیدگاه و بررسی اصالت</span>
                    </button>
                  </form>

                </div>
              )}

              {/* Tab 4: Rank Math SEO & Meta Inspection */}
              {activeTab === 'seo' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-emerald-900">نمره سئو رنک مث (Rank Math Score)</div>
                      <div className="text-xl font-black text-emerald-700">
                        {product.rankMathSeo.score.toLocaleString('fa-IR')} / ۱۰۰ (عالی و بهینه)
                      </div>
                    </div>
                    <span className="text-xs bg-emerald-200 text-emerald-900 px-3 py-1 rounded-full font-bold">
                      استاندارد ۲۰۲۶ گوگل
                    </span>
                  </div>

                  {/* Google Search Result Preview Simulation */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-1 text-right">
                    <div className="text-[11px] text-slate-500 flex items-center gap-1">
                      <span>https://golikala.com</span>
                      <span>›</span>
                      <span>products</span>
                      <span>›</span>
                      <span>{product.id}</span>
                    </div>
                    <div className="text-sm font-bold text-blue-700 hover:underline cursor-pointer">
                      {product.rankMathSeo.seoTitle}
                    </div>
                    <div className="text-xs text-slate-600 leading-relaxed font-normal">
                      {product.rankMathSeo.metaDescription}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-slate-500 block mb-1">کلمه کلیدی کانونی (Focus Keyword) :</span>
                      <strong className="text-rose-600 font-bold">{product.rankMathSeo.focusKeyword}</strong>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-slate-500 block mb-1">ساختار نشانه گذاری داده (Schema) :</span>
                      <strong className="text-emerald-700 font-bold">Product + AggregateRating + Offer</strong>
                    </div>
                  </div>

                </div>
              )}

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
