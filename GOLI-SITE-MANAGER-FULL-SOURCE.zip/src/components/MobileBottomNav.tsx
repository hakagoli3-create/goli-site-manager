import React from 'react';
import { 
  Home, 
  ShoppingBag, 
  Flame, 
  ShieldCheck, 
  User, 
  Layers
} from 'lucide-react';

interface MobileBottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  cartCount: number;
  openCart: () => void;
  openUserDashboard: () => void;
  openAuthenticityModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  setCurrentTab,
  cartCount,
  openCart,
  openUserDashboard,
  openAuthenticityModal,
}) => {
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-lg shadow-slate-900/10">
      <div className="grid grid-cols-5 gap-1 text-center">
        
        {/* Home */}
        <button
          onClick={() => setCurrentTab('home')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            currentTab === 'home' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">خانه</span>
        </button>

        {/* Shop */}
        <button
          onClick={() => setCurrentTab('shop')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            currentTab === 'shop' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">فروشگاه</span>
        </button>

        {/* Campaigns */}
        <button
          onClick={() => setCurrentTab('campaigns')}
          className={`flex flex-col items-center justify-center py-1 transition-colors relative ${
            currentTab === 'campaigns' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Flame className="w-5 h-5 text-amber-500" />
          <span className="text-[10px] mt-0.5">جشنواره</span>
          <span className="absolute top-0 right-1/4 w-2 h-2 rounded-full bg-rose-600" />
        </button>

        {/* Cart */}
        <button
          onClick={openCart}
          className="flex flex-col items-center justify-center py-1 text-slate-500 hover:text-rose-600 transition-colors relative"
        >
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">سبد خرید</span>
          {cartCount > 0 && (
            <span className="absolute top-0.5 right-1/4 bg-rose-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
              {cartCount.toLocaleString('fa-IR')}
            </span>
          )}
        </button>

        {/* User Account */}
        <button
          onClick={openUserDashboard}
          className="flex flex-col items-center justify-center py-1 text-slate-500 hover:text-rose-600 transition-colors"
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">حساب من</span>
        </button>

      </div>
    </nav>
  );
};
