import React from 'react';
import { 
  ShieldCheck, 
  Award, 
  Sparkles, 
  ArrowLeft, 
  CheckCircle, 
  PackageCheck, 
  Flame,
  BadgeCheck
} from 'lucide-react';

interface HeroBannerProps {
  onShopClick: () => void;
  onBrandClick: (brand: string) => void;
  onAuthenticityClick: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onShopClick,
  onBrandClick,
  onAuthenticityClick,
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white py-12 lg:py-20 border-b border-slate-800">
      
      {/* Background glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-rose-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Main Info Column */}
          <div className="lg:col-span-7 space-y-6 text-right">
            
            {/* Agency Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-bold">
              <BadgeCheck className="w-4 h-4 text-rose-400" />
              <span>نماینده رسمی و انحصاری محصولات اروپایی در ایران</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black leading-tight sm:leading-snug text-white">
              تجربه اصالت بی قید و شرط با برندهای <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-l from-rose-400 via-amber-300 to-rose-200">
                آمالفی (Amalfi) ، آگرادو (Agrado) و سایرو (Syro)
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl font-normal">
              فروشگاه اینترنتی گلی کالا تنها وارد کننده رسمی و دارای تاییدیه آزمایشگاهی محصولات پوستی و موی اصل اروپا می باشد. کلیه محصولات همراه با برچسب اصالت ، بچ کد قابل پیگیری و ضمانت قطعی مرجوعی وجه در صورت هرگونه عدم رضایت ارائه می شوند.
            </p>

            {/* Quick Feature Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>ضمانت ۱۰۰٪ اصالت کالا</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60">
                <PackageCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>استعلام آنلاین بچ کد</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 col-span-2 sm:col-span-1">
                <Award className="w-4 h-4 text-rose-400 shrink-0" />
                <span>فرمولاسیون اصل اسپانیا</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-4">
              <button
                onClick={onShopClick}
                className="flex items-center gap-2 px-6 py-3.5 bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-600 text-white rounded-xl text-sm font-black shadow-lg shadow-rose-900/40 transition-all hover:scale-102 cursor-pointer"
              >
                <span>مشاهده و خرید محصولات</span>
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                onClick={onAuthenticityClick}
                className="flex items-center gap-2 px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-sm font-bold transition-all cursor-pointer"
              >
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>سامانه استعلام اصالت</span>
              </button>
            </div>

            {/* Brand Quick Links */}
            <div className="pt-2 flex items-center gap-2 text-xs text-slate-400">
              <span className="shrink-0 font-medium">دسترسی سریع به نمایندگی ها :</span>
              <div className="flex flex-wrap gap-1.5">
                <button 
                  onClick={() => onBrandClick('آگرادو')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-rose-900/50 hover:text-rose-300 border border-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                >
                  آگرادو (Agrado)
                </button>
                <button 
                  onClick={() => onBrandClick('آمالفی')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-rose-900/50 hover:text-rose-300 border border-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                >
                  آمالفی (Amalfi)
                </button>
                <button 
                  onClick={() => onBrandClick('سایرو')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-rose-900/50 hover:text-rose-300 border border-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                >
                  سایرو (Syro)
                </button>
              </div>
            </div>

          </div>

          {/* Visual Showcase Card */}
          <div className="lg:col-span-5">
            <div className="relative bg-gradient-to-tr from-slate-800/90 to-slate-800/40 border border-slate-700/80 rounded-3xl p-6 shadow-2xl backdrop-blur-xs">
              
              <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold text-emerald-400">انبار مرکزی گلی کالا فعال است</span>
                </div>
                <span className="text-[11px] bg-rose-500/20 text-rose-300 px-2.5 py-1 rounded-full font-bold">
                  محصولات جدید ۲۰۲۶
                </span>
              </div>

              {/* Showcase Grid of 3 Brands */}
              <div className="mt-5 space-y-3">
                <div 
                  onClick={() => onBrandClick('آگرادو')}
                  className="group flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-700/50 border border-slate-700/50 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <img 
                      src="https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=120&q=80" 
                      alt="Agrado"
                      className="w-12 h-12 object-cover rounded-xl border border-slate-700" 
                    />
                    <div className="text-right">
                      <div className="text-sm font-black text-white group-hover:text-rose-400 transition-colors">
                        لاین کراتین و احیای مو آگرادو (Agrado)
                      </div>
                      <div className="text-xs text-slate-400">واردات مستقیم از کارخانه والنسیا اسپانیا</div>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-lg">
                    پر تقاضا
                  </span>
                </div>

                <div 
                  onClick={() => onBrandClick('آمالفی')}
                  className="group flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-700/50 border border-slate-700/50 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <img 
                      src="https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=120&q=80" 
                      alt="Amalfi"
                      className="w-12 h-12 object-cover rounded-xl border border-slate-700" 
                    />
                    <div className="text-right">
                      <div className="text-sm font-black text-white group-hover:text-rose-400 transition-colors">
                        لوسیون و مراقبت بدن آمالفی (Amalfi)
                      </div>
                      <div className="text-xs text-slate-400">حاوی عصاره آلوئه ورا و آرگان خالص اسپانیا</div>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-400/10 px-2.5 py-1 rounded-lg">
                    تضمین اصالت
                  </span>
                </div>

                <div 
                  onClick={() => onBrandClick('سایرو')}
                  className="group flex items-center justify-between p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-700/50 border border-slate-700/50 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <img 
                      src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=120&q=80" 
                      alt="Syro"
                      className="w-12 h-12 object-cover rounded-xl border border-slate-700" 
                    />
                    <div className="text-right">
                      <div className="text-sm font-black text-white group-hover:text-rose-400 transition-colors">
                        میسلار و شوینده های درماتولوژی سایرو (Syro)
                      </div>
                      <div className="text-xs text-slate-400">فرمولاسیون هایپوآلرژنیک استاندارد اروپا</div>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-sky-400 bg-sky-400/10 px-2.5 py-1 rounded-lg">
                    درماتولوژی
                  </span>
                </div>
              </div>

              {/* Bottom statistics */}
              <div className="mt-5 pt-4 border-t border-slate-700/60 grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-base sm:text-lg font-black text-amber-400">۱۰۰٪</div>
                  <div className="text-[11px] text-slate-400">تضمین اصالت فیزیکی</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg font-black text-rose-400">+۱۰,۰۰۰</div>
                  <div className="text-[11px] text-slate-400">سفارش موفق در گلی کالا</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg font-black text-emerald-400">۲۴ ساعته</div>
                  <div className="text-[11px] text-slate-400">ارسال با رهگیری لحظه ای</div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
