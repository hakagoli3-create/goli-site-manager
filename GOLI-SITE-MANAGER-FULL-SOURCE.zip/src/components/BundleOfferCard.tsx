import React, { useState } from 'react';
import { 
  Sparkles, 
  Plus, 
  ShoppingBag, 
  Check, 
  ShieldCheck, 
  Tag,
  ArrowLeft
} from 'lucide-react';
import { Product } from '../types';

interface BundleOfferCardProps {
  primaryProduct: Product;
  allProducts: Product[];
  onAddBundleToCart: (products: Product[]) => void;
}

export const BundleOfferCard: React.FC<BundleOfferCardProps> = ({
  primaryProduct,
  allProducts,
  onAddBundleToCart,
}) => {
  const [bundleAdded, setBundleAdded] = useState(false);

  // Find complementary products from the same brand or matching routine
  const complementItems = allProducts.filter(p => 
    p.id !== primaryProduct.id && 
    (primaryProduct.complementaryProductIds?.includes(p.id) || p.brand === primaryProduct.brand)
  ).slice(0, 2);

  if (complementItems.length === 0) return null;

  const bundleList = [primaryProduct, ...complementItems];
  const totalPrice = bundleList.reduce((sum, p) => sum + p.price, 0);
  const bundleDiscountPercent = 12; // 12% extra discount for buying the complete routine
  const discountedPrice = Math.round(totalPrice * (1 - bundleDiscountPercent / 100));
  const savedAmount = totalPrice - discountedPrice;

  const handleBuyBundle = () => {
    onAddBundleToCart(bundleList);
    setBundleAdded(true);
    setTimeout(() => setBundleAdded(false), 2500);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="p-5 rounded-3xl bg-gradient-to-tr from-rose-50 via-amber-50/40 to-white border-2 border-rose-200/90 shadow-md text-right space-y-4">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-rose-200/70">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black text-slate-900">
              پیشنهاد هوشمند پکیج روتین مکمل {primaryProduct.brand}
            </h4>
            <span className="text-[11px] text-rose-700 font-medium">
              محصولات مکمل این سری با اثربخشی دوچندان و تخفیف ست
            </span>
          </div>
        </div>

        <span className="bg-rose-600 text-white text-[11px] font-black px-3 py-1 rounded-full shadow-xs self-start sm:self-auto">
          {bundleDiscountPercent.toLocaleString('fa-IR')}٪ تخفیف پکیج ست
        </span>
      </div>

      {/* Bundle Items Visual Equation */}
      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 py-2">
        {bundleList.map((item, idx) => (
          <React.Fragment key={item.id}>
            <div className="flex items-center gap-2.5 p-2 bg-white rounded-2xl border border-rose-100 shadow-2xs max-w-[200px]">
              <img
                src={item.image}
                alt={item.name}
                className="w-12 h-12 object-cover rounded-xl border border-slate-100 shrink-0"
              />
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-900 truncate">{item.name}</div>
                <div className="text-[10px] text-rose-600 font-bold">{formatPrice(item.price)}</div>
              </div>
            </div>

            {idx < bundleList.length - 1 && (
              <div className="w-7 h-7 rounded-full bg-rose-200 text-rose-700 font-black flex items-center justify-center text-xs shrink-0 shadow-2xs">
                +
              </div>
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Pricing Summary & 1-Click Action */}
      <div className="p-4 rounded-2xl bg-white border border-rose-200/80 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="space-y-0.5 text-center sm:text-right">
          <div className="text-xs text-slate-500">
            مجموع قیمت تکی : <span className="line-through">{formatPrice(totalPrice)}</span>
          </div>
          <div className="flex items-baseline gap-2 justify-center sm:justify-start">
            <span className="text-base sm:text-lg font-black text-rose-600">
              {formatPrice(discountedPrice)}
            </span>
            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              (سود شما : {formatPrice(savedAmount)})
            </span>
          </div>
        </div>

        <button
          onClick={handleBuyBundle}
          className={`w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
            bundleAdded
              ? 'bg-emerald-600 text-white shadow-emerald-200'
              : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-200 hover:scale-102'
          }`}
        >
          {bundleAdded ? (
            <>
              <Check className="w-4 h-4" />
              <span>پکیج با تخفیف به سبد خرید افزوده شد !</span>
            </>
          ) : (
            <>
              <ShoppingBag className="w-4 h-4" />
              <span>خرید کل پکیج مکمل با ۱ کلیک</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </>
          )}
        </button>
      </div>

    </div>
  );
};
