import React, { useState } from 'react';
import { 
  Monitor, 
  Tablet, 
  Smartphone, 
  Sparkles, 
  Palette, 
  Layers, 
  RotateCcw, 
  Save, 
  Download, 
  Check, 
  Eye, 
  ShieldCheck, 
  Sliders, 
  History, 
  Zap, 
  Gauge, 
  CheckCircle2, 
  Image as ImageIcon,
  Copy,
  Code2,
  Settings,
  Plus
} from 'lucide-react';
import { Product } from '../types';

interface VisualElementorStudioProps {
  products: Product[];
}

interface VersionSnapshot {
  id: string;
  name: string;
  timestamp: string;
  primaryColor: string;
  borderRadius: number;
  layoutVariant: string;
}

export const VisualElementorStudio: React.FC<VisualElementorStudioProps> = ({
  products,
}) => {
  // Viewport mode
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activePanelTab, setActivePanelTab] = useState<'widgets' | 'templates' | 'design-system' | 'media' | 'history'>('widgets');

  // Design System States
  const [primaryColor, setPrimaryColor] = useState('#e11d48'); // Rose-600
  const [fontFamily, setFontFamily] = useState('Vazirmatn');
  const [borderRadius, setBorderRadius] = useState(16);
  const [shadowDepth, setShadowDepth] = useState<'mild' | 'deep' | 'glow'>('mild');

  // AI Layout Variation State (1: Minimal Luxury, 2: Promotional Festival, 3: High-Conversion Catalog)
  const [layoutVariant, setLayoutVariant] = useState<'minimal' | 'festival' | 'catalog'>('minimal');

  // Active Widgets in Elementor
  const [widgets, setWidgets] = useState({
    topAnnouncement: true,
    megaHeader: true,
    heroAgencyBanner: true,
    countdownTimer: true,
    bestsellerGrid: true,
    authenticitySection: true,
    expertBlogCards: true,
    footerFourPillars: true,
  });

  // Media Manager Banner
  const [currentHeroBanner, setCurrentHeroBanner] = useState(
    'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1200&q=80'
  );

  // Version History Snapshot System
  const [snapshots, setSnapshots] = useState<VersionSnapshot[]>([
    {
      id: 'snap-1',
      name: 'نسخه اولیه نمایندگی رسمی گلی کالا',
      timestamp: 'امروز - ۱۰:۳۰',
      primaryColor: '#e11d48',
      borderRadius: 16,
      layoutVariant: 'minimal'
    },
    {
      id: 'snap-2',
      name: 'نسخه جشنواره کراتین آگرادو',
      timestamp: 'امروز - ۱۲:۴۵',
      primaryColor: '#f59e0b',
      borderRadius: 20,
      layoutVariant: 'festival'
    }
  ]);
  const [snapshotSavedNotice, setSnapshotSavedNotice] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // Take Snapshot
  const handleSaveSnapshot = () => {
    const newSnap: VersionSnapshot = {
      id: `snap-${Date.now()}`,
      name: `تغییرات کاربر (چیدمان ${layoutVariant === 'minimal' ? 'مینیمال' : layoutVariant === 'festival' ? 'جشنواره' : 'کاتالوگی'})`,
      timestamp: 'هم اکنون',
      primaryColor,
      borderRadius,
      layoutVariant,
    };
    setSnapshots([newSnap, ...snapshots]);
    setSnapshotSavedNotice(true);
    setTimeout(() => setSnapshotSavedNotice(false), 2500);
  };

  // Revert to Snapshot
  const handleRevertSnapshot = (snap: VersionSnapshot) => {
    setPrimaryColor(snap.primaryColor);
    setBorderRadius(snap.borderRadius);
    setLayoutVariant(snap.layoutVariant as any);
  };

  // Toggle widget
  const handleToggleWidget = (key: keyof typeof widgets) => {
    setWidgets(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="py-6 bg-slate-950 text-white min-h-screen text-right">
      <div className="max-w-7xl mx-auto px-4 space-y-6">
        
        {/* Studio Top Control Bar */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-black text-white flex items-center gap-2">
                <span>استودیوی بازطراحی بصری و سیستم طراحی گلی کالا</span>
                <span className="text-[10px] bg-rose-600 text-white px-2 py-0.5 rounded-full font-bold">
                  ویژه المنتور وردپرس
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                طراحی تعاملی ، پیش نمایش زنده دسکتاپ و موبایل و بهینه سازی سراسری
              </p>
            </div>
          </div>

          {/* Viewport Switcher */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
            <button
              onClick={() => setViewport('desktop')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                viewport === 'desktop' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
              title="پیش نمایش دسکتاپ (۱۰۰٪)"
            >
              <Monitor className="w-4 h-4" />
              <span className="hidden sm:inline">دسکتاپ</span>
            </button>

            <button
              onClick={() => setViewport('tablet')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                viewport === 'tablet' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
              title="پیش نمایش تبلت (۷۶۸ پیکسل)"
            >
              <Tablet className="w-4 h-4" />
              <span className="hidden sm:inline">تبلت</span>
            </button>

            <button
              onClick={() => setViewport('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                viewport === 'mobile' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
              title="پیش نمایش موبایل (۳۷۵ پیکسل)"
            >
              <Smartphone className="w-4 h-4" />
              <span className="hidden sm:inline">موبایل</span>
            </button>
          </div>

          {/* Action Snapshot Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveSnapshot}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4 text-emerald-400" />
              <span>ذخیره نسخه</span>
            </button>

            <button
              onClick={() => {
                setCopiedCode(true);
                setTimeout(() => setCopiedCode(false), 2000);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer"
            >
              {copiedCode ? <Check className="w-4 h-4" /> : <Code2 className="w-4 h-4" />}
              <span>{copiedCode ? 'کد کپی شد !' : 'خروجی کدهای المنتور'}</span>
            </button>
          </div>

        </div>

        {/* Real-time Audit Score Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400 block">سرعت لود (PageSpeed)</span>
              <strong className="text-base font-black text-emerald-400 font-mono">۹۸ / ۱۰۰</strong>
            </div>
            <Zap className="w-5 h-5 text-emerald-400" />
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400 block">سئو رنک مث (Rank Math)</span>
              <strong className="text-base font-black text-emerald-400 font-mono">۱۰۰ / ۱۰۰</strong>
            </div>
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400 block">دسترس پذیری (A11y)</span>
              <strong className="text-base font-black text-cyan-400 font-mono">۹۷ / ۱۰۰</strong>
            </div>
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400 block">نرخ تبدیل خرید (CRO)</span>
              <strong className="text-base font-black text-rose-400 font-mono">۹۶ / ۱۰۰</strong>
            </div>
            <Gauge className="w-5 h-5 text-rose-400" />
          </div>
        </div>

        {snapshotSavedNotice && (
          <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>نسخه جدید با موفقیت در تاریخچه ذخیره گردید و امکان بازگشت در هر زمان فراهم است.</span>
          </div>
        )}

        {/* Main Workspace: Left Controls + Live Canvas */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Controls Panel (4 cols) */}
          <div className="lg:col-span-4 bg-slate-900 rounded-3xl border border-slate-800 p-5 space-y-6">
            
            {/* Panel Tabs */}
            <div className="flex border-b border-slate-800 pb-2 gap-2 text-xs font-bold overflow-x-auto">
              <button
                onClick={() => setActivePanelTab('widgets')}
                className={`pb-2 px-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activePanelTab === 'widgets' ? 'border-rose-500 text-rose-400 font-black' : 'border-transparent text-slate-400'
                }`}
              >
                ویجت‌ها
              </button>

              <button
                onClick={() => setActivePanelTab('design-system')}
                className={`pb-2 px-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activePanelTab === 'design-system' ? 'border-rose-500 text-rose-400 font-black' : 'border-transparent text-slate-400'
                }`}
              >
                سیستم طراحی
              </button>

              <button
                onClick={() => setActivePanelTab('templates')}
                className={`pb-2 px-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activePanelTab === 'templates' ? 'border-rose-500 text-rose-400 font-black' : 'border-transparent text-slate-400'
                }`}
              >
                طرح‌های AI
              </button>

              <button
                onClick={() => setActivePanelTab('media')}
                className={`pb-2 px-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activePanelTab === 'media' ? 'border-rose-500 text-rose-400 font-black' : 'border-transparent text-slate-400'
                }`}
              >
                رسانه‌ها
              </button>

              <button
                onClick={() => setActivePanelTab('history')}
                className={`pb-2 px-2 border-b-2 transition-colors cursor-pointer shrink-0 ${
                  activePanelTab === 'history' ? 'border-rose-500 text-rose-400 font-black' : 'border-transparent text-slate-400'
                }`}
              >
                نسخه‌ها ({snapshots.length})
              </button>
            </div>

            {/* TAB 1: WIDGETS TOGGLE */}
            {activePanelTab === 'widgets' && (
              <div className="space-y-3 text-xs">
                <h4 className="font-bold text-white mb-2">مدیریت بخش ها و سکشن های المنتور :</h4>

                {[
                  { key: 'topAnnouncement', label: 'نوار اعلامیه نمایندگی رسمی اروپا' },
                  { key: 'megaHeader', label: 'هدر و مگامنوی دسترسی سریع' },
                  { key: 'heroAgencyBanner', label: 'هیرو بنر معرفی آمالفی، آگرادو و سایرو' },
                  { key: 'countdownTimer', label: 'ویجت تایمر زنده شمارش معکوس تخفیف' },
                  { key: 'bestsellerGrid', label: 'گرید کارت محصولات پرفروش' },
                  { key: 'authenticitySection', label: 'سکشن اختصاصی استعلام بچ کد' },
                  { key: 'expertBlogCards', label: 'کارت های مقالات آموزشی و سئو' },
                  { key: 'footerFourPillars', label: 'فوتر ۴ ستونه تضمین و مجوزها' },
                ].map(item => (
                  <label
                    key={item.key}
                    onClick={() => handleToggleWidget(item.key as any)}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 cursor-pointer"
                  >
                    <span className="text-slate-300 font-medium">{item.label}</span>
                    <div className={`w-8 h-4 rounded-full transition-colors relative p-0.5 ${
                      widgets[item.key as keyof typeof widgets] ? 'bg-rose-600' : 'bg-slate-600'
                    }`}>
                      <div className={`w-3 h-3 rounded-full bg-white transition-transform ${
                        widgets[item.key as keyof typeof widgets] ? 'translate-x-0' : '-translate-x-4'
                      }`} />
                    </div>
                  </label>
                ))}
              </div>
            )}

            {/* TAB 2: DESIGN SYSTEM */}
            {activePanelTab === 'design-system' && (
              <div className="space-y-4 text-xs">
                <h4 className="font-bold text-white mb-1">تنظیمات هویت بصری سراسری (Global Design System) :</h4>

                {/* Color Palette */}
                <div className="space-y-2">
                  <span className="text-slate-400 block font-bold">رنگ سازمانی اصلی (Primary Color) :</span>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { hex: '#e11d48', name: 'رز رویال' },
                      { hex: '#d97706', name: 'طلایی لوکس' },
                      { hex: '#059669', name: 'سبز درماتولوژی' },
                      { hex: '#4338ca', name: 'نیلی اروپایی' },
                    ].map(col => (
                      <button
                        key={col.hex}
                        onClick={() => setPrimaryColor(col.hex)}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          primaryColor === col.hex ? 'border-white scale-105' : 'border-slate-700'
                        }`}
                        style={{ backgroundColor: col.hex }}
                      >
                        <span className="text-[10px] font-black text-white drop-shadow-xs">{col.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Border Radius */}
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-bold">شعاع گردی دکمه ها و کارت ها :</span>
                    <span className="font-mono text-rose-400 font-black">{borderRadius}px</span>
                  </div>
                  <input
                    type="range"
                    min={4}
                    max={32}
                    value={borderRadius}
                    onChange={(e) => setBorderRadius(Number(e.target.value))}
                    className="w-full accent-rose-600 cursor-pointer"
                  />
                </div>

                {/* Typography */}
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <span className="text-slate-400 block font-bold">تایپوگرافی فارسی :</span>
                  <select
                    value={fontFamily}
                    onChange={(e) => setFontFamily(e.target.value)}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-hidden"
                  >
                    <option value="Vazirmatn">فونت وزیرمتن (پیشنهادی - استاندارد گوگل)</option>
                    <option value="Yekan Bakh">فونت یکان بخ (مدرن تجاری)</option>
                    <option value="Shabnam">فونت شبنم (خوانا و رسمی)</option>
                  </select>
                </div>
              </div>
            )}

            {/* TAB 3: AI LAYOUT GENERATOR */}
            {activePanelTab === 'templates' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300">
                  <strong>مولد چیدمان هوشمند :</strong> انتخاب بین ۳ کانسپت بصری متناسب با ترندهای روز فروشگاه های زیبایی اروپایی:
                </div>

                {[
                  {
                    id: 'minimal',
                    title: '۱. کانسپت مینیمال لوکس (Minimal Luxury)',
                    desc: 'طراحی خلوت ، تمرکز بر کیفیت بالای تصویر و تایپوگرافی چشم‌نواز'
                  },
                  {
                    id: 'festival',
                    title: '۲. کانسپت پروموشنال و جشنواره (Festival Impact)',
                    desc: 'تایمر معکوس برجسته ، بنرهای تخفیفی و هدایای ویژه نمایندگی'
                  },
                  {
                    id: 'catalog',
                    title: '۳. کانسپت کاتالوگ فروش سریع (High-CRO Catalog)',
                    desc: 'دکمه های خرید سریع ۱ کلیکه ، فیلترهای رو به رو و مقایسه کالاها'
                  }
                ].map(opt => (
                  <div
                    key={opt.id}
                    onClick={() => setLayoutVariant(opt.id as any)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      layoutVariant === opt.id
                        ? 'border-rose-500 bg-rose-500/15 shadow-sm'
                        : 'border-slate-800 bg-slate-800/60 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-white mb-1">
                      <span>{opt.title}</span>
                      {layoutVariant === opt.id && <Check className="w-4 h-4 text-rose-400" />}
                    </div>
                    <p className="text-[11px] text-slate-400">{opt.desc}</p>
                  </div>
                ))}
              </div>
            )}

            {/* TAB 4: MEDIA MANAGER */}
            {activePanelTab === 'media' && (
              <div className="space-y-3 text-xs">
                <h4 className="font-bold text-white">مدیریت تصاویر و بنرهای باکیفیت رسانه :</h4>
                <p className="text-[11px] text-slate-400">
                  تصویر بنر اصلی هیرو را با یک کلیک تعویض نمایید :
                </p>

                <div className="grid grid-cols-2 gap-2">
                  {[
                    {
                      name: 'بنر آرایشی بهداشتی لوکس',
                      url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80'
                    },
                    {
                      name: 'لاین مو و کراتین آگرادو',
                      url: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=600&q=80'
                    },
                    {
                      name: 'مراقبت پوست طبیعی آمالفی',
                      url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80'
                    },
                    {
                      name: 'درماتولوژی ملایم سایرو',
                      url: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=600&q=80'
                    }
                  ].map((med, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentHeroBanner(med.url)}
                      className={`relative aspect-video rounded-xl overflow-hidden border-2 transition-all ${
                        currentHeroBanner === med.url ? 'border-rose-500 scale-105' : 'border-slate-800 opacity-70'
                      }`}
                    >
                      <img src={med.url} alt="" className="w-full h-full object-cover" />
                      <span className="absolute bottom-1 right-1 text-[9px] bg-slate-900/90 text-white px-1.5 py-0.5 rounded-md">
                        {med.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 5: SNAPSHOTS & HISTORY */}
            {activePanelTab === 'history' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h4 className="font-bold text-white">تاریخچه تغییرات و بازگشت (Revert) :</h4>
                </div>

                <div className="space-y-2">
                  {snapshots.map(snap => (
                    <div key={snap.id} className="p-3 rounded-2xl bg-slate-800/90 border border-slate-700 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-xs">{snap.name}</span>
                        <span className="text-[10px] text-slate-400">{snap.timestamp}</span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>چیدمان : {snap.layoutVariant}</span>
                        <button
                          onClick={() => handleRevertSnapshot(snap)}
                          className="flex items-center gap-1 text-rose-400 hover:underline font-bold"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>بازگشت به این نسخه</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Live Preview Canvas (8 cols) */}
          <div className="lg:col-span-8 flex justify-center">
            <div 
              className={`bg-white text-slate-800 rounded-3xl shadow-2xl overflow-hidden border-4 border-slate-800 transition-all duration-300 ${
                viewport === 'desktop' 
                  ? 'w-full' 
                  : viewport === 'tablet' 
                  ? 'w-[768px] max-w-full' 
                  : 'w-[375px] max-w-full'
              }`}
            >
              
              {/* Virtual Browser Top Bar */}
              <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-400" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                </div>
                <span>https://golikala.com</span>
                <span className="text-[10px] bg-slate-200 px-2 py-0.5 rounded-md">
                  {viewport === 'desktop' ? '1280px' : viewport === 'tablet' ? '768px' : '375px'}
                </span>
              </div>

              {/* Canvas Content */}
              <div className="p-4 sm:p-6 space-y-6 text-right">
                
                {/* 1. Top Announcement Widget */}
                {widgets.topAnnouncement && (
                  <div 
                    className="p-2.5 text-white text-xs font-bold text-center rounded-xl flex items-center justify-center gap-2"
                    style={{ backgroundColor: primaryColor }}
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>نماینده رسمی و انحصاری محصولات آمالفی ، آگرادو و سایرو در ایران</span>
                  </div>
                )}

                {/* 2. Mega Header Simulation */}
                {widgets.megaHeader && (
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-8 h-8 rounded-xl text-white flex items-center justify-center text-xs font-black"
                        style={{ backgroundColor: primaryColor }}
                      >
                        گ
                      </div>
                      <span className="text-base font-black text-slate-900">گلی کالا (GoliKala)</span>
                    </div>
                    <div className="text-xs text-slate-500 flex gap-3">
                      <span className="font-bold text-rose-600">صفحه اصلی</span>
                      <span>آگرادو</span>
                      <span>آمالفی</span>
                      <span>سایرو</span>
                    </div>
                  </div>
                )}

                {/* 3. Hero Agency Banner */}
                {widgets.heroAgencyBanner && (
                  <div 
                    className="relative rounded-2xl overflow-hidden text-white p-6 sm:p-8"
                    style={{ borderRadius: `${borderRadius}px` }}
                  >
                    <img 
                      src={currentHeroBanner} 
                      alt="" 
                      className="absolute inset-0 w-full h-full object-cover" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-l from-slate-950/90 via-slate-950/60 to-transparent" />

                    <div className="relative z-10 max-w-md space-y-3">
                      <span className="inline-block text-[10px] font-black px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-xs">
                        {layoutVariant === 'minimal' ? 'کلکسیون مینیمال ۲۰۲۶' : layoutVariant === 'festival' ? 'جشنواره طلایی تخفیف' : 'پرفروش ترین محصولات'}
                      </span>
                      <h3 className="text-lg sm:text-2xl font-black text-white leading-tight">
                        مراقبت تخصصی مو و پوست با اصالت ۱۰۰٪ اروپا
                      </h3>
                      <button
                        className="px-4 py-2 text-white text-xs font-black rounded-xl shadow-md cursor-pointer"
                        style={{ backgroundColor: primaryColor, borderRadius: `${borderRadius}px` }}
                      >
                        خرید مستقیم از نمایندگی
                      </button>
                    </div>
                  </div>
                )}

                {/* 4. Countdown Timer Widget */}
                {widgets.countdownTimer && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                    <span className="font-bold text-amber-900">پیشنهاد شگفت انگیز نمایندگی تا :</span>
                    <span className="font-mono font-black text-rose-600">۲ روز و ۱۴:۲۸:۴۰</span>
                  </div>
                )}

                {/* 5. Bestseller Grid Widget */}
                {widgets.bestsellerGrid && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-black text-slate-900">محصولات منتخب</span>
                      <span className="text-rose-600 font-bold">مشاهده همه</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {products.slice(0, 2).map(p => (
                        <div 
                          key={p.id} 
                          className="p-3 bg-slate-50 border border-slate-200 text-xs space-y-2"
                          style={{ borderRadius: `${borderRadius}px` }}
                        >
                          <img src={p.image} alt="" className="w-full aspect-square object-cover rounded-lg" />
                          <div className="font-bold text-slate-800 line-clamp-1">{p.name}</div>
                          <div className="text-rose-600 font-black">{p.price.toLocaleString('fa-IR')} تومان</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 6. Authenticity Block Widget */}
                {widgets.authenticitySection && (
                  <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>استعلام آنلاین اصالت بچ کد و آزمایشگاه اسپانیا</span>
                    </div>
                    <span className="text-[11px] bg-emerald-600 text-white px-2 py-1 rounded-lg font-bold">
                      بررسی بچ کد
                    </span>
                  </div>
                )}

              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
