import React, { useState } from 'react';
import { 
  User, 
  Package, 
  Truck, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Smartphone, 
  Mail, 
  Copy, 
  ExternalLink, 
  ShieldCheck,
  Search,
  Check,
  X
} from 'lucide-react';
import { Order } from '../types';

interface UserDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onUpdateOrderStatus?: (orderId: string, newStatus: Order['status'], newSmsMessage: string) => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  isOpen,
  onClose,
  orders,
  onUpdateOrderStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'sms' | 'profile'>('orders');
  const [selectedOrder, setSelectedOrder] = useState<Order>(orders[0] || null);
  const [copiedTracking, setCopiedTracking] = useState<string | null>(null);

  // Profile fields state
  const [userName, setUserName] = useState('کامران گلی');
  const [userPhone, setUserPhone] = useState('۰۹۱۲۳۴۵۶۷۸۹');
  const [userEmail, setUserEmail] = useState('kamran0goli@gmail.com');
  const [profileSaved, setProfileSaved] = useState(false);

  if (!isOpen) return null;

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedTracking(code);
    setTimeout(() => setCopiedTracking(null), 2000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2500);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  // Timeline step helper
  const getStepStatus = (orderStatus: Order['status'], stepNumber: number) => {
    const statuses = ['در حال پردازش', 'آماده‌سازی در انبار', 'تحویل به پست', 'تحویل داده شده'];
    const currentIdx = statuses.indexOf(orderStatus);
    if (currentIdx >= stepNumber) return 'completed';
    if (currentIdx === stepNumber - 1) return 'current';
    return 'pending';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div 
        className="relative bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto max-h-[94vh] flex flex-col text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 flex items-center justify-center text-white font-black shadow-md">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-black flex items-center gap-2">
                <span>پنل اختصاصی کاربر : {userName}</span>
                <span className="text-[10px] bg-amber-400 text-slate-900 px-2 py-0.5 rounded-full font-bold">
                  مشتری وفادار گلی کالا
                </span>
              </div>
              <div className="text-xs text-slate-300 font-mono mt-0.5">
                {userPhone} | {userEmail}
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 px-6 bg-slate-50 text-xs sm:text-sm font-bold gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'orders' ? 'border-rose-600 text-rose-600 font-black' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>پیگیری سفارشات و وضعیت مرسوله</span>
            <span className="bg-rose-100 text-rose-700 text-[10px] px-1.5 py-0.5 rounded-full">
              {orders.length.toLocaleString('fa-IR')}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('sms')}
            className={`py-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'sms' ? 'border-rose-600 text-rose-600 font-black' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>سیستم اطلاع رسانی پیامکی و ایمیلی</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'profile' ? 'border-rose-600 text-rose-600 font-black' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>مشخصات و آدرس های پستی</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: ORDERS & TRACKING */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              
              {/* Order selector list */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {orders.map((order) => (
                  <div
                    key={order.id}
                    onClick={() => setSelectedOrder(order)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                      selectedOrder?.id === order.id
                        ? 'border-rose-600 bg-rose-50/40 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs">
                      <span className="font-bold text-slate-900">سفارش {order.trackingCode}</span>
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        order.status === 'تحویل داده شده' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {order.status}
                      </span>
                    </div>

                    <div className="py-2.5 space-y-1 text-xs text-slate-600">
                      <div>تاریخ ثبت : <strong className="text-slate-800">{order.date}</strong></div>
                      <div>مبلغ کل : <strong className="text-rose-600 font-black">{formatPrice(order.totalAmount)}</strong></div>
                      <div>شیوه حمل : <strong className="text-slate-800">{order.shippingMethod}</strong></div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                      <span>تعداد اقلام : {order.items.length} کالا</span>
                      <span className="text-rose-600 font-bold">مشاهده جزئیات و رهگیری زنده ←</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Detailed Live Tracking of Selected Order */}
              {selectedOrder && (
                <div className="p-5 rounded-3xl bg-slate-50 border border-slate-200 space-y-6">
                  
                  {/* Top info */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                    <div>
                      <h4 className="text-sm font-black text-slate-900">
                        رهگیری لحظه ای سفارش {selectedOrder.trackingCode}
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        ارسال به نشانی : {selectedOrder.address}
                      </p>
                    </div>

                    {/* Post tracking code copy */}
                    <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 self-start sm:self-auto">
                      <span className="text-xs text-slate-500">کد رهگیری پستی / تیپاکس :</span>
                      <span className="text-xs font-mono font-bold text-slate-900">{selectedOrder.postTrackingCode}</span>
                      <button
                        onClick={() => handleCopy(selectedOrder.postTrackingCode)}
                        className="text-slate-400 hover:text-slate-700"
                        title="کپی کد رهگیری"
                      >
                        {copiedTracking === selectedOrder.postTrackingCode ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Shipment Tracking Timeline */}
                  <div className="space-y-4">
                    <h5 className="text-xs font-bold text-slate-700">مراحل آماده سازی و ارسال مرسوله اروپایی :</h5>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                      
                      {/* Step 1 */}
                      <div className="p-3 rounded-2xl bg-white border border-slate-200 space-y-1">
                        <div className="flex items-center gap-1.5 text-emerald-600 font-bold">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>۱. تایید و پرداخت</span>
                        </div>
                        <p className="text-[11px] text-slate-500">تراکنش موفق در درگاه شاپرک</p>
                      </div>

                      {/* Step 2 */}
                      <div className="p-3 rounded-2xl bg-white border border-slate-200 space-y-1">
                        <div className="flex items-center gap-1.5 text-emerald-600 font-bold">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>۲. انبار و تست اصالت</span>
                        </div>
                        <p className="text-[11px] text-slate-500">بررسی بچ کد و بسته بندی ضد ضربه</p>
                      </div>

                      {/* Step 3 */}
                      <div className={`p-3 rounded-2xl border space-y-1 ${
                        ['تحویل به پست', 'تحویل داده شده'].includes(selectedOrder.status)
                          ? 'bg-white border-slate-200'
                          : 'bg-slate-100/60 border-slate-200 opacity-60'
                      }`}>
                        <div className="flex items-center gap-1.5 text-emerald-600 font-bold">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>۳. تحویل به تیپاکس / پست</span>
                        </div>
                        <p className="text-[11px] text-slate-500">صدور بارنامه و ارسال پیامک</p>
                      </div>

                      {/* Step 4 */}
                      <div className={`p-3 rounded-2xl border space-y-1 ${
                        selectedOrder.status === 'تحویل داده شده'
                          ? 'bg-white border-slate-200'
                          : 'bg-slate-100/60 border-slate-200 opacity-60'
                      }`}>
                        <div className="flex items-center gap-1.5 text-emerald-600 font-bold">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>۴. تحویل به مشتری</span>
                        </div>
                        <p className="text-[11px] text-slate-500">تحویل با امضا به گیرنده</p>
                      </div>

                    </div>
                  </div>

                  {/* Items in this order */}
                  <div className="pt-2">
                    <h5 className="text-xs font-bold text-slate-700 mb-2">کالاهای موجود در این مرسوله :</h5>
                    <div className="space-y-2">
                      {selectedOrder.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200 text-xs">
                          <div className="flex items-center gap-3">
                            <img src={item.image} alt={item.productName} className="w-10 h-10 object-cover rounded-lg border border-slate-100" />
                            <div>
                              <div className="font-bold text-slate-900">{item.productName}</div>
                              <div className="text-[11px] text-slate-400">تعداد : {item.quantity} عدد با ضمانت اصالت</div>
                            </div>
                          </div>
                          <span className="font-black text-rose-600">{formatPrice(item.price * item.quantity)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

            </div>
          )}

          {/* TAB 2: SMS & EMAIL NOTIFICATION LOGS */}
          {activeTab === 'sms' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 leading-relaxed font-normal">
                <strong className="block font-bold mb-1">سیستم خودکار پیامک و ایمیل گلی کالا :</strong>
                به منظور ارتقای امنیت و آرامش خاطر خریداران عزیز ، تمامی مراحل از ثبت سفارش تا تحویل در انبار و صدور کد رهگیری پستی به صورت لحظه ای به شماره {userPhone} و ایمیل {userEmail} ارسال می گردد.
              </div>

              <h4 className="text-xs font-bold text-slate-800">تاریخچه پیامک های ارسالی به این شماره :</h4>

              <div className="space-y-3">
                {orders.flatMap(o => o.smsAlertsSent).map((sms, index) => (
                  <div key={index} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1 text-slate-700 font-bold">
                        <Smartphone className="w-3.5 h-3.5 text-rose-600" />
                        <span>سرشماره رسمی پیامکی گلی کالا (10009100)</span>
                      </span>
                      <span>{sms.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-800 leading-relaxed font-sans bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      « {sms.message} »
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PROFILE & ADDRESSES */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="space-y-4 max-w-xl">
              <h4 className="text-xs font-bold text-slate-800">ویرایش اطلاعات کاربری و گیرنده مرسولات :</h4>

              {profileSaved && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>اطلاعات پروفایل شما با موفقیت ذخیره گردید.</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">نام کامل :</label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">شماره موبایل :</label>
                  <input
                    type="text"
                    value={userPhone}
                    onChange={(e) => setUserPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 dir-ltr text-left"
                  />
                </div>
              </div>

              <div className="text-xs">
                <label className="block font-bold text-slate-700 mb-1">آدرس ایمیل :</label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 dir-ltr text-left"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                ذخیره تغییرات مشخصات
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
