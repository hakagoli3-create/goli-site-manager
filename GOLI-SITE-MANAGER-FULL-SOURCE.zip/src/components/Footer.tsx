import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Truck, 
  Headphones, 
  RotateCcw, 
  Sparkles, 
  Award, 
  PhoneCall, 
  Mail, 
  MapPin, 
  Send,
  CheckCircle2,
  FileCheck2,
  Code2
} from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
  onOpenAuthenticity: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenAuthenticity,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribed(true);
    setNewsletterEmail('');
    setTimeout(() => setSubscribed(false), 3000);
  };

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800 text-right">
      
      {/* 4 Feature Pillars */}
      <div className="border-b border-slate-800 py-8 bg-slate-900/60">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6">
          
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white">ضمانت ۱۰۰٪ اصالت اروپایی</div>
              <div className="text-[11px] text-slate-400 mt-0.5">واردات رسمی با بچ کد فعال</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white">ارسال سریع تیپاکس و پست</div>
              <div className="text-[11px] text-slate-400 mt-0.5">رهگیری لحظه ای با پیامک هوشمند</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white">۷ روز ضمانت بازگشت وجه</div>
              <div className="text-[11px] text-slate-400 mt-0.5">در صورت هرگونه عدم اصالت کالا</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white">مشاوره تخصصی پوست و مو</div>
              <div className="text-[11px] text-slate-400 mt-0.5">پاسخگویی سریع توسط کارشناسان</div>
            </div>
          </div>

        </div>
      </div>

      {/* Main Footer Links & Info */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {/* Brand Col */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl font-black text-white">گلی کالا (golikala.com)</span>
                <span className="text-xs text-rose-400 block font-medium">
                  نماینده رسمی برندهای آمالفی ، آگرادو و سایرو
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed font-normal">
              فروشگاه اینترنتی گلی کالا به عنوان تنها واردکننده مستقیم و رسمی برندهای نامدار اسپانیا و اروپا شامل آمالفی (Amalfi) ، آگرادو (Agrado) و سایرو (Syro) در ایران فعالیت می نماید. هدف ما کوتاه کردن دست واسطه ها و ارائه محصولات بهداشتی و آرایشی صد در صد اورجینال با استعلام بچ کد و قیمت مصوب بازرگانی می باشد.
            </p>

            <div className="pt-2 flex flex-wrap gap-2 text-xs">
              <button
                onClick={onOpenAuthenticity}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/80 text-emerald-300 border border-emerald-800 text-[11px] font-bold hover:bg-emerald-900 transition-colors cursor-pointer"
              >
                <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>سامانه استعلام آنلاین اصالت</span>
              </button>

              <button
                onClick={() => onNavigate('toolkit')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] font-bold transition-colors cursor-pointer"
              >
                <Code2 className="w-3.5 h-3.5 text-rose-400" />
                <span>جعبه ابزار المنتور گلی کالا</span>
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3 text-xs">
            <h4 className="text-sm font-bold text-white mb-2">دسترسی سریع :</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-rose-400 transition-colors">
                  صفحه اصلی
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop')} className="hover:text-rose-400 transition-colors">
                  فروشگاه و همه محصولات
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('brand-agrado')} className="hover:text-rose-400 transition-colors">
                  محصولات کراتین آگرادو
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('brand-amalfi')} className="hover:text-rose-400 transition-colors">
                  محصولات لوسیون آمالفی
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('brand-syro')} className="hover:text-rose-400 transition-colors">
                  میسلار واتر های سایرو
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('blog')} className="hover:text-rose-400 transition-colors">
                  وبلاگ تخصصی و مقالات
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Col */}
          <div className="lg:col-span-3 space-y-3 text-xs">
            <h4 className="text-sm font-bold text-white mb-2">تماس با نمایندگی مرکزی :</h4>
            <div className="space-y-2.5 text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <span>تهران ، منطقه ۵ ، بلوار جنت آباد جنوبی ، انبار و دفتر مرکزی بازرگانی گلی کالا</span>
              </div>
              <div className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="font-mono">۰۲۱ - ۹۱۰۰۲۴۰۰ | ۰۹۱۲۳۴۵۶۷۸۹</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="font-mono">kamran0goli@gmail.com</span>
              </div>
              <div className="text-[11px] text-slate-500 pt-1">
                ساعات پاسخگویی : شنبه تا پنجشنبه ۹:۰۰ الی ۲۰:۰۰
              </div>
            </div>
          </div>

          {/* Trust Certificates / Simulated e-Namad */}
          <div className="lg:col-span-2 space-y-3 text-center sm:text-right">
            <h4 className="text-sm font-bold text-white mb-2">مجوزهای رسمی :</h4>
            <div className="flex gap-2">
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center flex-1">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-1">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-slate-200">اینماد ۵ ستاره</span>
                <span className="text-[9px] text-slate-500">تجارت الکترونیکی</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center flex-1">
                <div className="w-8 h-8 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mb-1">
                  <Award className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-slate-200">سرتیفیکیت EU</span>
                <span className="text-[9px] text-slate-500">اصالت واردات</span>
              </div>
            </div>

            {/* Newsletter */}
            <form onSubmit={handleSubscribe} className="pt-2 space-y-1.5">
              <span className="text-[11px] text-slate-400 block">اطلاع از تخفیف های دوره ای :</span>
              <div className="flex">
                <input
                  type="email"
                  required
                  placeholder="ایمیل شما..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded-r-xl text-xs text-white outline-hidden focus:border-rose-500"
                />
                <button
                  type="submit"
                  className="px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-l-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
              {subscribed && (
                <div className="text-[10px] text-emerald-400 font-bold">ایمیل شما با موفقیت ثبت شد !</div>
              )}
            </form>

          </div>

        </div>

        {/* Bottom Copyright */}
        <div className="mt-12 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <div>
            تمامی حقوق مادی و معنوی این وب سایت متعلق به <strong>فروشگاه اینترنتی گلی کالا (golikala.com)</strong> و نماینده رسمی برندهای آمالفی ، آگرادو و سایرو در ایران می باشد.
          </div>
          <div className="flex items-center gap-1 text-slate-400 font-mono">
            <span>نسخه بهینه سازی شده ۲۰۲۶ | سئو رنک مث ۱۰۰٪</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
