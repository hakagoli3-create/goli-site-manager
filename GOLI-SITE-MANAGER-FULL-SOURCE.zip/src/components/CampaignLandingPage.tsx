import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  Flame, 
  Award, 
  ArrowLeft, 
  ShoppingBag, 
  CheckCircle2, 
  Star, 
  Gift, 
  Truck,
  Check
} from 'lucide-react';
import { Product } from '../types';

interface CampaignLandingPageProps {
  products: Product[];
  onAddToCart: (p: Product) => void;
  onQuickView: (p: Product) => void;
}

export const CampaignLandingPage: React.FC<CampaignLandingPageProps> = ({
  products,
  onAddToCart,
  onQuickView,
}) => {
  const [activeCampaign, setActiveCampaign] = useState<'agrado' | 'amalfi' | 'syro'>('agrado');

  // Real-time Countdown Timer (2 days, 14 hours, 28 mins, 40 secs)
  const [timeLeft, setTimeLeft] = useState({
    days: 2,
    hours: 14,
    minutes: 32,
    seconds: 48,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const campaignProducts = products.filter(p => {
    if (activeCampaign === 'agrado') return p.brand === 'آگرادو';
    if (activeCampaign === 'amalfi') return p.brand === 'آمالفی';
    return p.brand === 'سایرو';
  });

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="py-8 bg-slate-900 text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 space-y-10">
        
        {/* Campaign Switcher Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-3xl bg-slate-800/80 border border-slate-700">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
            <span className="text-xs sm:text-sm font-black text-white">
              جشنواره های فعال فروش ویژه نمایندگی گلی کالا :
            </span>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-bold">
            <button
              onClick={() => setActiveCampaign('agrado')}
              className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
                activeCampaign === 'agrado' 
                  ? 'bg-rose-600 text-white shadow-md' 
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              جشنواره کراتین آگرادو اسپانیا
            </button>

            <button
              onClick={() => setActiveCampaign('amalfi')}
              className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
                activeCampaign === 'amalfi' 
                  ? 'bg-rose-600 text-white shadow-md' 
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              جشنواره آلوئه ورا و آرگان آمالفی
            </button>

            <button
              onClick={() => setActiveCampaign('syro')}
              className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
                activeCampaign === 'syro' 
                  ? 'bg-rose-600 text-white shadow-md' 
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              جشنواره درماتولوژی سایرو اروپا
            </button>
          </div>
        </div>

        {/* HERO SECTION FOR AGRADO CAMPAIGN */}
        {activeCampaign === 'agrado' && (
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-tr from-slate-950 via-slate-900 to-rose-950 border border-rose-800/40 p-6 sm:p-10 text-right">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              <div className="lg:col-span-7 space-y-5">
                <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>بزرگترین لندینگ پیج جشنواره کراتین تراپی آگرادو در ایران</span>
                </div>

                <h1 className="text-2xl sm:text-4xl font-black leading-tight text-white">
                  احیای قطعی موهای دکلره شده با لاین طلایی <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-l from-amber-300 via-rose-300 to-white">
                    کراتین هیدرولیز شده آگرادو (Agrado Spain)
                  </span>
                </h1>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal max-w-xl">
                  تضمین ۱۰۰ درصدی نرمی و ترمیم کوتیکول مو بدون مواد شیمیایی مضر. در این جشنواره با خرید پک کامل شامپو و ماسک کراتین ، یک سرم آرگان اصل آمالفی هدیه بگیرید و از ارسال رایگان تیپاکس بهره‌مند شوید.
                </p>

                {/* Urgency Live Countdown Timer */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/30 inline-block text-center space-y-2">
                  <div className="flex items-center justify-center gap-1.5 text-xs text-amber-400 font-bold">
                    <Clock className="w-4 h-4" />
                    <span>مهلت استفاده از تخفیف جشنواره نمایندگی :</span>
                  </div>

                  <div className="flex items-center justify-center gap-3 text-slate-900">
                    <div className="bg-amber-400 px-3 py-1.5 rounded-xl text-center">
                      <span className="text-base sm:text-lg font-black block font-mono">
                        {timeLeft.days.toLocaleString('fa-IR')}
                      </span>
                      <span className="text-[10px] font-bold">روز</span>
                    </div>
                    <span className="text-white font-black">:</span>
                    <div className="bg-amber-400 px-3 py-1.5 rounded-xl text-center">
                      <span className="text-base sm:text-lg font-black block font-mono">
                        {timeLeft.hours.toLocaleString('fa-IR')}
                      </span>
                      <span className="text-[10px] font-bold">ساعت</span>
                    </div>
                    <span className="text-white font-black">:</span>
                    <div className="bg-amber-400 px-3 py-1.5 rounded-xl text-center">
                      <span className="text-base sm:text-lg font-black block font-mono">
                        {timeLeft.minutes.toLocaleString('fa-IR')}
                      </span>
                      <span className="text-[10px] font-bold">دقیقه</span>
                    </div>
                    <span className="text-white font-black">:</span>
                    <div className="bg-amber-400 px-3 py-1.5 rounded-xl text-center">
                      <span className="text-base sm:text-lg font-black block font-mono">
                        {timeLeft.seconds.toLocaleString('fa-IR')}
                      </span>
                      <span className="text-[10px] font-bold">ثانیه</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 pt-2">
                  <div className="flex items-center gap-1.5 text-xs text-slate-300">
                    <Gift className="w-4 h-4 text-rose-400" />
                    <span>همراه با اشانتیون اختصاصی نمایندگی</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-300">
                    <Truck className="w-4 h-4 text-emerald-400" />
                    <span>ارسال سریع با تیپاکس سراسری</span>
                  </div>
                </div>

              </div>

              {/* Visual Banner Media */}
              <div className="lg:col-span-5 relative">
                <div className="relative aspect-4/3 rounded-3xl overflow-hidden border-2 border-rose-500/40 shadow-2xl">
                  <img
                    src="https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=800&q=80"
                    alt="Agrado Campaign"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                  <div className="absolute bottom-4 right-4 text-white text-right">
                    <span className="bg-rose-600 text-white text-[11px] font-black px-2.5 py-1 rounded-md mb-1 inline-block">
                      تست آزمایشگاهی والنسیا اسپانیا
                    </span>
                    <div className="text-sm font-black">۸۵٪ احیای تارهای کشسان مو در هفته اول</div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* HERO SECTION FOR AMALFI CAMPAIGN */}
        {activeCampaign === 'amalfi' && (
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-tr from-slate-950 via-slate-900 to-emerald-950 border border-emerald-800/40 p-6 sm:p-10 text-right">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-4">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40">
                  <Award className="w-4 h-4" />
                  <span>جشنواره ویژه رایحه های ارگانیک مدیترانه ای آمالفی</span>
                </span>
                <h2 className="text-2xl sm:text-4xl font-black text-white">
                  لوسیون ها و شامپو بدن های کرمی آمالفی (Amalfi)
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal max-w-xl">
                  پوست های خشک و اگزمایی نیازمند آبرسانی عمیق با ژل خالص آلوئه ورا هستند. آمالفی با فرمول های غیر چرب و جذب سریع زیر ۳۰ ثانیه ، شادابی و طراوت ۲۴ ساعته را به بدن شما بازمی‌گرداند.
                </p>
                <div className="text-xs text-amber-300 font-bold bg-slate-900/80 p-3 rounded-xl border border-slate-700">
                  پیشنهاد نمایندگی : ۲۰٪ تخفیف ویژه خرید ترکیبی لوسیون بدن + ژل حمام نارگیل آمالفی
                </div>
              </div>
              <div className="lg:col-span-5">
                <div className="aspect-4/3 rounded-3xl overflow-hidden border border-emerald-500/30">
                  <img
                    src="https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80"
                    alt="Amalfi"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* HERO SECTION FOR SYRO CAMPAIGN */}
        {activeCampaign === 'syro' && (
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-tr from-slate-950 via-slate-900 to-sky-950 border border-sky-800/40 p-6 sm:p-10 text-right">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-4">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-bold border border-sky-500/40">
                  <ShieldCheck className="w-4 h-4" />
                  <span>تخصصی ترین لاین پاکسازی پوست های به شدت حساس</span>
                </span>
                <h2 className="text-2xl sm:text-4xl font-black text-white">
                  میسلار واتر و شوینده های درماتولوژی سایرو (Syro)
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal max-w-xl">
                  بدون سوزش چشم ، بدون الکل و بدون خشکی پوست بعد از شستشو. با فناوری میسل های هوشمند حتی آرایش های ضد آب ۲۴ ساعته را به ملایمت محو کنید.
                </p>
                <div className="text-xs text-sky-300 font-bold bg-slate-900/80 p-3 rounded-xl border border-slate-700">
                  تضمین بالینی : تایید شده توسط انجمن متخصصان درماتولوژی اتحادیه اروپا
                </div>
              </div>
              <div className="lg:col-span-5">
                <div className="aspect-4/3 rounded-3xl overflow-hidden border border-sky-500/30">
                  <img
                    src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80"
                    alt="Syro"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Products in This Campaign */}
        <div className="space-y-6 text-right">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-lg font-black text-white">
              محصولات مشمول تخفیف جشنواره ویژه {activeCampaign === 'agrado' ? 'آگرادو' : activeCampaign === 'amalfi' ? 'آمالفی' : 'سایرو'}
            </h3>
            <span className="text-xs text-amber-400 font-bold">
              تعداد کالاهای جشنواره : {campaignProducts.length} محصول
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {campaignProducts.map(p => (
              <div
                key={p.id}
                className="bg-slate-800/90 rounded-3xl border border-slate-700/80 p-5 flex flex-col justify-between hover:border-rose-400 transition-all shadow-lg"
              >
                <div>
                  <div className="aspect-square rounded-2xl overflow-hidden mb-4 relative">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                    {p.discountPercent && (
                      <span className="absolute top-3 right-3 bg-rose-600 text-white text-xs font-black px-2.5 py-1 rounded-full shadow-md">
                        {p.discountPercent.toLocaleString('fa-IR')}٪ تخفیف جشنواره
                      </span>
                    )}
                  </div>

                  <span className="text-[11px] text-rose-400 font-bold block mb-1">
                    {p.brand} ({p.originCountry})
                  </span>
                  <h4 className="text-xs sm:text-sm font-black text-white line-clamp-2 leading-snug">
                    {p.name}
                  </h4>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-700 flex items-center justify-between">
                  <div className="text-right">
                    {p.oldPrice && (
                      <span className="text-[11px] text-slate-400 line-through block">
                        {p.oldPrice.toLocaleString('fa-IR')}
                      </span>
                    )}
                    <span className="text-sm font-black text-amber-400">
                      {formatPrice(p.price)}
                    </span>
                  </div>

                  <button
                    onClick={() => onAddToCart(p)}
                    className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>خرید با تخفیف</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
