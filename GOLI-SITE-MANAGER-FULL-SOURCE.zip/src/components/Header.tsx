import React, { useState } from 'react';
import { 
  Search, 
  ShoppingBag, 
  User, 
  ShieldCheck, 
  Truck, 
  Sparkles, 
  Menu, 
  X, 
  PhoneCall, 
  Code2, 
  CheckCircle2,
  FileCheck2,
  ChevronDown,
  ArrowLeftRight,
  Flame,
  Layout
} from 'lucide-react';
import { Product } from '../types';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  cartCount: number;
  compareCount?: number;
  openCompareModal?: () => void;
  openCart: () => void;
  openUserDashboard: () => void;
  openAuthenticityModal: () => void;
  allProducts: Product[];
  onSelectProduct: (p: Product) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  cartCount,
  compareCount = 0,
  openCompareModal,
  openCart,
  openUserDashboard,
  openAuthenticityModal,
  allProducts,
  onSelectProduct,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);

  const filteredSearch = searchQuery.trim() === '' 
    ? [] 
    : allProducts.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.originalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5);

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Announcement Bar */}
      <div className="bg-gradient-to-r from-rose-700 via-rose-600 to-amber-600 text-white text-xs py-2 px-4 font-medium">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" />
            <span>
              نماینده رسمی و واردات مستقیم برندهای اروپایی <strong>آمالفی (Amalfi)</strong> ، <strong>آگرادو (Agrado)</strong> و <strong>سایرو (Syro)</strong> در ایران | ضمانت کتبی اصالت کالا
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px] hidden sm:flex">
            <span className="flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-amber-300" />
              ارسال سریع اکسپرس به سراسر کشور
            </span>
            <span className="flex items-center gap-1">
              <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
              پشتیبانی : ۰۲۱-۹۱۰۰۲۴۰۰
            </span>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4">
        <div className="flex items-center justify-between gap-4">
          
          {/* Right: Mobile Menu Toggle & Logo */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-700 hover:text-rose-600 rounded-lg focus:outline-hidden"
              aria-label="منوی سایت"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <button 
              onClick={() => setCurrentTab('home')}
              className="flex items-center gap-3 text-right group focus:outline-hidden"
            >
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-rose-200 group-hover:scale-105 transition-transform">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 group-hover:text-rose-600 transition-colors">
                  گلی کالا
                </div>
                <div className="text-[10px] sm:text-xs text-slate-500 font-medium">
                  GoliKala | فروشگاه تخصصی محصولات اروپایی
                </div>
              </div>
            </button>
          </div>

          {/* Center: Live Search Bar */}
          <div className="relative flex-1 max-w-xl mx-2 hidden md:block">
            <div className="relative">
              <input
                type="text"
                placeholder="جستجو در محصولات آمالفی ، آگرادو ، سایرو و محصولات اورجینال..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSearchResults(true);
                }}
                onFocus={() => setShowSearchResults(true)}
                className="w-full pl-10 pr-11 py-2.5 bg-slate-100 hover:bg-slate-50 focus:bg-white border border-slate-200 focus:border-rose-500 rounded-xl text-sm transition-all outline-hidden text-slate-800 placeholder:text-slate-400"
              />
              <Search className="absolute right-3.5 top-3 w-4 h-4 text-slate-400" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 bg-slate-200 rounded-full w-5 h-5 flex items-center justify-center"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Live Search Popup */}
            {showSearchResults && filteredSearch.length > 0 && (
              <div 
                className="absolute top-full mt-2 w-full bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 divide-y divide-slate-100"
                onMouseLeave={() => setShowSearchResults(false)}
              >
                <div className="text-[11px] font-bold text-slate-400 px-3 py-1.5 flex items-center justify-between">
                  <span>محصولات پیشنهادی گلی کالا</span>
                  <span className="text-rose-600">تضمین اصالت</span>
                </div>
                {filteredSearch.map(product => (
                  <button
                    key={product.id}
                    onClick={() => {
                      onSelectProduct(product);
                      setShowSearchResults(false);
                      setSearchQuery('');
                    }}
                    className="w-full flex items-center gap-3 p-2.5 hover:bg-rose-50/60 rounded-xl text-right transition-colors"
                  >
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-12 h-12 object-cover rounded-lg border border-slate-100 shrink-0" 
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-slate-900 truncate">{product.name}</div>
                      <div className="text-[11px] text-rose-600 font-medium">{product.brand} - {product.originCountry}</div>
                    </div>
                    <div className="text-xs font-bold text-slate-800 shrink-0">
                      {formatPrice(product.price)}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Left: Actions (User Dashboard, Authenticity Check, Cart) */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Authenticity Verification button */}
            <button
              onClick={openAuthenticityModal}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-xl text-xs font-bold transition-colors"
              title="استعلام بچ کد و اصالت رسمی کالا"
            >
              <FileCheck2 className="w-4 h-4 text-emerald-600" />
              <span>استعلام اصالت</span>
            </button>

            {/* Compare Button */}
            {openCompareModal && (
              <button
                onClick={openCompareModal}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 border border-slate-200 rounded-xl text-xs font-bold transition-all"
                title="مقایسه محصولات"
              >
                <ArrowLeftRight className="w-4 h-4 text-rose-600" />
                <span className="hidden xl:inline">مقایسه</span>
                {compareCount > 0 && (
                  <span className="bg-rose-600 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full">
                    {compareCount.toLocaleString('fa-IR')}
                  </span>
                )}
              </button>
            )}

            {/* User Account / Orders Button */}
            <button
              onClick={openUserDashboard}
              className="flex items-center gap-2 px-3 py-2 text-slate-700 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 border border-slate-200 rounded-xl text-xs font-bold transition-all"
            >
              <User className="w-4 h-4 text-rose-600" />
              <div className="text-right hidden sm:block">
                <span className="text-[11px] text-slate-500 block font-normal">پنل کاربری</span>
                <span className="text-xs font-bold text-slate-800">کامران گلی</span>
              </div>
            </button>

            {/* Cart Drawer Trigger */}
            <button
              onClick={openCart}
              className="relative flex items-center gap-2 px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-md shadow-rose-200 transition-all hover:scale-102"
              aria-label="سبد خرید"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">سبد خرید</span>
              {cartCount > 0 && (
                <span className="bg-amber-400 text-slate-900 text-[10px] font-black px-1.5 py-0.5 rounded-full shrink-0">
                  {cartCount.toLocaleString('fa-IR')}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-3 md:hidden">
          <div className="relative">
            <input
              type="text"
              placeholder="جستجو در محصولات آمالفی ، آگرادو ، سایرو..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-10 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs outline-hidden"
            />
            <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
          </div>
          {searchQuery && filteredSearch.length > 0 && (
            <div className="mt-1 bg-white rounded-xl shadow-lg border border-slate-200 p-2 divide-y divide-slate-100">
              {filteredSearch.map(product => (
                <button
                  key={product.id}
                  onClick={() => {
                    onSelectProduct(product);
                    setSearchQuery('');
                  }}
                  className="w-full flex items-center gap-2 p-2 text-right text-xs hover:bg-slate-50"
                >
                  <img src={product.image} alt={product.name} className="w-8 h-8 rounded-md object-cover" />
                  <span className="flex-1 truncate font-medium text-slate-800">{product.name}</span>
                  <span className="text-rose-600 font-bold">{formatPrice(product.price)}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Sub Navigation Bar */}
      <nav className="border-t border-slate-100 bg-slate-50/70 hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between text-xs font-semibold text-slate-700">
          <div className="flex items-center gap-1 py-1.5">
            <button
              onClick={() => setCurrentTab('home')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                currentTab === 'home' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white'
              }`}
            >
              صفحه اصلی
            </button>

            <button
              onClick={() => setCurrentTab('shop')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                currentTab === 'shop' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white'
              }`}
            >
              فروشگاه و همه محصولات
            </button>

            <button
              onClick={() => setCurrentTab('brand-amalfi')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 ${
                currentTab === 'brand-amalfi' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white'
              }`}
            >
              <span>برند آمالفی (Amalfi)</span>
              <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">نمایندگی</span>
            </button>

            <button
              onClick={() => setCurrentTab('brand-agrado')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 ${
                currentTab === 'brand-agrado' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white'
              }`}
            >
              <span>برند آگرادو (Agrado)</span>
              <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">نمایندگی</span>
            </button>

            <button
              onClick={() => setCurrentTab('brand-syro')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 ${
                currentTab === 'brand-syro' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white'
              }`}
            >
              <span>برند سایرو (Syro)</span>
              <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">نمایندگی</span>
            </button>

            <button
              onClick={() => setCurrentTab('campaigns')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 ${
                currentTab === 'campaigns' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white text-slate-700'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-500" />
              <span>جشنواره ها و لندینگ پیج</span>
              <span className="bg-rose-100 text-rose-700 text-[10px] px-1.5 py-0.2 rounded-full font-bold">ویژه</span>
            </button>

            <button
              onClick={() => setCurrentTab('blog')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                currentTab === 'blog' 
                  ? 'bg-rose-600 text-white font-bold' 
                  : 'hover:text-rose-600 hover:bg-white'
              }`}
            >
              وبلاگ تخصصی و مقالات سئو
            </button>

            <button
              onClick={openAuthenticityModal}
              className="px-3 py-1.5 rounded-lg hover:text-emerald-700 hover:bg-emerald-50 text-emerald-800 transition-colors flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>استعلام بچ کد و اصالت</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Visual Elementor Studio */}
            <button
              onClick={() => setCurrentTab('studio')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentTab === 'studio'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>استودیوی بازطراحی المنتور</span>
            </button>

            {/* WordPress & Elementor Code Toolkit button for golikala.com */}
            <button
              onClick={() => setCurrentTab('toolkit')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentTab === 'toolkit'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-200/80 hover:bg-slate-300 text-slate-800'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-rose-500" />
              <span>جعبه ابزار کدهای سئو</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white p-4 space-y-2">
          <button
            onClick={() => { setCurrentTab('home'); setMobileMenuOpen(false); }}
            className={`w-full text-right p-2.5 rounded-xl text-sm font-bold ${currentTab === 'home' ? 'bg-rose-600 text-white' : 'text-slate-800 hover:bg-slate-100'}`}
          >
            صفحه اصلی
          </button>
          <button
            onClick={() => { setCurrentTab('shop'); setMobileMenuOpen(false); }}
            className={`w-full text-right p-2.5 rounded-xl text-sm font-bold ${currentTab === 'shop' ? 'bg-rose-600 text-white' : 'text-slate-800 hover:bg-slate-100'}`}
          >
            فروشگاه و همه محصولات
          </button>
          <button
            onClick={() => { setCurrentTab('brand-agrado'); setMobileMenuOpen(false); }}
            className="w-full text-right p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>محصولات برند آگرادو (Agrado)</span>
            <span className="text-[10px] bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-bold">اسپانیا</span>
          </button>
          <button
            onClick={() => { setCurrentTab('brand-amalfi'); setMobileMenuOpen(false); }}
            className="w-full text-right p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>محصولات برند آمالفی (Amalfi)</span>
            <span className="text-[10px] bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-bold">اسپانیا</span>
          </button>
          <button
            onClick={() => { setCurrentTab('brand-syro'); setMobileMenuOpen(false); }}
            className="w-full text-right p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>محصولات برند سایرو (Syro)</span>
            <span className="text-[10px] bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-bold">اروپا</span>
          </button>
          <button
            onClick={() => { setCurrentTab('blog'); setMobileMenuOpen(false); }}
            className="w-full text-right p-2.5 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-100"
          >
            وبلاگ تخصصی و مقالات سئو شده
          </button>
          <button
            onClick={() => { openAuthenticityModal(); setMobileMenuOpen(false); }}
            className="w-full text-right p-2.5 rounded-xl text-sm font-bold text-emerald-700 bg-emerald-50 flex items-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>سامانه استعلام اصالت و بچ کد اروپایی</span>
          </button>
          <button
            onClick={() => { setCurrentTab('toolkit'); setMobileMenuOpen(false); }}
            className="w-full text-right p-2.5 rounded-xl text-sm font-bold text-slate-800 bg-amber-50 border border-amber-200 flex items-center gap-2"
          >
            <Code2 className="w-4 h-4 text-amber-600" />
            <span>جعبه ابزار کدهای المنتور و سئو گلی کالا</span>
          </button>
        </div>
      )}
    </header>
  );
};
