import React, { useState } from 'react';
import { 
  BookOpen, 
  Clock, 
  Calendar, 
  User, 
  Tag, 
  ArrowLeft, 
  ShieldCheck, 
  Sparkles, 
  Award,
  Link2,
  Table,
  CheckCircle2,
  X
} from 'lucide-react';
import { BlogPost, Product } from '../types';

interface BlogSectionProps {
  posts: BlogPost[];
  allProducts: Product[];
  onSelectProduct: (p: Product) => void;
}

export const BlogSection: React.FC<BlogSectionProps> = ({
  posts,
  allProducts,
  onSelectProduct,
}) => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  const getRelatedProducts = (ids: string[]) => {
    return allProducts.filter(p => ids.includes(p.id));
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <section className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 text-right">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-700 rounded-full text-xs font-bold border border-rose-200 mb-2">
              <BookOpen className="w-3.5 h-3.5" />
              <span>پایگاه دانش و سئو تخصصی گلی کالا</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              وبلاگ تخصصی برندهای اروپایی آمالفی ، آگرادو و سایرو
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">
              جدیدترین مقالات تحلیلی ، راهنمای تخصصی مراقبت پوست و مو و روش های تایید اصالت کالا
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto text-xs text-emerald-700 font-bold bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>مطابق با آخرین بروزرسانی قوانین سئو گوگل ۲۰۲۶</span>
          </div>
        </div>

        {/* Blog Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {posts.map((post) => {
            const related = getRelatedProducts(post.relatedProductIds);
            return (
              <article
                key={post.id}
                onClick={() => setSelectedPost(post)}
                className="group bg-slate-50 hover:bg-white rounded-3xl border border-slate-200/90 hover:border-rose-400 p-5 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer text-right"
              >
                <div>
                  {/* Cover Image */}
                  <div className="relative h-52 rounded-2xl overflow-hidden mb-4">
                    <img
                      src={post.coverImage}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-xs text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-xs flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5 text-amber-400" />
                      <span>{post.brandFocus}</span>
                    </div>

                    <div className="absolute bottom-3 left-3 bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs">
                      سئو رنک مث : {post.seoRankMathScore} / ۱۰۰
                    </div>
                  </div>

                  {/* Meta info */}
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mb-2">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {post.publishDate}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {post.readTime}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-slate-500">
                      <User className="w-3.5 h-3.5" />
                      {post.author}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm sm:text-base font-black text-slate-900 group-hover:text-rose-600 transition-colors leading-snug mb-2">
                    {post.title}
                  </h3>

                  {/* Summary */}
                  <p className="text-xs text-slate-600 leading-relaxed font-normal line-clamp-3">
                    {post.summary}
                  </p>
                </div>

                {/* Footer with Internal Link Badge & CTA */}
                <div className="pt-4 mt-4 border-t border-slate-200/70 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[11px] text-rose-600 font-bold">
                    <Link2 className="w-3.5 h-3.5" />
                    <span>لینک به {related.length} محصول اصل در متن</span>
                  </div>

                  <span className="flex items-center gap-1 text-xs font-bold text-slate-800 group-hover:text-rose-600 transition-colors">
                    <span>مطالعه مقاله کامل</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </span>
                </div>
              </article>
            );
          })}
        </div>

      </div>

      {/* Single Blog Post Reading Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div 
            className="relative bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
              <div className="flex items-center gap-2">
                <span className="bg-rose-100 text-rose-700 text-xs font-bold px-2.5 py-1 rounded-lg">
                  مقاله تخصصی گلی کالا
                </span>
                <span className="text-xs text-slate-500">{selectedPost.readTime}</span>
              </div>
              <button
                onClick={() => setSelectedPost(null)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
              
              {/* Header Title */}
              <div>
                <h1 className="text-lg sm:text-2xl font-black text-slate-900 leading-snug">
                  {selectedPost.title}
                </h1>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-2">
                  <span>منتشر شده در : {selectedPost.publishDate}</span>
                  <span>•</span>
                  <span>نویسنده : {selectedPost.author}</span>
                  <span>•</span>
                  <span className="text-emerald-700 font-bold">امتیاز سئو رنک مث : ۹۹/۱۰۰</span>
                </div>
              </div>

              {/* Cover Banner */}
              <div className="h-64 rounded-2xl overflow-hidden border border-slate-200">
                <img src={selectedPost.coverImage} alt={selectedPost.title} className="w-full h-full object-cover" />
              </div>

              {/* Body Text */}
              <div className="prose text-xs sm:text-sm text-slate-700 leading-relaxed space-y-4 whitespace-pre-line font-normal">
                {selectedPost.content}
              </div>

              {/* Attractive Comparison Table */}
              {selectedPost.tableData && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                    <Table className="w-4 h-4 text-rose-600" />
                    <span>جدول مقایسه تخصصی و کاربردی :</span>
                  </div>
                  <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-100/80 border-b border-slate-200 text-slate-800 font-bold">
                        <tr>
                          {selectedPost.tableData.headers.map((h, i) => (
                            <th key={i} className="py-2.5 px-3 font-black text-slate-900">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedPost.tableData.rows.map((row, rIdx) => (
                          <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                            {row.map((cell, cIdx) => (
                              <td key={cIdx} className="py-2.5 px-3 text-slate-700 font-medium">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Related Products / Internal Linking Box */}
              <div className="p-4 rounded-2xl bg-rose-50/60 border border-rose-200 space-y-3">
                <div className="flex items-center gap-2 text-xs font-black text-rose-950">
                  <Sparkles className="w-4 h-4 text-rose-600" />
                  <span>محصولات معرفی شده در این مقاله با ضمانت اصالت گلی کالا :</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {getRelatedProducts(selectedPost.relatedProductIds).map(prod => (
                    <div
                      key={prod.id}
                      onClick={() => {
                        setSelectedPost(null);
                        onSelectProduct(prod);
                      }}
                      className="flex items-center gap-3 p-2.5 bg-white rounded-xl border border-rose-200 hover:border-rose-400 cursor-pointer shadow-2xs transition-all"
                    >
                      <img src={prod.image} alt={prod.name} className="w-12 h-12 object-cover rounded-lg shrink-0" />
                      <div className="flex-1 min-w-0 text-right">
                        <div className="text-xs font-bold text-slate-900 truncate">{prod.name}</div>
                        <div className="text-[11px] text-rose-600 font-black">{formatPrice(prod.price)}</div>
                      </div>
                      <span className="text-[10px] bg-rose-50 text-rose-700 font-bold px-2 py-1 rounded-md shrink-0">
                        خرید اصل
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Targeted Keywords / Tags */}
              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                  <Tag className="w-3.5 h-3.5" />
                  <span>کلمات کلیدی سئو هدفمند :</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedPost.keywords.map((kw, i) => (
                    <span key={i} className="text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg font-medium">
                      #{kw}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </section>
  );
};
