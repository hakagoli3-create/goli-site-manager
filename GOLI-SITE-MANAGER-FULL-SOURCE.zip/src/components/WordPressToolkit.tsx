import React, { useState } from 'react';
import { 
  Code2, 
  Copy, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Zap, 
  Search, 
  FileCode, 
  CheckCircle2, 
  ExternalLink,
  Layers
} from 'lucide-react';
import { ELEMENTOR_WORDPRESS_SNIPPETS } from '../data/mockData';

export const WordPressToolkit: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'css' | 'schema' | 'rankmath' | 'speed'>('css');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const functionsPhpCode = `<?php
/**
 * بهینه سازی اختصاصی سرعت و امنیت سایت گلی کالا (golikala.com)
 * افزودن به انتهای فایل functions.php قالب فعال
 */

// ۱. حذف اسکریپت ها و کدهای اضافی اموجی و embed وردپرس
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_oembed_add_discovery_links');
remove_action('wp_head', 'wp_generator'); // مخفی سازی نسخه وردپرس جهت افزایش امنیت

// ۲. بهینه سازی لود فونت های المنتور و کاهش تاخیر LCP
add_filter('elementor/frontend/print_google_fonts', '__return_false');

// ۳. پشتیبانی از فرمت سبک و پرسرعت WebP برای تصاویر محصولات
add_filter('upload_mimes', function($mimes) {
    $mimes['webp'] = 'image/webp';
    return $mimes;
});

// ۴. غیرفعال سازی دسترسی ناامن XML-RPC
add_filter('xmlrpc_enabled', '__return_false');
`;

  return (
    <div className="py-12 bg-slate-900 text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 text-right">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-500/10 text-rose-300 rounded-full text-xs font-bold border border-rose-500/30 mb-2">
              <Code2 className="w-4 h-4 text-rose-400" />
              <span>جعبه ابزار اختصاصی وردپرس ، المنتور و رنک مث گلی کالا</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              کدهای آماده بازطراحی ، سئو رنک مث و افزایش سرعت برای golikala.com
            </h1>
            <p className="text-slate-400 text-xs sm:text-sm mt-1">
              کدهای استاندارد ، بدون هیچ گونه تداخل یا افت کارایی برای کپی در پیشخوان وردپرس
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto text-xs font-bold text-amber-300 bg-amber-500/10 border border-amber-500/30 px-3.5 py-2 rounded-xl">
            <ShieldCheck className="w-4 h-4" />
            <span>امنیت ۱۰۰٪ تضمین شده بدون هیچ خرابکاری در دیتابیس</span>
          </div>
        </div>

        {/* Toolkit Nav Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-3 mb-6 text-xs sm:text-sm font-bold">
          <button
            onClick={() => setActiveTab('css')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'css' ? 'bg-rose-600 text-white shadow-md' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>کدهای CSS مدرن و مینیمال المنتور</span>
          </button>

          <button
            onClick={() => setActiveTab('rankmath')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'rankmath' ? 'bg-rose-600 text-white shadow-md' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>تنظیمات سئو صفحه اول در رنک مث (Rank Math)</span>
          </button>

          <button
            onClick={() => setActiveTab('schema')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'schema' ? 'bg-rose-600 text-white shadow-md' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>اسکیما رسمی JSON-LD نمایندگی اروپا</span>
          </button>

          <button
            onClick={() => setActiveTab('speed')}
            className={`px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'speed' ? 'bg-rose-600 text-white shadow-md' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>کدهای شتاب دهی سرعت و امنیت (functions.php)</span>
          </button>
        </div>

        {/* Tab 1: Elementor Custom CSS */}
        {activeTab === 'css' && (
          <div className="space-y-4 text-right">
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white">استایل های CSS بهینه سازی کارت ها و ویجت های المنتور</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  این کدها را در بخش <strong>پیشخوان وردپرس › نمایش › سفارشی سازی › CSS اضافی</strong> یا در بخش تنظیمات صفحه المنتور قرار دهید.
                </p>
              </div>
              <button
                onClick={() => handleCopy(ELEMENTOR_WORDPRESS_SNIPPETS.elementorCustomCss, 'css')}
                className="shrink-0 flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                {copiedCode === 'css' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode === 'css' ? 'کپی شد !' : 'کپی کدهای CSS'}</span>
              </button>
            </div>

            <div className="relative rounded-2xl bg-slate-950 border border-slate-800 p-4 text-left dir-ltr overflow-x-auto text-xs font-mono text-emerald-400 leading-relaxed max-h-96">
              <pre>{ELEMENTOR_WORDPRESS_SNIPPETS.elementorCustomCss}</pre>
            </div>
          </div>
        )}

        {/* Tab 2: Rank Math SEO Setup */}
        {activeTab === 'rankmath' && (
          <div className="space-y-6 text-right">
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
              <h3 className="text-sm font-bold text-white mb-1">
                اطلاعات سئو رنک مث برای عنوان و توضیحات صفحه اول گلی کالا (golikala.com)
              </h3>
              <p className="text-xs text-slate-400">
                این مشخصات دقیقا منطبق با آخرین قوانین گوگل ۲۰۲۶ و دستورات شما تنظیم شده است :
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              
              <div className="p-4 rounded-2xl bg-slate-800 border border-slate-700 space-y-2">
                <span className="text-slate-400 block font-bold">عنوان سئو صفحه اول (SEO Title) :</span>
                <div className="p-3 bg-slate-950 rounded-xl text-amber-300 font-bold leading-relaxed">
                  گلی کالا | نماینده رسمی آمالفی ، آگرادو و سایرو - فروشگاه تخصصی محصولات اروپایی
                </div>
                <button
                  onClick={() => handleCopy('گلی کالا | نماینده رسمی آمالفی ، آگرادو و سایرو - فروشگاه تخصصی محصولات اروپایی', 'title')}
                  className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                >
                  {copiedCode === 'title' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'title' ? 'کپی شد' : 'کپی عنوان'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-800 border border-slate-700 space-y-2">
                <span className="text-slate-400 block font-bold">کلمات کلیدی کانونی (Focus Keywords) :</span>
                <div className="p-3 bg-slate-950 rounded-xl text-emerald-400 font-bold leading-relaxed">
                  نماینده رسمی آمالفی ، نماینده رسمی آگرادو ، نماینده رسمی سایرو ، خرید محصولات آگرادو اصل
                </div>
                <button
                  onClick={() => handleCopy('نماینده رسمی آمالفی ، نماینده رسمی آگرادو ، نماینده رسمی سایرو ، خرید محصولات آگرادو اصل', 'kw')}
                  className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                >
                  {copiedCode === 'kw' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'kw' ? 'کپی شد' : 'کپی کلمات کلیدی'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-800 border border-slate-700 space-y-2 md:col-span-2">
                <span className="text-slate-400 block font-bold">توضیحات متا صفحه اول (Meta Description) :</span>
                <div className="p-3 bg-slate-950 rounded-xl text-slate-200 leading-relaxed font-normal">
                  فروشگاه اینترنتی گلی کالا ، نماینده رسمی و مستقیم برندهای برجسته اروپایی آمالفی (Amalfi) ، آگرادو (Agrado) و سایرو (Syro) در ایران با ضمانت قطعی اصالت فیزیکی کالا ، استعلام آنلاین بچ کد آزمایشگاهی ، ارسال سریع با تیپاکس و پشتیبانی ۲۴ ساعته.
                </div>
                <button
                  onClick={() => handleCopy('فروشگاه اینترنتی گلی کالا ، نماینده رسمی و مستقیم برندهای برجسته اروپایی آمالفی (Amalfi) ، آگرادو (Agrado) و سایرو (Syro) در ایران با ضمانت قطعی اصالت فیزیکی کالا ، استعلام آنلاین بچ کد آزمایشگاهی ، ارسال سریع با تیپاکس و پشتیبانی ۲۴ ساعته.', 'desc')}
                  className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                >
                  {copiedCode === 'desc' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'desc' ? 'کپی شد' : 'کپی توضیحات متا'}</span>
                </button>
              </div>

            </div>
          </div>
        )}

        {/* Tab 3: JSON-LD Schema */}
        {activeTab === 'schema' && (
          <div className="space-y-4 text-right">
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white">کد اسکیما ساختار یافته JSON-LD گوگل</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  کپی در بخش Rank Math › Schema Generator › Custom Schema برای نمایش ستاره ها و نام گلی کالا در نتایج گوگل.
                </p>
              </div>
              <button
                onClick={() => handleCopy(ELEMENTOR_WORDPRESS_SNIPPETS.rankMathSchemaJsonLd, 'schema')}
                className="shrink-0 flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                {copiedCode === 'schema' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode === 'schema' ? 'کپی شد !' : 'کپی اسکیما JSON-LD'}</span>
              </button>
            </div>

            <div className="relative rounded-2xl bg-slate-950 border border-slate-800 p-4 text-left dir-ltr overflow-x-auto text-xs font-mono text-cyan-300 leading-relaxed max-h-96">
              <pre>{ELEMENTOR_WORDPRESS_SNIPPETS.rankMathSchemaJsonLd}</pre>
            </div>
          </div>
        )}

        {/* Tab 4: Speed and Functions.php */}
        {activeTab === 'speed' && (
          <div className="space-y-4 text-right">
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white">کدهای تقویت سرعت و حذف فایل های زائد در functions.php</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  حذف اسکریپت های زائد اموجی ، فعال سازی WebP و افزایش چشمگیر نمره سرعت GTmetrix و Google PageSpeed.
                </p>
              </div>
              <button
                onClick={() => handleCopy(functionsPhpCode, 'func')}
                className="shrink-0 flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                {copiedCode === 'func' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode === 'func' ? 'کپی شد !' : 'کپی کدهای PHP'}</span>
              </button>
            </div>

            <div className="relative rounded-2xl bg-slate-950 border border-slate-800 p-4 text-left dir-ltr overflow-x-auto text-xs font-mono text-amber-300 leading-relaxed max-h-96">
              <pre>{functionsPhpCode}</pre>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
