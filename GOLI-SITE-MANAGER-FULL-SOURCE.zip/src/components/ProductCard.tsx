import React, { useState } from 'react';
import { 
  Star, 
  ShoppingBag, 
  Eye, 
  ShieldCheck, 
  Check, 
  Heart, 
  Sparkles,
  QrCode,
  ArrowLeftRight,
  Zap
} from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onCheckBatchCode: (product: Product) => void;
  onAddToCompare?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onQuickView,
  onCheckBatchCode,
  onAddToCompare,
}) => {
  const [isAdded, setIsAdded] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [compareAdded, setCompareAdded] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1500);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div 
      onClick={() => onQuickView(product)}
      className="group relative bg-white rounded-2xl border border-slate-200/90 hover:border-rose-400 p-3 sm:p-4 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer"
    >
      <div>
        {/* Image Container with Badges */}
        <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-50 mb-3">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-106 transition-transform duration-500"
          />

          {/* Badges on top */}
          <div className="absolute top-2 right-2 flex flex-col gap-1 z-10">
            {product.isOfficialAgency && (
              <span className="bg-rose-600/95 backdrop-blur-xs text-white text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-amber-300" />
                <span>نمایندگی رسمی</span>
              </span>
            )}
            {product.discountPercent && product.discountPercent > 0 && (
              <span className="bg-amber-500 text-slate-900 text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs self-start">
                {product.discountPercent.toLocaleString('fa-IR')}٪ تخفیف
              </span>
            )}
          </div>

          {/* Action buttons (Wishlist & Compare) */}
          <div className="absolute top-2 left-2 flex flex-col gap-1.5 z-10">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsLiked(!isLiked);
              }}
              className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                isLiked ? 'bg-rose-50 text-rose-600' : 'bg-white/90 text-slate-400 hover:text-rose-500 hover:bg-white shadow-2xs'
              }`}
              title="علاقه‌مندی"
            >
              <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>

            {onAddToCompare && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToCompare(product);
                  setCompareAdded(true);
                  setTimeout(() => setCompareAdded(false), 2000);
                }}
                className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                  compareAdded ? 'bg-emerald-600 text-white shadow-xs' : 'bg-white/90 text-slate-500 hover:text-rose-600 hover:bg-white shadow-2xs'
                }`}
                title="افزودن به لیست مقایسه"
              >
                {compareAdded ? <Check className="w-3.5 h-3.5" /> : <ArrowLeftRight className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>

          {/* Batch Code Quick Checker Link */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onCheckBatchCode(product);
            }}
            className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900/90 text-white text-[10px] font-bold px-2 py-1 rounded-lg flex items-center gap-1 hover:bg-slate-950"
            title="استعلام بچ کد در سیستم"
          >
            <QrCode className="w-3 h-3 text-amber-400" />
            <span>بچ کد : {product.batchCodeExample}</span>
          </button>
        </div>

        {/* Brand & Origin */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
          <span className="font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
            {product.brand} ({product.brandEn})
          </span>
          <span className="text-slate-400 font-medium">ساخت {product.originCountry}</span>
        </div>

        {/* Product Title */}
        <h3 className="text-xs sm:text-sm font-bold text-slate-800 leading-snug line-clamp-2 min-h-[2.5rem] group-hover:text-rose-600 transition-colors text-right">
          {product.name}
        </h3>

        {/* Smart Complement Recommendation tag */}
        {product.complementaryProductIds && product.complementaryProductIds.length > 0 && (
          <div className="mt-1.5 flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50/80 px-2 py-0.5 rounded-md border border-amber-200/60">
            <Sparkles className="w-3 h-3 text-amber-500 shrink-0" />
            <span className="truncate">پیشنهاد هوشمند : دارای روتین مکمل ست {product.brand}</span>
          </div>
        )}

        {/* Rating & Reviews */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 text-[11px]">
          <div className="flex items-center gap-1 text-amber-500">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="font-bold text-slate-700">{product.rating.toLocaleString('fa-IR')}</span>
            <span className="text-slate-400">({product.reviewsCount.toLocaleString('fa-IR')} نظر)</span>
          </div>

          <div className="text-[10px] text-emerald-600 font-semibold flex items-center gap-0.5">
            <ShieldCheck className="w-3 h-3" />
            <span>ضمانت اصالت</span>
          </div>
        </div>
      </div>

      {/* Price & Action */}
      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
        
        {/* Price column */}
        <div className="text-right">
          {product.oldPrice && (
            <div className="text-[11px] text-slate-400 line-through">
              {product.oldPrice.toLocaleString('fa-IR')}
            </div>
          )}
          <div className="text-xs sm:text-sm font-black text-slate-900">
            {formatPrice(product.price)}
          </div>
        </div>

        {/* Add to Cart button */}
        <button
          onClick={handleAdd}
          className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            isAdded
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 hover:border-rose-600'
          }`}
          title="افزودن به سبد خرید"
        >
          {isAdded ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>اضافه شد</span>
            </>
          ) : (
            <>
              <ShoppingBag className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">خرید</span>
            </>
          )}
        </button>

      </div>
    </div>
  );
};
