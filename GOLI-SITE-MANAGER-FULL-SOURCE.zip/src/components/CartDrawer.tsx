import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowLeft, 
  ShieldCheck, 
  Truck, 
  Tag, 
  Sparkles 
} from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, newQty: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, curr) => acc + (curr.product.price * curr.quantity), 0);
  const discountAmount = discountApplied ? Math.round(subtotal * 0.1) : 0;
  const freeShippingThreshold = 800000;
  const neededForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const shippingFee = subtotal >= freeShippingThreshold || subtotal === 0 ? 0 : 45000;
  const total = subtotal - discountAmount + shippingFee;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim().toUpperCase() === 'GOLI2026' || couponCode.trim().toLowerCase() === 'golikala') {
      setDiscountApplied(true);
    } else {
      alert('کد تخفیف معتبر نیست. از کد هدیه GOLI2026 استفاده فرمایید.');
    }
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex justify-end">
      <div 
        className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl text-right animate-in slide-in-from-left duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-rose-600" />
            <h3 className="text-sm sm:text-base font-black text-slate-900">
              سبد خرید شما ({items.length.toLocaleString('fa-IR')} قلم)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress */}
        <div className="px-5 py-3 bg-rose-50/60 border-b border-rose-100 text-xs">
          {neededForFreeShipping > 0 ? (
            <div>
              <div className="flex items-center justify-between text-slate-700 font-bold mb-1.5">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-rose-600" />
                  <span>ارسال رایگان تیپاکس به سراسر کشور</span>
                </span>
                <span className="text-rose-600 font-black">
                  {formatPrice(neededForFreeShipping)} دیگر
                </span>
              </div>
              <div className="w-full h-1.5 bg-rose-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-rose-600 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
              <Truck className="w-4 h-4 text-emerald-600" />
              <span>تبریک ! سفارش شما مشمول ارسال رایگان گلی کالا گردید.</span>
            </div>
          )}
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 divide-y divide-slate-100">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-3 py-12">
              <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <div className="text-sm font-black text-slate-800">
                سبد خرید شما در حال حاضر خالی است
              </div>
              <p className="text-xs text-slate-500 max-w-xs">
                از محصولات با اصالت برندهای آمالفی ، آگرادو و سایرو دیدن فرمایید و خریدی لذت بخش را تجربه کنید.
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-5 py-2.5 bg-rose-600 text-white text-xs font-bold rounded-xl shadow-xs hover:bg-rose-700 transition-colors cursor-pointer"
              >
                شروع خرید از گلی کالا
              </button>
            </div>
          ) : (
            items.map(({ product, quantity }) => (
              <div key={product.id} className="pt-4 first:pt-0 flex gap-3">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-18 h-18 object-cover rounded-xl border border-slate-200 shrink-0"
                />

                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="text-xs font-bold text-slate-900 leading-snug line-clamp-1">
                        {product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(product.id)}
                        className="text-slate-400 hover:text-red-600 p-1 transition-colors"
                        title="حذف از سبد"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="text-[10px] text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded-sm">
                      {product.brand} - اسپانیا
                    </span>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                      <button
                        onClick={() => onUpdateQuantity(product.id, quantity - 1)}
                        className="px-2 py-0.5 text-xs text-slate-600 hover:bg-slate-200 font-bold"
                      >
                        -
                      </button>
                      <span className="px-2.5 py-0.5 text-xs font-black text-slate-800">
                        {quantity.toLocaleString('fa-IR')}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(product.id, quantity + 1)}
                        className="px-2 py-0.5 text-xs text-slate-600 hover:bg-slate-200 font-bold"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-xs font-black text-slate-900">
                      {formatPrice(product.price * quantity)}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer with Coupon & Checkout */}
        {items.length > 0 && (
          <div className="p-5 border-t border-slate-100 bg-slate-50/80 space-y-3 shrink-0">
            
            {/* Coupon input */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <input
                type="text"
                placeholder="کد تخفیف (مثال : GOLI2026)"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-hidden focus:border-rose-500"
              />
              <button
                type="submit"
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                اعمال
              </button>
            </form>

            {discountApplied && (
              <div className="text-[11px] text-emerald-700 font-bold bg-emerald-50 p-2 rounded-lg border border-emerald-200 flex items-center justify-between">
                <span>کد تخفیف ۱۰ درصدی نمایندگی اعمال شد</span>
                <span>-{formatPrice(discountAmount)}</span>
              </div>
            )}

            {/* Calculations */}
            <div className="space-y-1.5 text-xs text-slate-600 pt-1">
              <div className="flex justify-between">
                <span>مجموع اقلام :</span>
                <span className="font-bold text-slate-800">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>هزینه بسته‌بندی و ارسال :</span>
                <span className="font-bold text-slate-800">
                  {shippingFee === 0 ? (
                    <span className="text-emerald-600 font-black">رایگان (پیشتاز)</span>
                  ) : (
                    formatPrice(shippingFee)
                  )}
                </span>
              </div>
              <div className="flex justify-between text-sm font-black text-slate-950 pt-2 border-t border-slate-200">
                <span>مبلغ نهایی قابل پرداخت :</span>
                <span className="text-rose-600">{formatPrice(total)}</span>
              </div>
            </div>

            {/* Checkout button */}
            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="w-full py-3.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-lg shadow-rose-200 flex items-center justify-center gap-2 transition-all hover:scale-101 cursor-pointer"
            >
              <span>تکمیل سفارش و درگاه پرداخت امن</span>
              <ArrowLeft className="w-4 h-4" />
            </button>

            {/* Safe note */}
            <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>پرداخت امن از طریق شبکه رسمی شاپرک با تضمین اصالت گلی کالا</span>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
