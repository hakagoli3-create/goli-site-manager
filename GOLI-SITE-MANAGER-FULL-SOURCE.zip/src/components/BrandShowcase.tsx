import React from 'react';
import { ShieldCheck, Award, Sparkles, CheckCircle2, ArrowLeft, ExternalLink } from 'lucide-react';
import { OFFICIAL_BRANDS } from '../data/mockData';

interface BrandShowcaseProps {
  onSelectBrand: (brandName: string) => void;
  onOpenAuthenticity: () => void;
}

export const BrandShowcase: React.FC<BrandShowcaseProps> = ({
  onSelectBrand,
  onOpenAuthenticity,
}) => {
  return (
    <section className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div className="text-right">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-800 rounded-full text-xs font-bold border border-amber-200 mb-2">
              <Award className="w-3.5 h-3.5 text-amber-600" />
              <span>پرتفوی رسمی واردات گلی کالا در ایران</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              نمایندگی رسمی برندهای مطرح اروپایی
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">
              تنها مرجع رسمی عرضه با برچسب شبنم ، بچ کد معتبر و تضمین ۱۰۰ درصدی اصالت فیزیکی کالا
            </p>
          </div>

          <button
            onClick={onOpenAuthenticity}
            className="self-start md:self-auto flex items-center gap-2 text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>چگونه اصالت کالاها را بررسی کنیم ؟</span>
          </button>
        </div>

        {/* 3 Brand Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {OFFICIAL_BRANDS.map((brand) => (
            <div
              key={brand.name}
              className="group relative bg-slate-50 hover:bg-white rounded-3xl border border-slate-200 hover:border-rose-300 p-6 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Brand Banner Thumbnail */}
                <div className="relative h-44 rounded-2xl overflow-hidden mb-5">
                  <img
                    src={brand.banner}
                    alt={brand.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                  
                  {/* Badge */}
                  <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs text-slate-900 text-[11px] font-black px-2.5 py-1 rounded-full shadow-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{brand.badge}</span>
                  </div>

                  {/* Country Flag / Name */}
                  <div className="absolute bottom-3 right-3 text-white text-right">
                    <div className="text-lg font-black">{brand.name} ({brand.nameEn})</div>
                    <div className="text-xs text-slate-300 flex items-center gap-1">
                      <span>ساخت کشور :</span>
                      <strong className="text-amber-300">{brand.country}</strong>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-4 text-right">
                  {brand.description}
                </p>
              </div>

              {/* Action Button & Count */}
              <div className="pt-4 border-t border-slate-200/70 flex items-center justify-between">
                <span className="text-xs text-slate-500 font-medium">
                  {brand.productCount} محصول فعال در انبار
                </span>

                <button
                  onClick={() => onSelectBrand(brand.name)}
                  className="flex items-center gap-1.5 text-xs font-bold text-rose-600 group-hover:text-white bg-rose-50 group-hover:bg-rose-600 px-3.5 py-2 rounded-xl transition-all cursor-pointer"
                >
                  <span>مشاهده محصولات</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Other European Brands Guarantee Note */}
        <div className="mt-8 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-right">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">
                تضمین بی قید و شرط اصالت برای سایر محصولات خارجی موجود در گلی کالا
              </div>
              <div className="text-xs text-slate-300 mt-0.5">
                تمامی برندهای خارجی دیگر مانند گارنیر ، لورال و سیمپل نیز با فاکتور معتبر و بررسی آزمایشگاهی ارسال می شوند.
              </div>
            </div>
          </div>

          <button
            onClick={() => onSelectBrand('سایر برندهای اروپایی')}
            className="shrink-0 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            مشاهده سایر برندهای اروپایی
          </button>
        </div>

      </div>
    </section>
  );
};
