import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  Truck, 
  CreditCard, 
  Lock, 
  Smartphone, 
  Mail, 
  ArrowLeft, 
  ArrowRight,
  PackageCheck,
  Check
} from 'lucide-react';
import { CartItem, Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderCompleted: (order: Order) => void;
  onOpenUserDashboard: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onOrderCompleted,
  onOpenUserDashboard,
}) => {
  const [step, setStep] = useState<'info' | 'gateway' | 'success'>('info');
  const [customerName, setCustomerName] = useState('کامران گلی');
  const [phone, setPhone] = useState('۰۹۱۲۳۴۵۶۷۸۹');
  const [email, setEmail] = useState('kamran0goli@gmail.com');
  const [province, setProvince] = useState('تهران');
  const [city, setCity] = useState('تهران');
  const [address, setAddress] = useState('بلوار جنت آباد جنوبی ، کوچه بنفشه ، پلاک ۱۲ ، واحد ۴');
  const [postalCode, setPostalCode] = useState('۱۴۷۳۸۲۹۱۰۱');
  const [shippingMethod, setShippingMethod] = useState<'تیپاکس اکسپرس' | 'پست پیشتاز'>('تیپاکس اکسپرس');
  const [paymentGateway, setPaymentGateway] = useState<'shaparak-saman' | 'shaparak-mellat' | 'zarinpal'>('shaparak-saman');
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, curr) => acc + (curr.product.price * curr.quantity), 0);
  const shippingFee = subtotal >= 800000 ? 0 : 45000;
  const total = subtotal + shippingFee;

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  const handleStartPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('gateway');
  };

  const handleCompletePaymentSimulation = () => {
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const tracking = `GK-${randomSuffix}`;
    const postTracking = `319400${randomSuffix}8820`;

    const newOrder: Order = {
      id: tracking,
      trackingCode: tracking,
      postTrackingCode: postTracking,
      date: 'لحظاتی پیش (امروز)',
      items: items.map(it => ({
        productId: it.product.id,
        productName: it.product.name,
        price: it.product.price,
        quantity: it.quantity,
        image: it.product.image
      })),
      totalAmount: total,
      status: 'در حال پردازش',
      shippingMethod: shippingMethod,
      customerName: customerName,
      phone: phone,
      address: `${province} ، ${city} ، ${address} (کد پستی : ${postalCode})`,
      smsAlertsSent: [
        {
          timestamp: 'هم اکنون',
          message: `گلی کالا : کاربر گرامی ${customerName} ، سفارش شما با شناسه ${tracking} در سامانه ثبت شد و جهت پردازش و تست اصالت کالا به انبار مرکزی ارسال گردید.`
        }
      ]
    };

    setCreatedOrder(newOrder);
    onOrderCompleted(newOrder);
    setStep('success');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div 
        className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto max-h-[94vh] flex flex-col text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-600" />
            <span className="text-xs sm:text-sm font-black text-slate-800">
              تسویه حساب امن گلی کالا (نمایندگی رسمی محصولات اروپایی)
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1">
          
          {/* STEP 1: Address & Shipping Information */}
          {step === 'info' && (
            <form onSubmit={handleStartPayment} className="space-y-5">
              
              <div className="space-y-1">
                <h3 className="text-sm font-black text-slate-900">
                  ۱. مشخصات خریدار و تحویل گیرنده
                </h3>
                <p className="text-xs text-slate-500">
                  اطلاعات دقیق خود را جهت دریافت پیامک های لحظه ای وضعیت مرسوله وارد فرمایید.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">نام و نام خانوادگی :</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">شماره موبایل (جهت پیامک لحظه ای) :</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white text-left dir-ltr"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">آدرس ایمیل (اختیاری) :</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white text-left dir-ltr"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">کد پستی ۱۰ رقمی :</label>
                  <input
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white text-left dir-ltr"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">استان :</label>
                  <input
                    type="text"
                    required
                    value={province}
                    onChange={(e) => setProvince(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">شهر :</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 text-xs">نشانی دقیق پستی :</label>
                <textarea
                  required
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-rose-500 focus:bg-white text-xs leading-relaxed"
                />
              </div>

              {/* Shipping Method */}
              <div className="pt-2 border-t border-slate-200/60">
                <h4 className="text-xs font-bold text-slate-900 mb-2">
                  ۲. انتخاب شیوه ارسال مرسوله :
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div
                    onClick={() => setShippingMethod('تیپاکس اکسپرس')}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                      shippingMethod === 'تیپاکس اکسپرس'
                        ? 'border-rose-600 bg-rose-50/50 shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-slate-900">
                      <span>تیپاکس اکسپرس (سریع ترین)</span>
                      {shippingMethod === 'تیپاکس اکسپرس' && <Check className="w-4 h-4 text-rose-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">تحویل ۲۴ الی ۴۸ ساعته با پیامک رهگیری زنده</p>
                  </div>

                  <div
                    onClick={() => setShippingMethod('پست پیشتاز')}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                      shippingMethod === 'پست پیشتاز'
                        ? 'border-rose-600 bg-rose-50/50 shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-slate-900">
                      <span>پست پیشتاز سراسری</span>
                      {shippingMethod === 'پست پیشتاز' && <Check className="w-4 h-4 text-rose-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">تحویل ۲ الی ۴ روز کاری در تمام نقاط کشور</p>
                  </div>
                </div>
              </div>

              {/* Order summary box */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>مجموع ارزش اقلام اورجینال ({items.length} کالا) :</span>
                  <span className="font-bold text-slate-800">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>هزینه بسته‌بندی ضد ضربه و ارسال :</span>
                  <span className="font-bold text-slate-800">
                    {shippingFee === 0 ? <strong className="text-emerald-600">رایگان</strong> : formatPrice(shippingFee)}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-slate-200">
                  <span>مبلغ قابل پرداخت در درگاه شاپرک :</span>
                  <span className="text-rose-600">{formatPrice(total)}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-lg shadow-rose-200 flex items-center justify-center gap-2 cursor-pointer transition-transform hover:scale-101"
              >
                <span>ادامه و ورود به درگاه پرداخت شاپرک</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 2: Secure Shaparak Gateway Simulation */}
          {step === 'gateway' && (
            <div className="space-y-5">
              
              {/* Shaparak Header */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <div className="text-xs font-black">درگاه پرداخت الکترونیک شاپرک (بانک مرکزی)</div>
                    <div className="text-[10px] text-blue-200">پذیرنده رسمی : فروشگاه اینترنتی گلی کالا (کد : 4920194)</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-[11px] bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-400/30">
                  <Lock className="w-3 h-3" />
                  <span>SSL 256-Bit</span>
                </div>
              </div>

              {/* Gateway Selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-800 block">انتخاب درگاه بانکی متصل به شاپرک :</label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentGateway('shaparak-saman')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all ${
                      paymentGateway === 'shaparak-saman' ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-2xs' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    بانک سامان (سپ)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentGateway('shaparak-mellat')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all ${
                      paymentGateway === 'shaparak-mellat' ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-2xs' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    بانک ملت (به پرداخت)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentGateway('zarinpal')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all ${
                      paymentGateway === 'zarinpal' ? 'border-amber-600 bg-amber-50 text-amber-900 shadow-2xs' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    زرین پال اکسپرس
                  </button>
                </div>
              </div>

              {/* Simulated Card Entry */}
              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block mb-1">مبلغ تراکنش :</span>
                  <span className="text-base font-black text-slate-900">{formatPrice(total)}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-slate-500 block">شماره کارت ۱۶ رقمی فرضی :</span>
                  <input
                    type="text"
                    disabled
                    value="۶۰۳۷ - ۹۹۱۸ - **** - ۵۴۲۱"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-center font-mono font-bold text-slate-700"
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                  <span>رمز دوم پویا : <strong>ارسال شد</strong></span>
                  <span className="text-emerald-700 font-bold">محیط آزمایشی پرداخت گلی کالا</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setStep('info')}
                  className="px-4 py-3 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  بازگشت
                </button>

                <button
                  type="button"
                  onClick={handleCompletePaymentSimulation}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تایید و پرداخت موفقیت آمیز {formatPrice(total)}</span>
                </button>
              </div>

            </div>
          )}

          {/* STEP 3: Order Success & SMS Alert Simulation */}
          {step === 'success' && createdOrder && (
            <div className="space-y-6 text-center">
              
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md shadow-emerald-100">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-black text-slate-900">
                  پرداخت شما با موفقیت انجام شد !
                </h3>
                <p className="text-xs text-slate-600">
                  سفارش شما در سامانه رسمی گلی کالا ثبت شد و روند بسته بندی و تست بچ کد آغاز گردید.
                </p>
              </div>

              {/* Tracking Codes Box */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2 text-right">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="text-slate-500">شماره سفارش گلی کالا :</span>
                  <strong className="text-sm font-black text-rose-600">{createdOrder.trackingCode}</strong>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="text-slate-500">کد رهگیری پستی / تیپاکس :</span>
                  <strong className="text-sm font-mono font-bold text-slate-800">{createdOrder.postTrackingCode}</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">شیوه ارسال :</span>
                  <strong className="font-bold text-slate-800">{createdOrder.shippingMethod}</strong>
                </div>
              </div>

              {/* Simulated SMS Alert Preview */}
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 text-right space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                  <Smartphone className="w-4 h-4 text-amber-600" />
                  <span>سامانه پیامکی لحظه ای گلی کالا (پیامک ارسال شده به {phone}) :</span>
                </div>
                <div className="p-3 bg-white rounded-xl border border-amber-200/80 text-xs text-slate-700 leading-relaxed font-normal font-sans shadow-2xs">
                  « {createdOrder.smsAlertsSent[0]?.message} »
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenUserDashboard();
                  }}
                  className="w-full sm:flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <PackageCheck className="w-4 h-4 text-amber-400" />
                  <span>ورود به پنل کاربری و رهگیری زنده مرسوله</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:w-auto px-5 py-3 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 cursor-pointer"
                >
                  بازگشت به سایت
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
