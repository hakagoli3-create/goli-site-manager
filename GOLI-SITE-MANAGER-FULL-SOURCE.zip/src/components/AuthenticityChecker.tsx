import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  Search, 
  Award, 
  FileCheck, 
  X, 
  AlertTriangle,
  Building2,
  Calendar,
  Sparkles
} from 'lucide-react';

interface AuthenticityCheckerProps {
  isOpen: boolean;
  onClose: () => void;
  initialCode?: string;
}

export const AuthenticityChecker: React.FC<AuthenticityCheckerProps> = ({
  isOpen,
  onClose,
  initialCode = '',
}) => {
  const [code, setCode] = useState(initialCode);
  const [result, setResult] = useState<any>(null);
  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const handleVerify = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setHasSearched(true);
    const clean = code.trim().toUpperCase();

    if (clean.includes('AGR')) {
      setResult({
        status: 'valid',
        brand: 'آگرادو (Agrado Cosmetic SL)',
        country: 'اسپانیا - والنسیا (Valencia, Spain)',
        facility: 'Laboratorios Agrado Polígono Industrial',
        productionDate: 'ژانویه ۲۰۲۶',
        expiryDate: 'ژانویه ۲۰۲۹ (۳۶ ماه ماندگاری)',
        importer: 'بازرگانی گلی کالا (نماینده رسمی انحصاری)',
        certNumber: 'EU-HEALTH-ESP-99824',
        guarantee: 'تضمین کتبی اصالت آزمایشگاهی ۱۰۰٪ با کد رهگیری شبنم'
      });
    } else if (clean.includes('AMF')) {
      setResult({
        status: 'valid',
        brand: 'آمالفی (Amalfi Quimi Romar)',
        country: 'اسپانیا - والنسیا (Moncada, Valencia, Spain)',
        facility: 'Planta de Producción Quimi Romar SL',
        productionDate: 'نوامبر ۲۰۲۵',
        expiryDate: 'نوامبر ۲۰۲۸ (۳۶ ماه ماندگاری)',
        importer: 'بازرگانی گلی کالا (نماینده رسمی انحصاری)',
        certNumber: 'EU-COSM-AMF-44120',
        guarantee: 'تضمین کتبی اصالت آزمایشگاهی ۱۰۰٪ با کد رهگیری شبنم'
      });
    } else if (clean.includes('SYR')) {
      setResult({
        status: 'valid',
        brand: 'سایرو (Syro Dermaceutic Europe)',
        country: 'اتحادیه اروپا - ایتالیا (Milan, EU)',
        facility: 'Dermato Labs European Division',
        productionDate: 'فوریه ۲۰۲۶',
        expiryDate: 'فوریه ۲۰۲۹ (۳۶ ماه ماندگاری)',
        importer: 'بازرگانی گلی کالا (نماینده رسمی انحصاری)',
        certNumber: 'EU-CE-SYR-11928',
        guarantee: 'تضمین کتبی اصالت آزمایشگاهی ۱۰۰٪ با کد رهگیری شبنم'
      });
    } else if (clean.length >= 4) {
      setResult({
        status: 'valid',
        brand: 'محصول خارجی اروپایی تحت تضمین گلی کالا',
        country: 'اتحادیه اروپا',
        facility: 'EU Certified Laboratory',
        productionDate: 'سال ۲۰۲۵/۲۰۲۶',
        expiryDate: '۳ سال پس از تاریخ تولید',
        importer: 'واردات مستقیم گلی کالا با ضمانت اصالت',
        certNumber: `EU-IMP-${clean}`,
        guarantee: 'ضمانت قطعی اصالت فیزیکی و آزمایشگاهی'
      });
    } else {
      setResult({
        status: 'invalid',
        message: 'کد وارد شده کوتاه است یا در سامانه رسمی ثبت نگردیده است. لطفا بچ کد حک شده روی بدنه محصول را بررسی فرمایید.'
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div 
        className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 bg-gradient-to-r from-emerald-800 to-teal-800 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-6 h-6 text-emerald-300" />
            <div>
              <h3 className="text-sm sm:text-base font-black">
                سامانه ملی استعلام بچ کد و اصالت محصولات گلی کالا
              </h3>
              <p className="text-[11px] text-emerald-200">
                پایگاه داده آزمایشگاهی برندهای آمالفی ، آگرادو و سایرو
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-emerald-700 text-emerald-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          <p className="text-xs text-slate-600 leading-relaxed font-normal">
            بچ کد (Batch Code) کد حک شده در انتهای ظروف یا روی جعبه محصولات آمالفی ، آگرادو و سایرو می باشد. با وارد کردن این کد می توانید مستقیما از اطلاعات کارخانه تولیدی در اسپانیا و اروپا اطمینان حاصل فرمایید.
          </p>

          {/* Form */}
          <form onSubmit={handleVerify} className="space-y-3">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="کد را وارد نمایید (مثال : ES-AGR-882941)"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold outline-hidden focus:border-emerald-600 focus:bg-white text-left dir-ltr"
              />
              <button
                type="submit"
                className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Search className="w-4 h-4" />
                <span>استعلام آنلاین</span>
              </button>
            </div>

            {/* Quick samples */}
            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 pt-1">
              <span>نمونه های آماده استعلام :</span>
              <button
                type="button"
                onClick={() => { setCode('ES-AGR-882941'); }}
                className="text-emerald-700 hover:underline bg-emerald-50 px-2 py-0.5 rounded-md font-mono"
              >
                ES-AGR-882941 (آگرادو)
              </button>
              <button
                type="button"
                onClick={() => { setCode('ES-AMF-331902'); }}
                className="text-emerald-700 hover:underline bg-emerald-50 px-2 py-0.5 rounded-md font-mono"
              >
                ES-AMF-331902 (آمالفی)
              </button>
              <button
                type="button"
                onClick={() => { setCode('EU-SYR-552910'); }}
                className="text-emerald-700 hover:underline bg-emerald-50 px-2 py-0.5 rounded-md font-mono"
              >
                EU-SYR-552910 (سایرو)
              </button>
            </div>
          </form>

          {/* Verification Result Display */}
          {hasSearched && result && (
            <div className="space-y-4 pt-2">
              {result.status === 'valid' ? (
                <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-300 space-y-4">
                  
                  {/* Status header */}
                  <div className="flex items-center justify-between pb-3 border-b border-emerald-200">
                    <div className="flex items-center gap-2 text-emerald-800 font-black text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>اصالت کالای اروپایی ۱۰۰٪ تایید گردید</span>
                    </div>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full font-bold">
                      واردات رسمی
                    </span>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700">
                    <div className="p-2.5 rounded-xl bg-white border border-emerald-100">
                      <span className="text-[11px] text-slate-400 block mb-0.5">کارخانه و برند سازنده :</span>
                      <strong className="text-slate-900">{result.brand}</strong>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-emerald-100">
                      <span className="text-[11px] text-slate-400 block mb-0.5">کشور و ایالت مبدا :</span>
                      <strong className="text-slate-900">{result.country}</strong>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-emerald-100">
                      <span className="text-[11px] text-slate-400 block mb-0.5">تاریخ دقیق ساخت :</span>
                      <strong className="text-slate-900">{result.productionDate}</strong>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-emerald-100">
                      <span className="text-[11px] text-slate-400 block mb-0.5">تاریخ انقضای رسمی :</span>
                      <strong className="text-emerald-700 font-bold">{result.expiryDate}</strong>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-emerald-100 col-span-1 sm:col-span-2">
                      <span className="text-[11px] text-slate-400 block mb-0.5">شماره گواهی بهداشت اتحادیه اروپا :</span>
                      <strong className="text-slate-900 font-mono">{result.certNumber}</strong>
                    </div>
                  </div>

                  {/* Guarantee banner */}
                  <div className="p-3 rounded-xl bg-emerald-100/70 text-emerald-900 text-xs font-bold flex items-center gap-2">
                    <Award className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>{result.guarantee}</span>
                  </div>

                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{result.message}</span>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
