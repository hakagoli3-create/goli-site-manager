import React from 'react';
import { 
  X, 
  ArrowLeftRight, 
  Check, 
  Star, 
  ShieldCheck, 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Sparkles 
} from 'lucide-react';
import { Product } from '../types';

interface ProductCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  compareProducts: Product[];
  allProducts: Product[];
  onRemoveFromCompare: (id: string) => void;
  onAddToCompare: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}

export const ProductCompareModal: React.FC<ProductCompareModalProps> = ({
  isOpen,
  onClose,
  compareProducts,
  allProducts,
  onRemoveFromCompare,
  onAddToCompare,
  onAddToCart,
}) => {
  if (!isOpen) return null;

  const availableToAdd = allProducts.filter(
    p => !compareProducts.some(cp => cp.id === p.id)
  );

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div 
        className="relative bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900">
                مقایسه تخصصی و رو در روی محصولات اروپایی گلی کالا
              </h3>
              <p className="text-[11px] text-slate-500">
                بررسی همزمان مشخصات ، ترکیبات ، کشور سازنده و قیمت
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {compareProducts.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <ArrowLeftRight className="w-8 h-8" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">هنوز کالایی به لیست مقایسه اضافه نشده است</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                از بخش فروشگاه یا کارت هر محصول روی آیکون مقایسه کلیک کنید تا جدول مشخصات رو در رو تشکیل گردد.
              </p>
              
              {/* Quick Add recommendations */}
              <div className="pt-4 max-w-md mx-auto">
                <span className="text-xs font-bold text-slate-700 block mb-2">پیشنهاد سریع برای مقایسه :</span>
                <div className="flex flex-wrap justify-center gap-2">
                  {allProducts.slice(0, 3).map(p => (
                    <button
                      key={p.id}
                      onClick={() => onAddToCompare(p)}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{p.name.slice(0, 25)}...</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="p-3 bg-slate-100/70 font-black text-slate-800 w-1/4 rounded-tr-2xl">
                      شاخص مقایسه
                    </th>
                    {compareProducts.map(p => (
                      <th key={p.id} className="p-3 bg-slate-50/50 min-w-[220px]">
                        <div className="relative space-y-2">
                          <button
                            onClick={() => onRemoveFromCompare(p.id)}
                            className="absolute -top-1 -left-1 p-1 text-slate-400 hover:text-red-600 rounded-md"
                            title="حذف از مقایسه"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-24 h-24 object-cover rounded-xl border border-slate-200 mx-auto"
                          />

                          <div className="text-center space-y-1">
                            <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded-full">
                              {p.brand} ({p.originCountry})
                            </span>
                            <div className="text-xs font-black text-slate-900 line-clamp-2">
                              {p.name}
                            </div>
                            <div className="text-xs font-black text-rose-600">
                              {formatPrice(p.price)}
                            </div>
                          </div>

                          <button
                            onClick={() => onAddToCart(p)}
                            className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>افزودن به سبد</span>
                          </button>
                        </div>
                      </th>
                    ))}
                    {compareProducts.length < 3 && (
                      <th className="p-3 bg-slate-50/20 border-r border-dashed border-slate-200 min-w-[180px] text-center">
                        <span className="text-xs text-slate-400 block mb-2 font-medium">افزودن کالای دیگر :</span>
                        <div className="space-y-1.5 max-h-48 overflow-y-auto">
                          {availableToAdd.slice(0, 4).map(p => (
                            <button
                              key={p.id}
                              onClick={() => onAddToCompare(p)}
                              className="w-full p-2 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-300 rounded-xl text-[11px] font-bold text-slate-700 text-right truncate flex items-center gap-1 cursor-pointer"
                            >
                              <Plus className="w-3 h-3 text-rose-600 shrink-0" />
                              <span className="truncate">{p.name}</span>
                            </button>
                          ))}
                        </div>
                      </th>
                    )}
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="p-3 font-bold text-slate-700 bg-slate-50/60">کشور سازنده</td>
                    {compareProducts.map(p => (
                      <td key={p.id} className="p-3 font-medium text-slate-800 text-center">
                        {p.originCountry} (اتحادیه اروپا)
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="p-3 font-bold text-slate-700 bg-slate-50/60">ضمانت اصالت و برچسب</td>
                    {compareProducts.map(p => (
                      <td key={p.id} className="p-3 text-center">
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>۱۰۰٪ کتبی با بچ کد</span>
                        </span>
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="p-3 font-bold text-slate-700 bg-slate-50/60">بچ کد فعال کارخانه</td>
                    {compareProducts.map(p => (
                      <td key={p.id} className="p-3 text-center font-mono font-bold text-slate-700">
                        {p.batchCodeExample}
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="p-3 font-bold text-slate-700 bg-slate-50/60">امتیاز خریداران</td>
                    {compareProducts.map(p => (
                      <td key={p.id} className="p-3 text-center">
                        <div className="inline-flex items-center gap-1 font-bold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-lg">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>{p.rating.toLocaleString('fa-IR')} از ۵ ({p.reviewsCount} نظر)</span>
                        </div>
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="p-3 font-bold text-slate-700 bg-slate-50/60">دسته و کاربرد اصلی</td>
                    {compareProducts.map(p => (
                      <td key={p.id} className="p-3 text-center font-medium text-slate-700">
                        {p.category}
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="p-3 font-bold text-slate-700 bg-slate-50/60">ویژگی های کلیدی</td>
                    {compareProducts.map(p => (
                      <td key={p.id} className="p-3">
                        <ul className="space-y-1 text-[11px] text-slate-600">
                          {p.features.slice(0, 3).map((f, i) => (
                            <li key={i} className="flex items-start gap-1">
                              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{f}</span>
                            </li>
                          ))}
                        </ul>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs">
          <span className="text-slate-500 font-medium">
            تعداد کالاهای در حال مقایسه : {compareProducts.length} از ۳
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-900 transition-colors cursor-pointer"
          >
            بستن جدول مقایسه
          </button>
        </div>

      </div>
    </div>
  );
};
