<?php
/**
 * Fired when the plugin is uninstalled.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Cleanup transient cache if needed
delete_transient('goli_manager_cache');
