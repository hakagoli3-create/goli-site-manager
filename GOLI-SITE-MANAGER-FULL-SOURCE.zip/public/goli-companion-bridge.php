<?php
/**
 * Plugin Name: Goli Site Manager Companion Bridge
 * Plugin URI:  https://golikala.com
 * Description: افزونه رسمی اتصال ایمن پلتفرم مدیریت و هوش مصنوعی Goli Site Manager به وردپرس، المنتور پرو و ووکامرس گلیکالا.
 * Version:     2.4.0
 * Author:      بازرگانی گلی (Goli Management Team)
 * Author URI:  https://golikala.com
 * License:     GPL-2.0+
 * Text Domain: goli-companion
 */

if (!defined('ABSPATH')) {
    exit; // خروج در صورت دسترسی مستقیم
}

class Goli_Companion_Bridge {

    const REST_NAMESPACE = 'goli/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_secure_routes'));
    }

    /**
     * ثبت مسیرهای REST API اختصاصی برای پلتفرم
     */
    public function register_secure_routes() {
        // ۱. بررسی سلامت و دریافت متادیتاهای المنتور، ووکامرس و کش لایت‌اسپید
        register_rest_route(self::REST_NAMESPACE, '/health', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_system_health'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));

        // ۲. دریافت ساختار سندی المنتور بدون تغییر دیتابیس
        register_rest_route(self::REST_NAMESPACE, '/elementor/get-document/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_elementor_document'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));

        // ۳. ذخیره ایمن ساختار المنتور پس از تایید مدیر با بک‌آپ خودکار
        register_rest_route(self::REST_NAMESPACE, '/elementor/save-document/(?P<id>\d+)', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'save_elementor_document'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));

        // ۴. پاک‌سازی هوشمند کش لایت‌اسپید
        register_rest_route(self::REST_NAMESPACE, '/litespeed/purge-cache', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'purge_litespeed_cache'),
            'permission_callback' => array($this, 'check_admin_permissions'),
        ));
    }

    /**
     * بررسی سطح دسترسی کاربر مدیر کل
     */
    public function check_admin_permissions() {
        return current_user_can('manage_options');
    }

    /**
     * وضعیت سلامت سیستم
     */
    public function get_system_health() {
        return rest_ensure_response(array(
            'status'           => 'OK',
            'bridge_version'   => '2.4.0',
            'wp_version'       => get_bloginfo('version'),
            'elementor_active' => defined('ELEMENTOR_VERSION'),
            'wc_active'        => class_exists('WooCommerce'),
            'litespeed_active' => defined('LSCWP_V'),
            'timestamp'        => current_time('mysql'),
            'site_name'        => get_bloginfo('name'),
        ));
    }

    /**
     * واکشی سند المنتور
     */
    public function get_elementor_document($request) {
        $page_id = intval($request['id']);
        if (!$page_id) {
            return new WP_Error('invalid_id', 'شناسه برگه نامعتبر است', array('status' => 400));
        }

        $elementor_data = get_post_meta($page_id, '_elementor_data', true);
        return rest_ensure_response(array(
            'page_id' => $page_id,
            'title'   => get_the_title($page_id),
            'data'    => $elementor_data ? json_decode($elementor_data, true) : null,
        ));
    }

    /**
     * ذخیره ساختار المنتور با ایجاد ریویژن
     */
    public function save_elementor_document($request) {
        $page_id = intval($request['id']);
        $params  = $request->get_json_params();

        if (empty($params['data'])) {
            return new WP_Error('empty_data', 'داده سندی المنتور خالی است', array('status' => 400));
        }

        // ذخیره بک‌آپ در متای پست
        $current_data = get_post_meta($page_id, '_elementor_data', true);
        update_post_meta($page_id, '_goli_backup_elementor_data_' . time(), $current_data);

        // اعمال تغییرات تایید شده
        update_post_meta($page_id, '_elementor_data', wp_slash(json_encode($params['data'])));

        return rest_ensure_response(array(
            'success' => true,
            'message' => 'سند المنتور با موفقیت به‌روزرسانی شد.',
        ));
    }

    /**
     * پاک‌سازی کش لایت‌اسپید
     */
    public function purge_litespeed_cache() {
        if (defined('LSCWP_V')) {
            do_action('litespeed_purge_all');
            return rest_ensure_response(array('success' => true, 'message' => 'کش لایت‌اسپید با موفقیت پاک‌سازی شد.'));
        }
        return rest_ensure_response(array('success' => false, 'message' => 'افزونه LiteSpeed Cache فعال نیست.'));
    }
}

// راه‌اندازی افزونه
new Goli_Companion_Bridge();
