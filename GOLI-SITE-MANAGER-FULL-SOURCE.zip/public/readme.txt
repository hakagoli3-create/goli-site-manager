=== Goli Site Manager Companion Bridge ===
Contributors: kamran0goli, golikala
Tags: elementor, woocommerce, rest-api, litespeed, ai-manager
Requires at least: 5.8
Tested up to: 6.7.1
Requires PHP: 7.4
Stable tag: 2.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

رابط امن و اختصاصی اتصال پلتفرم هوش مصنوعی GOLI SITE MANAGER به وردپرس، المنتور پرو و ووکامرس گلیکالا.

== Description ==

این افزونه مسیرهای امن REST API را در وردپرس تعریف می‌کند تا پلتفرم Goli Site Manager بتواند متادیتای المنتور، وضعیت کاتالوگ ووکامرس، کش لایت‌اسپید و شاخص‌های تشخیصی را با حفظ کامل امنیت مدیریت کند.

== Installation ==

1. فایل زیپ افزونه را در مسیر `افزونه‌ها > افزودن افزونه > بارگذاری افزونه` آپلود کنید.
2. روی دکمه فعال‌سازی افزونه کلیک کنید.
3. از بخش کاربران > شناسنامه شما، یک Application Password برای دسترسی ادمین پلتفرم ایجاد کنید.

== Changelog ==

= 2.4.0 =
* افزودن مسیرهای امن بررسی سلامت `/wp-json/goli/v1/health`
* پاک‌سازی و همگام‌سازی کش وب‌سرور LiteSpeed Enterprise
* سازگاری کامل با قالب باکالا (Bakala Child Theme) و المنتور پرو 3.25
