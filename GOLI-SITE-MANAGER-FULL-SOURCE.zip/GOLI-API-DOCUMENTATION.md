# مستندات کامل APIها و وب‌سرویس‌های GOLI SITE MANAGER
**نسخه سند:** ۲.۴.۰  
**تاریخ انتشار:** ۵ نوامبر ۲۰۲۶  
**مخاطب:** برنامه‌نویسان بک‌اند و یکپارچه‌سازان سیستم (Integration Engineers)

---

## بخش اول: اندپوینت‌های سرور میانی (Express Backend Proxy API)
تمام اندپوینت‌های این بخش بر روی پورت محلی اپلیکیشن (پیش‌فرض ۳۰۰۰) در دسترس هستند و به عنوان پروکسی و پردازشگر امن عمل می‌کنند.

---

### ۱. تست وضعیت اتصال وردپرس
* **مسیر (Endpoint):** `GET /api/wp/status`
* **کاربرد:** بررسی پینگ زنده سرور `golikala.com`، نسخه وب‌سرور لایت‌اسپید، نگارش PHP و افزونه‌های فعال.
* **پارامترها:** ندارد.
* **نمونه پاسخ موفق (HTTP 200 OK):**
```json
{
  "success": true,
  "siteUrl": "https://golikala.com",
  "latencyMs": 142,
  "name": "گلی کالا",
  "description": "تنها نمایندهٔ رسمی محصولات اروپایی برندهای Agrado، Amalfi و Sairo در ایران",
  "namespaces": ["wp/v2", "wc/v3", "elementor/v1", "rankmath/v1", "goli/v1"],
  "authMethods": ["Application Passwords", "JWT / Companion Bridge"],
  "status": "CONNECTED",
  "serverHeaders": {
    "server": "LiteSpeed",
    "poweredBy": "PHP/8.2"
  }
}
```

---

### ۲. دریافت محصولات زنده ووکامرس
* **مسیر (Endpoint):** `GET /api/wp/live-products`
* **کاربرد:** فراخوانی کاتالوگ محصولات زنده سایت بدون فیلتر با حذف کاراکترهای اضافه بافر قالب باکالا.
* **پارامترها:** ندارد (به طور پیش‌فرض تا ۳۰ قلم محصول آخر را واکشی می‌کند).
* **نمونه ساختار شیء محصول برگشتی:**
```json
{
  "success": true,
  "products": [
    {
      "id": 25224,
      "name": "شامپو عصاره پیاز آمالفی ۹۰۰ میلی‌لیتر",
      "slug": "amalfi-onion-shampoo-900ml",
      "type": "simple",
      "permalink": "https://golikala.com/product/amalfi-onion-shampoo-900ml/",
      "prices": {
        "price": "1227600",
        "regular_price": "1227600",
        "sale_price": "1227600",
        "currency_code": "IRR"
      },
      "images": [
        {
          "id": 25225,
          "src": "https://golikala.com/wp-content/uploads/30009472-CHAMPU-CEBOLLA-PUMP-900ML-AMALFI-1-3-1-5.png",
          "name": "شامپو پیاز آمالفی"
        }
      ],
      "is_in_stock": true,
      "short_description": "شامپو عصاره پیاز آمالفی با حجم ۹۰۰ میلی‌لیتر..."
    }
  ]
}
```

---

### ۳. دریافت برگه‌های زنده وردپرس
* **مسیر (Endpoint):** `GET /api/wp/live-pages`
* **کاربرد:** استخراج لیست برگه‌های وردپرس همراه با متای المنتور و اسلاگ‌ها.
* **نمونه پاسخ موفق:**
```json
{
  "success": true,
  "pages": [
    {
      "id": 26087,
      "title": { "rendered": "صفحه اصلی گلی کالا" },
      "slug": "home-redesign-2026",
      "status": "publish",
      "type": "page",
      "modified": "2026-11-04T17:03:10"
    },
    {
      "id": 25471,
      "title": { "rendered": "شامپو بدن آمالفی (Amalfi)" },
      "slug": "amalfi-body-wash",
      "status": "publish"
    }
  ]
}
```

---

### ۴. موتور پردازش هوش مصنوعی (Goli AI Agent)
* **مسیر (Endpoint):** `POST /api/ai/agent`
* **هدرها:** `Content-Type: application/json`
* **بدنه درخواست (Request Body):**
```json
{
  "instruction": "هیرو بنر صفحه اصلی را بر اساس هویت بصری سبز و طلایی بازطراحی کن",
  "taskType": "site_management",
  "context": {
    "siteUrl": "https://golikala.com",
    "activeTheme": "Bakala Child Theme",
    "elementorActive": true
  }
}
```
* **پاسخ برگشتی (Agent Response):**
```json
{
  "success": true,
  "agentResponse": {
    "summary": "طرح بهینه‌سازی ساختار هیرو بر اساس استانداردهای LCP و پالت سبز و طلایی تهیه شد.",
    "targetArea": "هیرو بنر صفحه اصلی (ID: 26087)",
    "riskLevel": "پایین",
    "planSteps": [
      "ثبت نقطه بازگشت خودکار در متای برگه",
      "اعمال کانتینر فلکس‌باکس با رنگ زمینه #0f382c و کادربندی طلایی #d4af37",
      "بهینه‌سازی تگ‌های سئو رنک‌مث"
    ],
    "elementorChanges": {
      "section": "هیرو بنر برندهای رسمی",
      "suggestedStructure": "کانتینر ۲ ستونه با اولویت لود سریع تصویر",
      "customCss": ".goli-hero-banner { background: #0f382c; border-radius: 20px; }"
    },
    "seoRecommendations": {
      "focusKeyword": "نماینده رسمی آمالفی، آگرادو و سایرو در ایران",
      "seoTitle": "گلی کالا | نماینده رسمی برندهای آمالفی، آگرادو و سایرو در ایران",
      "metaDescription": "خرید مستقیم محصولات مراقبت مو و پوست اصل اسپانیا با ضمانت قطعی اصالت کالا از بازرگانی گلی."
    },
    "requiresApproval": true,
    "dryRunVerified": true
  }
}
```

---

## بخش دوم: اندپوینت‌های افزونه وردپرس (Goli Companion Bridge)
این اندپوینت‌ها توسط افزونه `goli-companion-bridge.php` در وردپرس ایجاد می‌شوند.

### ۱. پایش سلامت و ماژول‌های فعال
* **مسیر (URL):** `https://golikala.com/wp-json/goli/v1/health`
* **متد:** `GET`
* **سطح دسترسی:** نیاز به احراز هویت ادمین (`current_user_can('manage_options')`).
* **خروجی:**
```json
{
  "status": "OK",
  "bridge_version": "2.4.0",
  "wp_version": "6.7.1",
  "elementor_active": true,
  "wc_active": true,
  "litespeed_active": true,
  "timestamp": "2026-11-05 08:30:00",
  "site_name": "گلی کالا"
}
```

### ۲. خواندن داده‌های سند المنتور
* **مسیر (URL):** `https://golikala.com/wp-json/goli/v1/elementor/get-document/{page_id}`
* **متد:** `GET`
* **خروجی:** برگرداندن شیء JSON ساختار ویجت‌ها و کانتینرهای ذخیره‌شده در متای `_elementor_data`.

### ۳. ذخیره ایمن داده‌های المنتور با بک‌آپ خودکار
* **مسیر (URL):** `https://golikala.com/wp-json/goli/v1/elementor/save-document/{page_id}`
* **متد:** `POST`
* **عملکرد:** قبل از نوشتن داده جدید، نسخه قبلی را در کلید `_goli_backup_elementor_data_{timestamp}` ذخیره کرده و سپس داده جدید را جایگزین می‌کند.

### ۴. پاک‌سازی کش لایت‌اسپید
* **مسیر (URL):** `https://golikala.com/wp-json/goli/v1/litespeed/purge-cache`
* **متد:** `POST`
* **عملکرد:** فراخوانی اکشن هوک `do_action('litespeed_purge_all')` در هسته سرور لایت‌اسپید.
